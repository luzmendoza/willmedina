<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Size extends CI_Controller {  //cambiar CI por MY_Controller por la seguridad

    public function __construct()
    {
      parent::__construct();
    //  $this->load->helper('url');
      $this->load->model('size_model');
    }

    public function index()
    {
        $data['sizes'] = $this->size_model->get_all();

        //enviar datos y cargar
 				$data['the_view_content'] = $this->load->view('sizes/size_view', $data, TRUE);

 				$this->load->view('templates/auth_master_view', $data);
    }


    //recupera y muestra en pantalla los datos del producto seleccionado
    public function get_all()
		{
        //comprobamos si es una petición ajax
        if($this->input->is_ajax_request())
        {
            $data = array();
            $data = $this->size_model->get_all();

       			echo json_encode($data);

        }
		}



}

?>
