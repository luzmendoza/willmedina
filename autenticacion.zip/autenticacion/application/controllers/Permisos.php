<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Permisos extends CI_Controller {

    public function __construct()
    {
      parent::__construct();
        $this->load->library('ion_auth');
      $this->load->model('permisos_model');
    }

    public function index()
    {
      //valida si esta logeado y si es administrador
			if ($this->ion_auth->logged_in())
			{
					if($this->ion_auth->is_admin())
					{
            $data = array();
            //enviar datos y cargar
     				$data['the_view_content'] = $this->load->view('permisos/permisos_view', $data, TRUE);

     				$this->load->view('templates/auth_master_view', $data);
          }else{
            //enviar mensaje que no tiene permisos para esta opción
             echo 'no eres administrador';
          }
       }else{
          echo 'no estas logeado';
           //enviar mensaje de logearse o mostrar pantalla de login
          //	redirect('auth/login');
       }
    }


    //recupera y muestra en pantalla los datos
    public function get_menu()
		{
        //comprobamos si es una petición ajax
        if($this->input->is_ajax_request())
        {
            $data = array();
            $data = $this->permisos_model->get_menu();

       			echo json_encode($data);

        }
		}

    public function add()
    {
      //comprobamos si es una petición ajax
      if($this->input->is_ajax_request())
      {
        try {
          //elimina los permisos existentes
          $this->permisos_model->delete($this->input->post('iduser'));
          //ingresa los nuevos permisos
          $this->permisos_model->add(json_decode($this->input->post('arrDetalles')));

          echo json_encode(array("status" => TRUE));
        } catch (\Exception $e) {
            echo json_encode(array("status" => FALSE, 'mensaje' => 'Ocurrio un error al asignar los permisos'));
        }
      }
    }

    public function get_usermenu($user)
		{
        //comprobamos si es una petición ajax
        if($this->input->is_ajax_request())
        {
            $data = $this->permisos_model->get_usermenu($user);

       			echo json_encode($data);

        }
		}

}

?>
