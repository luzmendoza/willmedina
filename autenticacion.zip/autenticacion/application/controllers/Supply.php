<?php
defined('BASEPATH') OR exit('No direct script access allowed');

//clase para suministros.. materias primas
class Supply extends CI_Controller {  //cambiar CI por MY_Controller por la seguridad

    public function __construct()
    {
      parent::__construct();
      $this->load->library('ion_auth');

      $this->load->model('supply_model');

      //carga las reglas de validacion de formulario
      $this->load->library('form_validation');
      //establece las reglas de validacion
      $this->form_validation->set_rules('name', 'Nombre', 'trim|required|is_unique[cat_supplies.name]');

    }

    public function index()
    {
      //valida si esta logeado y si es administrador
			if ($this->ion_auth->logged_in())
			{
					if($this->ion_auth->is_admin())
					{
              $data['supplies'] = $this->supply_model->get_all();

              //enviar datos y cargar
       				$data['the_view_content'] = $this->load->view('supplies/supply_view', $data, TRUE);

       				$this->load->view('templates/auth_master_view', $data);
          }else{
            //enviar mensaje que no tiene permisos para esta opción
             echo 'no eres administrador';
          }
       }else{
          echo 'no estas logeado';
           //enviar mensaje de logearse o mostrar pantalla de login
          //	redirect('auth/login');
       }

    }//fin index


    //crea o actualiza un registro
      public function add()
  		{
          //comprobamos si es una petición ajax
      	if($this->input->is_ajax_request())
        {

          //reglas de validaciones
          if($this->form_validation->run() == FALSE)
          {
            	//de esta forma devolvemos los errores de formularios
            	//con ajax desde codeigniter, aunque con php es lo mismo
            	$errors = array(
					           'name' => form_error('name'),
					            'respuesta' => 'error'
				               );
						//y lo devolvemos así para parsearlo con JSON.parse
		            echo json_encode($errors);
		            return FALSE;
			    }
          else{
              $code = $this->supply_model->count();
              $code = str_pad($code, 5, "0", STR_PAD_LEFT);
              $code = "wm-s-".$code;
            //realizar los registros en la base de datos
        			$data = array(
        					'name' => $this->input->post('name'),
                  'code' => $code,
        				);
                //si estamos editando
            	if($this->input->post('id'))
            	{
                  //actualizar
                  $this->supply_model->update(array('id' => $this->input->post('id')), $data);
              }
              else{
                  //guardar en la tabla
                  $this->supply_model->add($data);
              }

        			echo json_encode(array("status" => TRUE));
          }
        }//fin ajax
      }//fin add

      //recupera y muestra en pantalla los datos registro seleccionado
          public function edit($id)
      		{
            //comprobamos si es una petición ajax y existe la variable post id
              if($this->input->is_ajax_request())
              {
                  $data = array();
                  $supply = $this->supply_model->get_by_id($id);
                  $data['id'] = $supply->id;
                  $data['name'] = $supply->name;

             			echo json_encode($data);

              }
      		}


    //elimina un registro por id
    public function delete($id)
  	{
      //comprobamos si es una petición ajax y existe la variable post id
        if($this->input->is_ajax_request())
        {
      		$this->supply_model->delete($id);
      		echo json_encode(array("status" => TRUE));
        }
  	}

    //autocomplete para busqueda por sku o nombre en ventas
    public function autocomplete()
    {
       $supplies =  $this->supply_model->get_all();
      echo json_encode($supplies);
    }

    //recupera y muestra en pantalla los datos del producto seleccionado
    public function get_all()
		{   //comprobamos si es una petición ajax
        if($this->input->is_ajax_request())
        {
            $data = array();
            $data = $this->supply_model->get_all();
       			echo json_encode($data);
        }
		}
  }
  ?>
