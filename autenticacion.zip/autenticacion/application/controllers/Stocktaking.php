<?php
defined('BASEPATH') OR exit('No direct script access allowed');

//clase para control de inventario
class Stocktaking extends CI_Controller {  //.....aqui me quede

    public function __construct()
    {
      parent::__construct();
      $this->load->library('ion_auth');

      $this->load->model('stocksupply_model');
      $this->load->model('stockproduct_model');

      //carga las reglas de validacion de formulario
      $this->load->library('form_validation');

    }

    public function supply()
    {
      //valida si esta logeado y si es administrador
      if ($this->ion_auth->logged_in())
      {
          if($this->ion_auth->is_admin())
          {
              $data= array();
              //enviar datos y cargar
              $data['the_view_content'] = $this->load->view('stocktaking/stocksupply_view', $data, TRUE);
              $this->load->view('templates/auth_master_view', $data);
            }else{
              //enviar mensaje que no tiene permisos para esta opción
               echo 'no eres administrador';
            }
         }else{
            echo 'no estas logeado';
             //enviar mensaje de logearse o mostrar pantalla de login
            //	redirect('auth/login');
         }
    }
    public function product()
    {
      //valida si esta logeado y si es administrador
      if ($this->ion_auth->logged_in())
      {
          if($this->ion_auth->is_admin())
          {
            $data= array();
            //enviar datos y cargar
            $data['the_view_content'] = $this->load->view('stocktaking/stockproduct_view', $data, TRUE);
            $this->load->view('templates/auth_master_view', $data);
          }else{
            //enviar mensaje que no tiene permisos para esta opción
             echo 'no eres administrador';
          }
       }else{
          echo 'no estas logeado';
           //enviar mensaje de logearse o mostrar pantalla de login
          //	redirect('auth/login');
       }
    }

    public function getstocksupply($id)
    {
      //comprobamos si es una petición ajax y existe la variable post id
        if($this->input->is_ajax_request())
        {
            //recuperar los detalles del producto
            $stocksupply = $this->stocksupply_model->get_by_id($id);

            echo json_encode($stocksupply);

        }
    }
    public function gethistorysupply($id)
    {
      //comprobamos si es una petición ajax y existe la variable post id
        if($this->input->is_ajax_request())
        {
            //recuperar el historial
            $stocksupply = $this->stocksupply_model->get_history($id);

            echo json_encode($stocksupply);

        }
    }

    //crea o actualiza un registro
      public function addsum()
      {
          //comprobamos si es una petición ajax
          if($this->input->is_ajax_request())
          {
              //establece las reglas de validacion
              $this->form_validation->set_rules('id_supply', 'Insumo', 'trim|required');
              $this->form_validation->set_rules('cantidad', 'Cantidad', 'trim|numeric|required');
              $this->form_validation->set_rules('precio', 'Precio', 'trim|numeric|required');
              //reglas de validaciones
              if($this->form_validation->run() == FALSE)
              {
                  //de esta forma devolvemos los errores de formularios
                  //con ajax desde codeigniter, aunque con php es lo mismo
                  $errors = array(
                         'supply' => form_error('id_supply'),
                         'amount' => form_error('cantidad'),
                         'price' => form_error('price'),
                          'respuesta' => 'error'
                           );
                //y lo devolvemos así para parsearlo con JSON.parse
                    echo json_encode($errors);
                    return FALSE;
              }
              else{
                  //  $supply = $this->input->post('id_supply');
                  $cantidad = $this->input->post('cantidad');
                  $cantidadAnterior = $this->input->post('stock');
                //realizar los registros en la base de datos
                  if($this->input->post('medida') == 1)//metros
                  { //convertir a centimentros
                    $cantidad = $this->input->post('cantidad') * 100;
                    $meausure = '2';
                    $precio = $this->input->post('precio') / 100;
                  }else{
                     $cantidad = $this->input->post('cantidad');
                     $meausure = $this->input->post('medida');
                     $precio = $this->input->post('precio') / $cantidad;
                  }
                  $data = array(
                      'id_supply' => $this->input->post('id_supply'),
                      'existence' => $cantidad+$cantidadAnterior,
                      'unit_measure' => $meausure,
                      'unit_price' => $precio,
                    );

                    $descripcion = $this->input->post('descripcion');
                    if($descripcion=='')
                    {
                      $descripcion = 'Nueva entrada';
                    }
                    $user = $this->ion_auth->user()->row();//obtiene el usuario logeado
                    $datahistory = array(
                        'id_supply' => $this->input->post('id_supply'),
                        'amount' => $cantidad,
                        'type_mov' => '1',
                        'description' => $descripcion,
                        'id_user' => $user->id, //  $_SESSION['usuario'],
                      );
                      if($this->input->post('id'))
                      {
                          //actualizar
                          $this->stocksupply_model->update(array('id' => $this->input->post('id')), $data);
                      }
                      else{
                          //guardar en la tabla
                          $this->stocksupply_model->add($data);
                      }
                      //guardar en la tabla historial
                      $this->stocksupply_model->addhistory($datahistory);


                  echo json_encode(array("status" => TRUE, 'Usuario' =>$user));
              }
          }//fin ajax
      }

      public function getstockproduct($idProduct,$idSuc)
      {
        //comprobamos si es una petición ajax y existe la variable post id
          if($this->input->is_ajax_request())
          {
              //recuperar los detalles del producto
              $stockproduct = $this->stockproduct_model->get_by($idProduct,$idSuc);
              echo json_encode($stockproduct);
          }
      }
      public function gethistoryproduct($idProduct,$idSuc)
      {
        //comprobamos si es una petición ajax y existe la variable post id
          if($this->input->is_ajax_request())
          {
              //recuperar el historial
              $stockproduct = $this->stockproduct_model->get_history($idProduct,$idSuc);
              echo json_encode($stockproduct);

          }
      }
      public function addpro()
      {
        //comprobamos si es una petición ajax
        if($this->input->is_ajax_request())
        {
            //establece las reglas de validacion
            $this->form_validation->set_rules('id_product', 'Producto', 'trim|required');
            $this->form_validation->set_rules('id_sucursal', 'Sucursal', 'trim|required');
            //reglas de validaciones
            if($this->form_validation->run() == FALSE)
            {
                //de esta forma devolvemos los errores de formularios
                //con ajax desde codeigniter, aunque con php es lo mismo
                $errors = array(
                       'producto' => form_error('id_product'),
                       'sucursal' => form_error('id_sucursal'),
                        'respuesta' => 'error'
                         );
              //y lo devolvemos así para parsearlo con JSON.parse
                  echo json_encode($errors);
                  return FALSE;
            }
            else{
                //recuperar los detalles
                $detalles['arrDetalles']  = json_decode($this->input->post('arrDetalles'));
                $descripcion = $this->input->post('descripcion');
                  if($descripcion=='')
                  {
                    $descripcion = 'Nueva entrada';
                  }
                  $user = $this->ion_auth->user()->row();//obtiene el usuario logeado

                    //guardar en la tabla
                    $this->stockproduct_model->add($detalles, $this->input->post('id_product'),$this->input->post('id_sucursal'));
                    //guardar en la tabla historial... 'type_mov' => '1'
                    $this->stockproduct_model->addhistory($detalles,$descripcion,$user->id,$this->input->post('id_product'),$this->input->post('id_sucursal'));


                echo json_encode(array("status" => TRUE, 'Usuario' =>$user));
            }
        }//fin ajax
      }

      public function getstockproductsuc($id,$idsize,$idsuc)
      {        //comprobamos si es una petición ajax y existe la variable post id
          if($this->input->is_ajax_request())
          {   //recuperar los detalles del producto
              $stockproduct = $this->stockproduct_model->get_by_productsuc($id,$idsize,$idsuc);
              echo json_encode($stockproduct);
          }
      }
  }
  ?>
