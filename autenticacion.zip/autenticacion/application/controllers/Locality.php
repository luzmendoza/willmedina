<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Locality extends CI_Controller {  //cambiar CI por MY_Controller por la seguridad

    public function __construct()
    {
      parent::__construct();
      //$this->load->helper('url');
      $this->load->model('locality_model');
    }

    public function index()
    {
        $data['localities'] = $this->locality_model->get_all();

        //enviar datos y cargar
 				$data['the_view_content'] = $this->load->view('localities/locality_view', $data, TRUE);

 				$this->load->view('templates/auth_master_view', $data);
    }


    //recupera y muestra en pantalla los datos del producto seleccionado
    public function get_all_by_id($idEstado,$idLocalidad)
		{
        //comprobamos si es una petición ajax
        if($this->input->is_ajax_request())
        {
            $data = array();
            $data = $this->locality_model->get_all_by_id($idEstado,$idLocalidad);

       			echo json_encode($data);

        }
		}



}

?>
