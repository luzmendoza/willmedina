<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Customer extends CI_Controller { 

    public function __construct()
    {
      parent::__construct();
      $this->load->library('ion_auth');

    //  $this->load->helper('url');
      $this->load->model('customer_model');
      $this->load->model('useraddress_model');

      //carga las reglas de validacion de formulario
      $this->load->library('form_validation');
      //establece las reglas de validacion
    //  $this->form_validation->set_rules('first_name', 'Nombre', 'trim|required');
    //  $this->form_validation->set_rules('last_name', 'Apellido Paterno', 'trim|required');
      $this->form_validation->set_rules('cell_phone', 'Celular', 'required|numeric');
      $this->form_validation->set_rules('birth_date', 'Fecha Nacimiento', 'required|date');//establecer formato fecha

      $this->form_validation->set_rules('country', 'País', 'trim|required');
      $this->form_validation->set_rules('cp', 'Codigo Postal', 'required|greater_than[0]');
      $this->form_validation->set_rules('street', 'Calle', 'trim|required');
      $this->form_validation->set_rules('num_exterior', 'No. Exterior', 'required|greater_than[0]');

    }

    public function index()
    {
      //valida si esta logeado y si es administrador
			if ($this->ion_auth->logged_in())
			{
					if($this->ion_auth->is_admin())
					{
              $data['customers'] = $this->customer_model->get_all();

              //enviar datos y cargar
       				$data['the_view_content'] = $this->load->view('customers/customer_view', $data, TRUE);

       				$this->load->view('templates/auth_master_view', $data);
          }else{
            //enviar mensaje que no tiene permisos para esta opción
             echo 'no eres administrador';
          }
       }else{
          echo 'no estas logeado';
           //enviar mensaje de logearse o mostrar pantalla de login
          //	redirect('auth/login');
       }

    }//fin index


    //crea o actualiza un empleado
      public function add()
  		{
          //comprobamos si es una petición ajax
      	if($this->input->is_ajax_request())
        {
          if($this->input->post('id'))
          {
            $this->form_validation->set_rules('id_user', 'Usuario', 'required');
          }else{
            $this->form_validation->set_rules('id_user', 'Usuario', 'required|is_unique[cat_customers.id_user]');
          }

          //reglas de validaciones
          if($this->form_validation->run() == FALSE)
          {
            	//de esta forma devolvemos los errores de formularios
            	//con ajax desde codeigniter, aunque con php es lo mismo
            	$errors = array(
					           'id_user' => form_error('id_user'),
					           'cell_phone' => form_error('cell_phone'),
                     'birth_date' => form_error('birth_date'),
					            'country' => form_error('country'),
                      'cp' => form_error('cp'),
                      'street' => form_error('street'),
                      'num_exterior' => form_error('num_exterior'),
					            'respuesta' => 'error'
				               );
						//y lo devolvemos así para parsearlo con JSON.parse
		            echo json_encode($errors);
		            return FALSE;
			    }
          else{
            	$targetPath = '';
              $new_name = '';

              if($this->input->post('llevaImagen') == 'si')
              {
                  $MaxID =  $this->customer_model->count();
                  if($this->input->post('id'))
                  {
                    if (file_exists($this->input->post('urlImagen'))) {
                      $imagen = $this->input->post('nameImagen');//uploads/employees/00001
                      //eliminar imagen anterior
                      $this->deleteimage($this->input->post('nameImagen'));
                    }

                  }
                  //cargar imagenes
                  foreach($_FILES['images']['name'] as $name => $value)
                  {
                       $file_name = explode(".", $_FILES['images']['name'][$name]);
                       $allowed_extension = array("jpg", "jpeg", "png", "gif");
                       if(in_array($file_name[1], $allowed_extension))
                       {
                            $new_name = $MaxID.'.'. $file_name[1];
                            $sourcePath = $_FILES["images"]["tmp_name"][$name];
                            $targetPath = "uploads/customers/".$new_name;
                            if(move_uploaded_file($sourcePath, $targetPath))//guarda la imagen original
                            {
                                $this->create_thumbnail($new_name);//creamos un thumbnail de la imagen
                            }
                       }
                  }
              }



            // $birthdate = $this->FormatoFechaSQL( str_replace($this->input->post('birth_date'),"/","-"));
            //realizar los registros en la base de datos
        			$data = array(
        					'id_user' => $this->input->post('id_user'),
        					'phone' => $this->input->post('phone'),
        					'cell_phone' => $this->input->post('cell_phone'),
        					'birth_date' => $this->input->post('birth_date'),
                  'sex' => $this->input->post('sex'),
                  'imageurl' => $targetPath,
                  'image' =>$new_name,
        				);

                $data_address = array(
                    'id_user' => $this->input->post('id_user'),
                    'type_user' => '2',
          					'key_country' => $this->input->post('country'),
          					'key_cp' => $this->input->post('cp'),
          					'key_state' => $this->input->post('state'),
          					'key_colony' =>$this->input->post('colony'),
                    'street' => $this->input->post('street'),
                    'num_exterior' => $this->input->post('num_exterior'),
                    'num_inside' => $this->input->post('num_inside'),
                    'street_between1' => $this->input->post('street1'),
                    'street_between2' => $this->input->post('street2'),
                    'complement' => $this->input->post('complement'),
          				);
                //si estamos editando
            	if($this->input->post('id'))
            	{
                  //actualizar
                  $this->customer_model->update(array('id' => $this->input->post('id')), $data);
                  $this->useraddress_model->update(array('id_user' => $this->input->post('id_user')), $data_address);
              }
              else{
                  //guardar en la tabla
                  $customerID = $this->customer_model->add($data);
                  $direcID =$this->useraddress_model->add($data_address);
              }

        			echo json_encode(array("status" => TRUE));
          }
        }//fin ajax
      }//fin add

      //FUNCIÓN PARA CREAR LA MINIATURA A LA MEDIDA QUE LE DIGAMOS
      public function create_thumbnail($filename){
          $config['image_library'] = 'gd2';
          //CARPETA EN LA QUE ESTÁ LA IMAGEN A REDIMENSIONAR
          $config['source_image'] = 'uploads/customers/'.$filename;
          $config['allowed_types'] = 'gif|jpg|png|jpeg';
          $config['create_thumb'] = TRUE;
          $config['maintain_ratio'] = TRUE;
          //CARPETA EN LA QUE GUARDAMOS LA MINIATURA
          $config['new_image']='uploads/thumbs/customers/';
          $config['width'] = 150;//150;
          $config['height'] = 150;//150;
          $config['thumb_marker'] = '';//elimina el _thumb;
          $this->load->library('image_lib', $config);
          $this->image_lib->initialize($config);
          /*if (!$this->image_lib->resize()) {
            echo $this->image_lib->display_errors();
          }*/
          $this->image_lib->resize();
           $this->image_lib->clear();
      }

      //modifica una fecha a formato sql valido
      public function FormatoFechaSQL($dateString) {
        $date = new DateTime($dateString);
        $fecha = $date->format('Y-m-d');
      	return $fecha;
      }

      //recupera y muestra en pantalla los datos del cliente seleccionado
          public function edit($id)
      		{
            //comprobamos si es una petición ajax y existe la variable post id
              if($this->input->is_ajax_request())
              {
                  $data = array();
            			//$data = $this->product_model->get_by_id($id);
                  $cliente = $this->customer_model->get_by_id($id);
                  $data['id'] = $cliente->id;
                  $data['id_user'] = $cliente->id_user;
                  $data['first_name'] = $cliente->first_name;
                  $data['last_name'] = $cliente->last_name;
                  $data['phone'] = $cliente->phone;
                  $data['cell_phone'] = $cliente->cell_phone;
                  $data['birth_date'] = $cliente->birth_date;
                  $data['sex'] = $cliente->sex;
                  $data['image'] = $cliente->image;
                  $data['imageurl'] = $cliente->imageurl;

                  //recuperar los datos de Dirección
                 $clienteaddres = $this->useraddress_model->get_by_user($cliente->id_user,'2');
                 $data['key_country'] =  $clienteaddres->key_country;
                 $data['key_state'] =  $clienteaddres->key_state;
                 $data['key_cp'] =  $clienteaddres->key_cp;
                 $data['key_colony'] =  $clienteaddres->key_colony;
                 $data['street'] =  $clienteaddres->street;
                 $data['num_exterior'] =  $clienteaddres->num_exterior;
                 $data['num_inside'] =  $clienteaddres->num_inside;
                 $data['street_between1'] =  $clienteaddres->street_between1;
                 $data['street_between2'] =  $clienteaddres->street_between2;
                 $data['complement'] =  $clienteaddres->complement;


             			echo json_encode($data);

              }
      		}

          //elimina la imagen de un empleado
          public function deleteimage($nameImg)
        	{
                //eliminar imagenes de carpeta servidor
                unlink("uploads/customers/".$nameImg);
                unlink("uploads/thumbs/customers/".$nameImg);

        	}

    //elimina un producto por id
    public function delete($id)
  	{
      //comprobamos si es una petición ajax y existe la variable post id
        if($this->input->is_ajax_request())
        {
          $usuario = $this->customer_model->get_user_by_id($id);
      		$this->customer_model->delete($id);
          $this->useraddress_model->delete($usuario,'2');
      		echo json_encode(array("status" => TRUE));
        }
  	}

  }
  ?>
