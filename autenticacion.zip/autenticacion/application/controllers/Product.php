<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Product extends CI_Controller {  //cambiar CI por MY_Controller por la seguridad

    public function __construct()
    {
      parent::__construct();
      $this->load->library('ion_auth');

    //  $this->load->helper('url');
      $this->load->model('product_model');

      //carga las reglas de validacion de formulario
      $this->load->library('form_validation');
      //establece las reglas de validacion
      //$this->form_validation->set_rules('sku', 'sku', 'trim|required|is_unique[cat_products.sku]');
      $this->form_validation->set_rules('name', 'Nombre', 'trim|required');
      $this->form_validation->set_rules('price', 'Precio', 'required|numeric');
      $this->form_validation->set_rules('category', 'Category', 'required');

    }

    public function index()
    {
      //valida si esta logeado y si es administrador
			if ($this->ion_auth->logged_in())
			{
					if($this->ion_auth->is_admin())
					{
              $data['products'] = $this->product_model->get_all();

              //enviar datos y cargar
       				$data['the_view_content'] = $this->load->view('products/product_view', $data, TRUE);

       				$this->load->view('templates/auth_master_view', $data);
            }else{
              //enviar mensaje que no tiene permisos para esta opción
               echo 'no eres administrador';
            }
         }else{
            echo 'no estas logeado';
             //enviar mensaje de logearse o mostrar pantalla de login
            //	redirect('auth/login');
         }
    }

//crea o actualiza un producto
    public function add()
		{
        //comprobamos si es una petición ajax
    	 if($this->input->is_ajax_request())
      {
            if($this->input->post('id'))
            {
                $this->form_validation->set_rules('sku', 'sku', 'trim|required');
            }else{
                $this->form_validation->set_rules('sku', 'sku', 'trim|required|is_unique[cat_products.sku]');
            }

          //reglas de validaciones
          if($this->form_validation->run() == FALSE || !is_array($_FILES))
          {
            	//de esta forma devolvemos los errores de formularios
            	//con ajax desde codeigniter, aunque con php es lo mismo
            	$errors = array(
					           'sku' => form_error('sku'),
					           'name' => form_error('name'),
                     'price' => form_error('price'),
					           'respuesta' => 'error'
				               );
						//y lo devolvemos así para parsearlo con JSON.parse
		            echo json_encode($errors);
		            return FALSE;
			    }
          else{

            //registrar imagen para recuperar el nombre
            if($this->input->post('llevaImagen') == 'si')
            {
              //si es actualización buscar y eliminar imagen
                if($this->input->post('id'))
                {
                  if (file_exists($this->input->post('urlImagen'))) {
                    $imagen = $this->input->post('urlImagen');//uploads/products/wm-e-00001.jpg
                    $imagen = substr($imagen,17);//"wm-e-00001.jpg"
                    //eliminar imagen anterior
                    $this->deleteimage($imagen);
                  }
                  $MaxID = $this->input->post('id');
                }
                else{
                  $MaxID =  $this->product_model->max();
                }
                //cargar imagenes
                foreach($_FILES['images']['name'] as $name => $value)
                {
                     $file_name = explode(".", $_FILES['images']['name'][$name]);
                     $allowed_extension = array("jpg", "jpeg", "png", "gif");
                     if(in_array($file_name[1], $allowed_extension))
                     {
                          $new_name = 'P_'.$MaxID.'.'. $file_name[1];
                          $sourcePath = $_FILES["images"]["tmp_name"][$name];
                          $targetPath = "uploads/products/".$new_name;
                          if(move_uploaded_file($sourcePath, $targetPath))//guarda la imagen original
                          {
                              $this->create_thumbnail($new_name);//creamos un thumbnail de la imagen
                          }
                     }
                }

            }else{
              $new_name =  $imagen = $this->input->post('nameImagen');
              $targetPath =  $imagen = $this->input->post('urlImagen');
            }

            //realizar los registros en la base de datos
        			$data = array(
        					'sku' => $this->input->post('sku'),
        					'name' => $this->input->post('name'),
        					'description' => $this->input->post('description'),
        					'price' => $this->input->post('price'),
                  'id_category' => $this->input->post('category'),
                  'id_color' => $this->input->post('color'),
                  'name_image' => $new_name,
                  'url_image' => $targetPath,
                  'status' =>  $this->input->post('estatus'),

        				);
                //si estamos editando
            	if($this->input->post('id'))
            	{
                  //actualizar
                  $this->product_model->update(array('id' => $this->input->post('id')), $data);
              }
              else{
                  //guardar en la tabla productos
                  $productID = $this->product_model->add($data);
              }

        			echo json_encode(array("status" => TRUE));
          }

        }//fin si es ajax
		}//fin agregar

//recupera y muestra en pantalla los datos del producto seleccionado
    public function edit($id)
		{
      //comprobamos si es una petición ajax y existe la variable post id
        if($this->input->is_ajax_request())
        {
            $data = array();
      			//$data = $this->product_model->get_by_id($id);
            $product = $this->product_model->get_by_id($id);
            $data['id'] = $product->id;
            $data['sku'] = $product->sku;
            $data['name'] = $product->name;
            $data['description'] = $product->description;
            $data['price'] = $product->price;
            $data['category'] = $product->id_category;
            $data['color'] = $product->id_color;
            $data['imageurl'] = $product->url_image;
            $data['image'] = $product->name_image;
            $data['estatus'] = $product->status;

       			echo json_encode($data);

        }
		}

    //elimina un producto por id
    public function delete($id)
  	{
      //comprobamos si es una petición ajax y existe la variable post id
        if($this->input->is_ajax_request())
        {
          //recuperar nombre de la imagen
          $producto = $this->product_model->get_by_id($id);
          $this->deleteimage($producto->name_image);
      		$this->product_model->delete($id);
      		echo json_encode(array("status" => TRUE));
        }
  	}


    //FUNCIÓN PARA CREAR LA MINIATURA A LA MEDIDA QUE LE DIGAMOS
    function create_thumbnail($filename){
        $config['image_library'] = 'gd2';
        //CARPETA EN LA QUE ESTÁ LA IMAGEN A REDIMENSIONAR
        $config['source_image'] = 'uploads/products/'.$filename;
        $config['allowed_types'] = 'gif|jpg|png|jpeg';
        $config['create_thumb'] = TRUE;
        $config['maintain_ratio'] = TRUE;
        //CARPETA EN LA QUE GUARDAMOS LA MINIATURA
        $config['new_image']='uploads/thumbs/products/';
        $config['width'] = 64;//150;
        $config['height'] = 64;//150;
        $config['thumb_marker'] = '';//elimina el _thumb;
        $this->load->library('image_lib', $config);
        $this->image_lib->initialize($config);
        /*if (!$this->image_lib->resize()) {
          echo $this->image_lib->display_errors();
        }*/
        $this->image_lib->resize();
         $this->image_lib->clear();
    }

    //elimina la imagen de un producto por id
    public function deleteimage($nameImg)
  	{
        //eliminar imagenes de carpeta servidor
        unlink("uploads/products/".$nameImg);
        unlink("uploads/thumbs/products/".$nameImg);
  	}

    //autocomplete para busqueda por sku o nombre en ventas
    public function autocomplete()
    {
       $products =  $this->product_model->get_autocomplete();
      echo json_encode($products);
    }

    /*public function getdetails($id)
    {
      //comprobamos si es una petición ajax y existe la variable post id
        if($this->input->is_ajax_request())
        {
            //recuperar los detalles del producto
            $productdetails = $this->productdetails_model->get_by_id($id);
            echo json_encode($productdetails);
        }
    }*/

    public function getexistence($id,$idSize,$idColor)
    {
      //comprobamos si es una petición ajax y existe la variable post id
        if($this->input->is_ajax_request())
        {
            //recuperar los detalles del producto
            $existence = $this->productdetails_model->get_existence($id,$idSize,$idColor);

            echo json_encode($existence);

        }
    }

}

?>
