<?php
defined('BASEPATH') OR exit('No direct script access allowed');

//clase para control de inventario
class Production extends CI_Controller {  //.....aqui me quede

    public function __construct()
    {
      parent::__construct();
      $this->load->library('ion_auth');

      $this->load->model('production_model');

      //carga las reglas de validacion de formulario
      $this->load->library('form_validation');

    }

    public function index()
    {
        //valida si esta logeado y si es administrador
  			if ($this->ion_auth->logged_in())
  			{
          if($this->ion_auth->is_admin())
          {
              $data = array();
              //enviar datos y cargar
              $data['the_view_content'] = $this->load->view('production/costs_view', $data ,TRUE);

       				$this->load->view('templates/auth_master_view', $data);
            }else{
              //enviar mensaje que no tiene permisos para esta opción
               echo 'no eres administrador';
            }

         }else{
            echo 'no estas logeado';
             //enviar mensaje de logearse o mostrar pantalla de login
            //	redirect('auth/login');
         }
    }

    public function add()
    {
      //comprobamos si es una petición ajax
      if($this->input->is_ajax_request())
      {
          //establece las reglas de validacion
          $this->form_validation->set_rules('id_product', 'Producto', 'trim|required');
          $this->form_validation->set_rules('workforce', 'Mano de obra', 'trim|required');
          $this->form_validation->set_rules('gastos', 'Gastos Fijos', 'trim|required');
          $this->form_validation->set_rules('total', 'Total de produccion', 'trim|required');
          //reglas de validaciones
          if($this->form_validation->run() == FALSE)
          {
              //de esta forma devolvemos los errores de formularios
              //con ajax desde codeigniter, aunque con php es lo mismo
              $errors = array(
                     'producto' => form_error('id_product'),
                      'respuesta' => 'error'
                       );
            //y lo devolvemos así para parsearlo con JSON.parse
                echo json_encode($errors);
                return FALSE;
          }
          else{
              //recuperar los detalles
              $detalles['arrDetalles']  = json_decode($this->input->post('arrDetalles'));
                $user = $this->ion_auth->user()->row();//obtiene el usuario logeado
                $data = array(
                    'id_product' => $this->input->post('id_product'),
                    'workforce' =>   $this->input->post('workforce'),
                    'fixed_expence' => $this->input->post('gastos'),
                    'description_workforce' => $this->input->post('descripcion_workforce'),
                    'description_fixed' => $this->input->post('descripcion_gastos'),
                    'total' => $this->input->post('total'),
                    'id_user' => $user->id,
                  );

                  //guardar en la tabla
                  $this->production_model->add($detalles, $data,$user->id);

              echo json_encode(array("status" => TRUE, 'Usuario' =>$user));
          }
      }//fin ajax
    }

  }
  ?>
