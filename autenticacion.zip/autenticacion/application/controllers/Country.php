<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Country extends CI_Controller {  

    public function __construct()
    {
      parent::__construct();
      //$this->load->helper('url');
      $this->load->model('country_model');
    }

    public function index()
    {
        $data['countries'] = $this->country_model->get_all();

        //enviar datos y cargar
 				$data['the_view_content'] = $this->load->view('countries/country_view', $data, TRUE);

 				$this->load->view('templates/auth_master_view', $data);
    }


    //recupera y muestra en pantalla los datos del producto seleccionado
    public function get_all()
		{
        //comprobamos si es una petición ajax
        if($this->input->is_ajax_request())
        {
            $data = array();
            $data = $this->country_model->get_all();

       			echo json_encode($data);

        }
		}



}

?>
