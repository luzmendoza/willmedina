<?php
defined('BASEPATH') OR exit('No direct script access allowed');

//session_start(); // incio de  sesiones.

class User extends MY_Controller {

	function __construct()
    {
        parent::__construct();
  		$this->load->library('ion_auth');

			//modificaciones para ajax
		//	$this->load->helper('url');
			$this->load->model('user_model');
      //carga las reglas de validacion de formulario
      $this->load->library('form_validation');
  	}

    public function index()
    {
			//valida si esta logeado y si es administrador
			if ($this->ion_auth->logged_in())
			{
					if($this->ion_auth->is_admin())
					{
						//$this->load->view('welcome_message');
					// $data['users'] = $this->user_model->get_all();
					 $data['users'] = $this->ion_auth->users()->result();

					 //enviar datos y cargar
					 $data['the_view_content'] = $this->load->view('user/user_view', $data, TRUE);

					 $this->load->view('templates/auth_master_view', $data);
				 }else{
					 //enviar mensaje que no tiene permisos para esta opción
					  echo 'no eres administrador';
				 }
			}else{
				 echo 'no estas logeado';
					//enviar mensaje de logearse o mostrar pantalla de login
				 //	redirect('auth/login');
			}

    }

		//crear nuevo usuario.. ajax desde opcion administrador
		public function add()
		{
				//validacion si es ajax-loader
				if($this->input->is_ajax_request())
				{
					//establece reglas de validacion
						$this->form_validation->set_rules('first_name', 'First name','trim|required');
						$this->form_validation->set_rules('last_name', 'Last name','trim|required');
						$this->form_validation->set_rules('email','Email','trim|valid_email|required');
						if(!$this->input->post('id')) //se agrega la validacion cuando es nuevo usuario
						{
							$this->form_validation->set_rules('username','Username','trim|required|is_unique[users.username]');
							$this->form_validation->set_rules('password','Password','trim|min_length[8]|max_length[20]|required');
							$this->form_validation->set_rules('confirm_password','Confirm password','trim|matches[password]|required');
						}

						if($this->form_validation->run()===FALSE)
						{
							//de esta forma devolvemos los errores de formularios
							//con ajax desde codeigniter, aunque con php es lo mismo
							$errors = array(
										 'first_name' => form_error('first_name'),
										 'last_name' => form_error('last_name'),
										 'username' => form_error('username'),
										 'email' => form_error('email'),
										 'password' => form_error('password'),
									   'confirm_password' => form_error('confirm_password'),
										 'respuesta' => 'error'
											 );
						   //y lo devolvemos así para parsearlo con JSON.parse
								echo json_encode($errors);
								return FALSE;

						}
						else
						{
								$first_name = $this->input->post('first_name');
								$last_name = $this->input->post('last_name');
								$username = $this->input->post('username');
								$email = $this->input->post('email');
								$password = $this->input->post('password');

								$additional_data = array(
										'first_name' => $first_name,
										'last_name' => $last_name
										//agregar aqui apellido materno
								);

								$gpAdmin = (bool) $this->input->post('ckbAdmin');
								$gpEmpleado = (bool) $this->input->post('ckbEmploye');
								$gpGeneral = (bool) $this->input->post('ckbmember');

							  $grupos_data = array();
								if($gpAdmin)
								{
									 	array_push($grupos_data, "1");
								}
								if($gpEmpleado)
								{
										array_push($grupos_data, "3");
								}
								if($gpGeneral)
								{
										array_push($grupos_data, "2");
								}

								//si estamos editando
            	if($this->input->post('id'))
            	{
									$ID = $this->input->post('id');
									//actualizar
									$this->user_model->update($ID,$first_name,$last_name,$email,0);
									$this->user_model->delete_fromgroup($ID);

									if($this->ion_auth->add_to_group($grupos_data, $ID))
							 		{
												$mensaje = 'La cuenta ha sido actualizada.';
												echo json_encode(array("status" => TRUE, "mensaje" => $mensaje));
									}else{
										$mensaje = 'Error al actualizar los grupos.';
										echo json_encode(array("status" => FALSE, "mensaje" => $mensaje));
									}


							}
							else //nuevo usuario
							{
								//$this->load->library('ion_auth');
								if($this->ion_auth->register($username,$password,$email,$additional_data,$grupos_data))
								{
										$_SESSION['auth_message'] =   'La cuenta ha sido creada con éxito. Puede iniciar Sesión ahora.';//'The account has been created. You may now login.';
										$mensaje = 'La cuenta ha sido creada con éxito';
										$this->session->mark_as_flash('auth_message');
										//redirect('user/login');
										echo json_encode(array("status" => TRUE, "mensaje" => $mensaje));
								}
								else
								{
										$_SESSION['auth_message'] = $this->ion_auth->errors();
										$this->session->mark_as_flash('auth_message');
										//redirect('register');
										echo json_encode(array("status" => FALSE, "mensaje" => $this->ion_auth->errors()));
								}
							}

								//echo json_encode(array("status" => TRUE));
						}
				}//fin is_ajax_request
		}

		//recupera y muestra en pantalla los datos del usuario seleccionado
		    public function edit($id)
				{
		      //comprobamos si es una petición ajax y existe la variable post id
		        if($this->input->is_ajax_request())
		        {
		            $data = array();
		      			//$data = $this->product_model->get_by_id($id);
		            $user= $this->user_model->get_by_id($id);
		            $data['id'] = $user->id;
		            $data['username'] = $user->username;
		            $data['first_name'] = $user->first_name;
		            $data['last_name'] = $user->last_name;
		            $data['email'] = $user->email;
		            $data['password'] = $user->password;

								$usergroup = $this->user_model->get_groups_by_userid($id);
								//formatear a json
								$data['arrGrupos']  =  $usergroup;//json_encode($productdetails);

		       			echo json_encode($data);
		        }
				}

		//eliminar usuario y datos asociados
		public function delete($id)
		{
				if($this->ion_auth->delete_user($id))
				{
						$_SESSION['auth_message'] =   'Usuario eliminado';
						$mensaje = 'Usuario eliminado con éxito.';
						$this->session->mark_as_flash('auth_message');
						echo json_encode(array("status" => TRUE, "mensaje" => $mensaje));
				}
				else
				{
						$_SESSION['auth_message'] = $this->ion_auth->errors();
						$this->session->mark_as_flash('auth_message');
						echo json_encode(array("status" => FALSE, "mensaje" => $this->ion_auth->errors()));
				}
		}

		//autocomplete utilizado para recuperar datos en empleados y clientes
		public function autocomplete()
		{
			 $users = $this->ion_auth->users()->result();
			echo json_encode($users);
		}



		public function login_ajax()
		{
				if($this->input->is_ajax_request())
				{
						//echo 'Here we will make the login form';
						$this->data['title'] = "Login";

					 // $this->load->library('form_validation');
						$this->form_validation->set_rules('username_ajax', 'Username', 'trim|required');
						$this->form_validation->set_rules('password_ajax', 'Password', 'required');

						if ($this->form_validation->run() === FALSE)
						{
								 //$this->load->helper('form');
								 //$this->render('user/login_view');
								 $errors = array(
	 					           'username' => form_error('username_ajax'),
	 					           'password' => form_error('password_ajax'),
	 					            'respuesta' => 'error',
												"status" => FALSE,
	 				               );
	 						//y lo devolvemos así para parsearlo con JSON.parse
	 		            echo json_encode($errors);
	 		            return FALSE;
						}
						else
						{
								$remember = (bool) $this->input->post('remember_ajax');
								if ($this->ion_auth->login($this->input->post('username_ajax'), $this->input->post('password_ajax'), $remember))
								{
									//recuperar datos del usuario para ver si es admin o cliente u otra cosa  y cargar diferente
										if( $this->ion_auth->is_admin() )//si es administrador
										{
											//redirect('dashboard');
												echo json_encode(array("status" => TRUE, "tipo" => 'admin'));
										}else  {
											//verificar si es empleado
											//redirect('dashboard/employee');
											echo json_encode(array("status" => TRUE, "tipo" => 'employe'));
										/*}else{
											//si es cliente se queda ahi
												echo json_encode(array("status" => TRUE));*/
										}
								}
								else
								{
										$_SESSION['auth_message'] = $this->ion_auth->errors();
										$this->session->mark_as_flash('auth_message');
									//	redirect('user/login');
										$errors = array(
													'username' => form_error('username_ajax'),
													'password' => form_error('password_ajax'),
													 'respuesta' => 'error',
													 	"status" => FALSE,
													  'error' => $this->ion_auth->errors()//podria marcar error
														);
								 //y lo devolvemos así para parsearlo con JSON.parse
										 echo json_encode($errors);
										 return FALSE;

								}
						}
				}
		}


//**********************************************sin ajax
    public function login()
    {
				//echo 'Here we will make the login form';
        $this->data['title'] = "Login";

		   // $this->load->library('form_validation');
        $this->form_validation->set_rules('username', 'Username', 'trim|required');
        $this->form_validation->set_rules('password', 'Password', 'required');

        if ($this->form_validation->run() === FALSE)
        {
  			     $this->load->helper('form');
             $this->render('user/login_view');
        }
        else
        {
            $remember = (bool) $this->input->post('remember');
            if ($this->ion_auth->login($this->input->post('username'), $this->input->post('password'), $remember))
            {
							//recuperar datos del usuario para ver si es admin o cliente u otra cosa  y cargar diferente
								if( $this->ion_auth->is_admin() )//si es administrador
								{
                	redirect('dashboard');
							  }else {
							  	//verificar si es empleado
									redirect('dashboard/employee');
							  }
            }
            else
            {
                $_SESSION['auth_message'] = $this->ion_auth->errors();
                $this->session->mark_as_flash('auth_message');
                redirect('user/login');
            }
        }
    }

    public function logout()
    {
        //echo 'here we will do the logout';
        $this->ion_auth->logout();
				session_destroy();
	       redirect('user/login');
    }


		//***********************************PERFILES*****************************************//
		public function perfil()
		{
			//valida si esta logeado y si es administrador
			if ($this->ion_auth->logged_in())
			{
					if($this->ion_auth->is_admin())
					{
						//buscar informacion del usuario
					 $user = $this->ion_auth->user()->row();//obtiene el usuario logeado
					// $user= $this->user_model->get_by_id($user->id);
					 $data['id'] = $user->id;
					 $data['username'] = $user->username;
					 $data['first_name'] = $user->first_name;
					 $data['last_name'] = $user->last_name;
					 $data['email'] = $user->email;
					 $data['phone'] =$user->phone;

					 //enviar datos y cargar
					 $data['the_view_content'] = $this->load->view('user/perfil_view', $data, TRUE);

					 $this->load->view('templates/auth_master_view', $data);
				 }else{
					 //enviar mensaje que no tiene permisos para esta opción
						echo 'no eres administrador';
				 }
			}else{
				 echo 'no estas logeado';
					//enviar mensaje de logearse o mostrar pantalla de login
				 //	redirect('auth/login');
			}

		}

		//actualiza usuario.. ajax desde opcion perfil
		public function update()
		{
				//validacion si es ajax-loader
				if($this->input->is_ajax_request())
				{

					//establece reglas de validacion
					$this->form_validation->set_rules('first_name', 'First name','trim|required');
						$this->form_validation->set_rules('last_name', 'Last name','trim|required');
						$this->form_validation->set_rules('email','Email','trim|valid_email|required');
						$this->form_validation->set_rules('phone','Telefono','trim|numeric');

						if($this->form_validation->run()===FALSE)
						{
							//de esta forma devolvemos los errores de formularios
							//con ajax desde codeigniter, aunque con php es lo mismo
							$errors = array(
										 'first_name' => form_error('first_name'),
										 'last_name' => form_error('last_name'),
										 'email' => form_error('email'),
										 'phone' => form_error('phone'),
										 'respuesta' => 'error'
											 );
						   //y lo devolvemos así para parsearlo con JSON.parse
								echo json_encode($errors);
								return FALSE;

						}
						else
						{
								$first_name = $this->input->post('first_name');
								$last_name = $this->input->post('last_name');
								$email = $this->input->post('email');
								$phone = $this->input->post('phone');

								//si estamos editando
            	if($this->input->post('id_user'))
            	{
									$ID = $this->input->post('id_user');
										//actualizar
										$this->user_model->update($ID,$first_name,$last_name,$email,$phone);
										$mensaje = 'La cuenta ha sido actualizada.';
							}

						}
					 echo json_encode(array("status" => TRUE));
				}//fin is_ajax_request
		}

}
?>
