<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Color extends CI_Controller {

    public function __construct()
    {
      parent::__construct();
      //$this->load->helper('url');
      $this->load->model('color_model');
    }

    public function index()
    {
        $data['colors'] = $this->color_model->get_all();

        //enviar datos y cargar
 				$data['the_view_content'] = $this->load->view('colors/color_view', $data, TRUE);

 				$this->load->view('templates/auth_master_view', $data);
    }


    //recupera y muestra en pantalla los datos del producto seleccionado
    public function get_all()
		{
        //comprobamos si es una petición ajax
        if($this->input->is_ajax_request())
        {
            $data = array();
            $data = $this->color_model->get_all();

       			echo json_encode($data);

        }
		}



}

?>
