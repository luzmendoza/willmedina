<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Employe extends CI_Controller {

    public function __construct()
    {
      parent::__construct();
      $this->load->library('ion_auth');

    //  $this->load->helper('url');
      $this->load->model('employe_model');
      $this->load->model('useraddress_model');
      $this->load->model('userbranch_model');
      $this->load->model('branchoffice_model');
      $this->load->model('user_model');

      //carga las reglas de validacion de formulario
      $this->load->library('form_validation');
      //establece las reglas de validacion
    //  $this->form_validation->set_rules('first_name', 'Nombre', 'trim|required');
    //  $this->form_validation->set_rules('last_name', 'Apellido Paterno', 'trim|required');
      $this->form_validation->set_rules('cell_phone', 'Celular', 'required|numeric');
      $this->form_validation->set_rules('birth_date', 'Fecha Nacimiento', 'required|date');//establecer formato fecha

      $this->form_validation->set_rules('country', 'País', 'trim|required');
      $this->form_validation->set_rules('cp', 'Codigo Postal', 'required|numeric|greater_than[0]');
      $this->form_validation->set_rules('street', 'Calle', 'trim|required');
      $this->form_validation->set_rules('num_exterior', 'No. Exterior', 'required|numeric|greater_than[0]');

      $this->form_validation->set_rules('id_sucursal', 'Sucursal', 'trim|required');

    }

    public function index()
    {
      //valida si esta logeado y si es administrador
			if ($this->ion_auth->logged_in())
			{
					if($this->ion_auth->is_admin())
					{
              $data['employees'] = $this->employe_model->get_all();

              //enviar datos y cargar
       				$data['the_view_content'] = $this->load->view('employees/employe_view', $data, TRUE);

       				$this->load->view('templates/auth_master_view', $data);
          }else{
            //enviar mensaje que no tiene permisos para esta opción
             echo 'no eres administrador';
          }
       }else{
          echo 'no estas logeado';
           //enviar mensaje de logearse o mostrar pantalla de login
          //	redirect('auth/login');
       }

    }//fin index


    //crea o actualiza un empleado
      public function add()
  		{
          //comprobamos si es una petición ajax
      	if($this->input->is_ajax_request())
        {
          if($this->input->post('id'))
          {
            $this->form_validation->set_rules('id_user', 'Usuario', 'required');
          }else{
            $this->form_validation->set_rules('id_user', 'Usuario', 'required|is_unique[cat_employees.id_user]');
          }

          //reglas de validaciones
          if($this->form_validation->run() == FALSE)
          {
            	//de esta forma devolvemos los errores de formularios
            	//con ajax desde codeigniter, aunque con php es lo mismo
            	$errors = array(
					           'id_user' => form_error('id_user'),
                     //'phone' => form_error('phone'),
					           'cell_phone' => form_error('cell_phone'),
                     'birth_date' => form_error('birth_date'),
                     //'imagen' => form_error('imagen'),
                     //sex, image, key_employe
					            'country' => form_error('country'),
                      'cp' => form_error('cp'),
                      'street' => form_error('street'),
                      'num_exterior' => form_error('num_exterior'),
                      'id_sucursal' => form_error('id_sucursal'),
					            'respuesta' => 'error'
				               );
						//y lo devolvemos así para parsearlo con JSON.parse
		            echo json_encode($errors);
		            return FALSE;
			    }
          else{
            	$targetPath = '';
              $new_name = '';

              if($this->input->post('id'))
              {
                  $targetPath = $this->input->post('urlImagen');
                  $new_name = $this->input->post('nameImagen');
                  $keyEmploye = $this->input->post('num_emp');
              }else{
                //generar clave Empleado
                $maxEmpleado = $this->employe_model->count();
                $keyEmploye = str_pad($maxEmpleado, 5, "0", STR_PAD_LEFT);
                $keyEmploye = "wm-e-".$keyEmploye;
              }

              if($this->input->post('llevaImagen') == 'si')
              {
                  if($this->input->post('id'))
                  {
                    if (file_exists($this->input->post('urlImagen'))) {
                      $imagen = $this->input->post('urlImagen');//uploads/employees/wm-e-00001.jpg
                      $imagen = substr($imagen,18);//"wm-e-00001.jpg"
                      //eliminar imagen anterior
                      $this->deleteimage($imagen);
                    }

                  }
                  //cargar imagenes
                  foreach($_FILES['images']['name'] as $name => $value)
                  {
                       $file_name = explode(".", $_FILES['images']['name'][$name]);
                       $allowed_extension = array("jpg", "jpeg", "png", "gif");
                       if(in_array($file_name[1], $allowed_extension))
                       {
                            $new_name = $keyEmploye.'.'. $file_name[1];
                            $sourcePath = $_FILES["images"]["tmp_name"][$name];
                            $targetPath = "uploads/employees/".$new_name;
                            if(move_uploaded_file($sourcePath, $targetPath))//guarda la imagen original
                            {
                                $this->create_thumbnail($new_name);//creamos un thumbnail de la imagen
                            }
                       }
                  }
              }



            // $birthdate = $this->FormatoFechaSQL( str_replace($this->input->post('birth_date'),"/","-"));
            //realizar los registros en la base de datos
        			$data = array(
        					'id_user' => $this->input->post('id_user'),
        					'phone' => $this->input->post('phone'),
        					'cell_phone' => $this->input->post('cell_phone'),
        					'birth_date' => $this->input->post('birth_date'),
                  'sex' => $this->input->post('sex'),
                  'imageurl' => $targetPath,
                  'image' =>$new_name,
                  'key_employe' => $keyEmploye,
        				);

                $data_address = array(
                    'id_user' => $this->input->post('id_user'),
                    'type_user' => '1',
          					'key_country' => $this->input->post('country'),
          					'key_cp' => $this->input->post('cp'),
          					'key_state' => $this->input->post('state'),
          					'key_colony' =>$this->input->post('colony'),
                    'street' => $this->input->post('street'),
                    'num_exterior' => $this->input->post('num_exterior'),
                    'num_inside' => $this->input->post('num_inside'),
                    'street_between1' => $this->input->post('street1'),
                    'street_between2' => $this->input->post('street2'),
                    'complement' => $this->input->post('complement'),
          				);
                //si estamos editando
            	if($this->input->post('id'))
            	{
                  //actualizar
                  $this->employe_model->update(array('id' => $this->input->post('id')), $data);
                  $this->useraddress_model->update(array('id_user' => $this->input->post('id_user')), $data_address);
                  $this->userbranch_model->update(array('id_user' => $this->input->post('id_user')), $this->input->post('id_sucursal'));
              }
              else{
                  //guardar en la tabla
                  $employeID = $this->employe_model->add($data);
                  $direeID =$this->useraddress_model->add($data_address);
                  $sucID =$this->userbranch_model->add($this->input->post('id_user'),$this->input->post('id_sucursal'));
              }

        			echo json_encode(array("status" => TRUE));
          }
        }//fin ajax
      }//fin add

      //FUNCIÓN PARA CREAR LA MINIATURA A LA MEDIDA QUE LE DIGAMOS
      public function create_thumbnail($filename){
          $config['image_library'] = 'gd2';
          //CARPETA EN LA QUE ESTÁ LA IMAGEN A REDIMENSIONAR
          $config['source_image'] = 'uploads/employees/'.$filename;
          $config['allowed_types'] = 'gif|jpg|png|jpeg';
          $config['create_thumb'] = TRUE;
          $config['maintain_ratio'] = TRUE;
          //CARPETA EN LA QUE GUARDAMOS LA MINIATURA
          $config['new_image']='uploads/thumbs/employees/';
          $config['width'] = 150;//150;
          $config['height'] = 150;//150;
          $config['thumb_marker'] = '';//elimina el _thumb;
          $this->load->library('image_lib', $config);
          $this->image_lib->initialize($config);
          /*if (!$this->image_lib->resize()) {
            echo $this->image_lib->display_errors();
          }*/
          $this->image_lib->resize();
           $this->image_lib->clear();
      }

      //modifica una fecha a formato sql valido
      public function FormatoFechaSQL($dateString) {
        $date = new DateTime($dateString);
        $fecha = $date->format('Y-m-d');
      	return $fecha;
      }

      //recupera y muestra en pantalla los datos del empleado seleccionado
          public function edit($id)
      		{
            //comprobamos si es una petición ajax y existe la variable post id
              if($this->input->is_ajax_request())
              {
                  $data = array();
            			//$data = $this->product_model->get_by_id($id);
                  $employe = $this->employe_model->get_by_id($id);
                  $data['id'] = $employe->id;
                  $data['id_user'] = $employe->id_user;
                  $data['first_name'] = $employe->first_name;
                  $data['last_name'] = $employe->last_name;
                  $data['phone'] = $employe->phone;
                  $data['cell_phone'] = $employe->cell_phone;
                  $data['birth_date'] = $employe->birth_date;
                  $data['sex'] = $employe->sex;
                  $data['key_employe'] = $employe->key_employe;
                  $data['image'] = $employe->image;
                  $data['imageurl'] = $employe->imageurl;

                  //recuperar los datos de Dirección
                 $employeaddres = $this->useraddress_model->get_by_user($employe->id_user, '1');
                 $data['key_country'] =  $employeaddres->key_country;
                 $data['key_state'] =  $employeaddres->key_state;
                 $data['key_cp'] =  $employeaddres->key_cp;
                 $data['key_colony'] =  $employeaddres->key_colony;
                 $data['street'] =  $employeaddres->street;
                 $data['num_exterior'] =  $employeaddres->num_exterior;
                 $data['num_inside'] =  $employeaddres->num_inside;
                 $data['street_between1'] =  $employeaddres->street_between1;
                 $data['street_between2'] =  $employeaddres->street_between2;
                 $data['complement'] =  $employeaddres->complement;

                 $sucursal = $this->branchoffice_model->get_by_id($employe->sucursal);
                 $data['id_sucursal'] = $sucursal->id;
                 $data['sucursal'] = $sucursal->name;

             			echo json_encode($data);

              }
      		}

          //elimina la imagen de un empleado
          public function deleteimage($nameImg)
        	{
                //eliminar imagenes de carpeta servidor
                unlink("uploads/employees/".$nameImg);
                unlink("uploads/thumbs/employees/".$nameImg);

        	}

    //elimina un producto por id
    public function delete($id)
  	{
      //comprobamos si es una petición ajax y existe la variable post id
        if($this->input->is_ajax_request())
        {
          $usuario = $this->employe_model->get_user_by_id($id);
      		$this->employe_model->delete($id);
          $this->useraddress_model->delete($usuario,'1');
          $this->userbranch_model->delete($usuario);
      		echo json_encode(array("status" => TRUE));
        }
  	}

    public function perfil()
    {
        //valida si esta logeado y si es administrador
        if ($this->ion_auth->logged_in())
        {
              //buscar informacion del usuario
             $user = $this->ion_auth->user()->row();//obtiene el usuario logeado
             $data['email'] = $user->email;
             $data['username'] = $user->username;

           $employe = $this->employe_model->get_by_userid($user->id);
             $data['id_employe'] = $employe->id;
             $data['id_user'] = $employe->id_user;
             $data['first_name'] = $employe->first_name;
             $data['last_name'] = $employe->last_name;
             $data['phone'] = $employe->phone;
             $data['cell_phone'] = $employe->cell_phone;
             $data['birth_date'] = $employe->birth_date;
             $data['sex'] = $employe->sex;
             $data['key_employe'] = $employe->key_employe;
             $data['image'] = $employe->image;
             $data['imageurl'] = $employe->imageurl;

             //recuperar los datos de Dirección
            $employeaddres = $this->useraddress_model->get_by_user($employe->id_user, '1');
            $data['key_country'] =  $employeaddres->key_country;
            $data['key_state'] =  $employeaddres->key_state;
            $data['key_cp'] =  $employeaddres->key_cp;
            $data['key_colony'] =  $employeaddres->key_colony;
            $data['street'] =  $employeaddres->street;
            $data['num_exterior'] =  $employeaddres->num_exterior;
            $data['num_inside'] =  $employeaddres->num_inside;
            $data['street_between1'] =  $employeaddres->street_between1;
            $data['street_between2'] =  $employeaddres->street_between2;
            $data['complement'] =  $employeaddres->complement;

             //enviar datos y cargar
             $data['the_view_content'] = $this->load->view('employees/perfil_view', $data, TRUE);

             $this->load->view('templates/auth_master_view', $data);

        }else{
           echo 'no estas logeado';
            //enviar mensaje de logearse o mostrar pantalla de login
           //	redirect('auth/login');
        }
    }

    //crea o actualiza un empleado
      public function update()
      {
          //comprobamos si es una petición ajax
        if($this->input->is_ajax_request())
        {

          //reglas de validaciones
          if($this->form_validation->run() == FALSE)
          {
              //de esta forma devolvemos los errores de formularios
              //con ajax desde codeigniter, aunque con php es lo mismo
              $errors = array(
                     'cell_phone' => form_error('cell_phone'),
                     'birth_date' => form_error('birth_date'),
                      'country' => form_error('country'),
                      'cp' => form_error('cp'),
                      'street' => form_error('street'),
                      'num_exterior' => form_error('num_exterior'),
                      'respuesta' => 'error'
                       );
            //y lo devolvemos así para parsearlo con JSON.parse
                echo json_encode($errors);
                return FALSE;
          }
          else{
              $keyEmploye =  $this->input->post('key_employe');

              if($this->input->post('urlImagen') !='')
              {
                $urlImagen = $this->input->post('urlImagen');
                $base = base_url();
                $baselen = strlen($base);
                $targetPath = substr($urlImagen, $baselen);
              }else{
                $targetPath = $this->input->post('urlImagen');
              }
              $new_name = $this->input->post('nameImagen');


              if($this->input->post('llevaImagen') == 'si')
              {
                    if (file_exists($targetPath)) {
                      $imagen = $targetPath;//uploads/employees/wm-e-00001.jpg
                      $imagen = substr($imagen,18);//"wm-e-00001.jpg"
                      //eliminar imagen anterior
                      $this->deleteimage($imagen);
                    }
                  //cargar imagenes
                  foreach($_FILES['images']['name'] as $name => $value)
                  {
                       $file_name = explode(".", $_FILES['images']['name'][$name]);
                       $allowed_extension = array("jpg", "jpeg", "png", "gif");
                       if(in_array($file_name[1], $allowed_extension))
                       {
                            $new_name = $keyEmploye.'.'. $file_name[1];
                            $sourcePath = $_FILES["images"]["tmp_name"][$name];
                            $targetPath = "uploads/employees/".$new_name;
                            if(move_uploaded_file($sourcePath, $targetPath))//guarda la imagen original
                            {
                                $this->create_thumbnail($new_name);//creamos un thumbnail de la imagen
                            }
                       }
                  }
              }



            // $birthdate = $this->FormatoFechaSQL( str_replace($this->input->post('birth_date'),"/","-"));
            //realizar los registros en la base de datos
              $data = array(
                  'phone' => $this->input->post('phone'),
                  'cell_phone' => $this->input->post('cell_phone'),
                  'birth_date' => $this->input->post('birth_date'),
                  'sex' => $this->input->post('sex'),
                  'imageurl' => $targetPath,
                  'image' =>$new_name,
                );

                $data_address = array(
                    'id_user' => $this->input->post('id_user'),
                    'type_user' => '1',
                    'key_country' => $this->input->post('country'),
                    'key_cp' => $this->input->post('cp'),
                    'key_state' => $this->input->post('state'),
                    'key_colony' =>$this->input->post('colony'),
                    'street' => $this->input->post('street'),
                    'num_exterior' => $this->input->post('num_exterior'),
                    'num_inside' => $this->input->post('num_inside'),
                    'street_between1' => $this->input->post('street1'),
                    'street_between2' => $this->input->post('street2'),
                    'complement' => $this->input->post('complement'),
                  );

                  $first_name = $this->input->post('first_name');
  								$last_name = $this->input->post('last_name');
  								$email = $this->input->post('email');
  								$phone = $this->input->post('phone');

              //actualizar
              $this->user_model->update($this->input->post('id_user'),$first_name,$last_name,$email,$phone);
              $this->employe_model->update(array('id' => $this->input->post('id_employe')), $data);
              $this->useraddress_model->update(array('id_user' => $this->input->post('id_user')), $data_address);


              echo json_encode(array("status" => TRUE));
          }
        }//fin ajax
      }//fin add

  }
  ?>
