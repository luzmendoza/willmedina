<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Sales extends CI_Controller {  //cambiar CI por MY_Controller por la seguridad

    public function __construct()
    {
      parent::__construct();
      $this->load->library('ion_auth');

      //$this->load->helper('url');
      $this->load->model('sales_model');
      $this->load->model('stockproduct_model');
      $this->load->model('cashmovements_model');
      $this->load->model('branchoffice_model');


    }

    public function index()
    {
        //valida si esta logeado y si es administrador
  			if ($this->ion_auth->logged_in())
  			{
              $data['sales'] = $this->sales_model->get_all();
              $user = $this->ion_auth->user()->row();//obtiene el usuario logeado
              $data['user'] = $user->first_name . ' ' . $user->last_name;
              $sucursal = $this->branchoffice_model->get_by_iduser($user->id);
              $data['id_sucursal'] = $sucursal->id;

              //enviar datos y cargar
              $data['the_view_content'] = $this->load->view('sales/salescandev_view', $data ,TRUE);

       				$this->load->view('templates/auth_master_view', $data);

         }else{
            echo 'no estas logeado';
             //enviar mensaje de logearse o mostrar pantalla de login
            //	redirect('auth/login');
         }
    }

    public function ventas()
    {
        //valida si esta logeado y si es administrador
  			if ($this->ion_auth->logged_in())
  			{
              $data = array();
              $user = $this->ion_auth->user()->row();//obtiene el usuario logeado
              $data['user'] = $user->first_name . ' ' . $user->last_name;
              $sucursal = $this->branchoffice_model->get_by_iduser($user->id);
              $data['id_sucursal'] = $sucursal->id;
              $data['sucursal'] = $sucursal->name;
              //obtener datos movimientos de caja para el inicio del dia
              $data['diainicio'] = $this->cashmovements_model->get_startday($sucursal->id);
              $data['diafin'] = $this->cashmovements_model->get_endday($sucursal->id);
              //mostrar pantalla
              $data['the_view_content'] = $this->load->view('sales/sales_view', $data ,TRUE);
       				$this->load->view('templates/auth_master_view', $data);

         }else{
            echo 'no estas logeado';
         }
    }
    public function add()
    {
      //comprobamos si es una petición ajax
      if($this->input->is_ajax_request())
      {
          try
          {
            //recuperar los detalles
            $detalles['arrDetalles']  = json_decode($this->input->post('arrDetallesPagar'));
            $tipopago = $this->input->post('tipopago');
            $total = $this->input->post('totalpagar');

            $user = $this->ion_auth->user()->row();//obtiene el usuario logeado
            if (!$this->ion_auth->in_group('members')) //empleado O administrador
        		{
        			 //tipo de venta en linea
               $tipoVenta = '2';
        		}else{
              //tipo de venta en tienda
              $tipoVenta = '1';
            }

            $factura = $this->sales_model->max();
            $keyFact = str_pad($factura, 8, "0", STR_PAD_LEFT);
            $factura = "WM".$keyFact;

            $data = array('sales_check' => $factura,
                          'id_user' => $user->id,
                           'type_sale' => $tipoVenta,//tienda o linea
                          'type_buy' => '1', //contado por el momento es el unico pago... o credito
                          'type_payment' => $tipopago,//efectivo o tarjeta
                          'total' =>$total ,
                          'status' => 1,
                          'id_branchoffice' => $this->input->post('sucursal'),
                        );

            //guardar en la tabla
            $idventa = $this->sales_model->add($data);
            $this->sales_model->adddetails($detalles,$idventa,$user->id,$this->input->post('sucursal'));
            //registrar el movimiento de caja
            $this->cashmovements_model->add('1','2',$total,'',$user->id,$this->input->post('sucursal'));

            echo json_encode(array("status" => TRUE, 'Usuario' =>$user));
          } catch (Exception $e) {
              //echo 'Excepción capturada: ',  $e->getMessage(), "\n";
              echo json_encode(array("status" => FALSE, 'Usuario' =>$user, 'mensaje' => 'Ocurrio un error al realizar la venta'));
          }

      }//fin ajax
    }

    //cancelacion de venta
    public function cancelar($id,$idsuc)
  	{
      //comprobamos si es una petición ajax y existe la variable post id
        if($this->input->is_ajax_request())
        {
          $user = $this->ion_auth->user()->row();//obtiene el usuario logeado
          $venta = $this->sales_model->get_by_id($id);
      		$this->sales_model->cancel($id);//cancela la nota principal
          //salida de dinero de la caja
          $this->cashmovements_model->add('2','3',$venta->total,'',$user->id,$idsuc);
          //dar entrada a los articulos
          $data['salesdetails'] = $this->sales_model->get_details($id);
          $this->stockproduct_model->update_stock($data['salesdetails'],$user->id,$user->id,$this->input->post('sucursal'));
      		echo json_encode(array("status" => TRUE));
        }
  	}

    //obtener detalles venta
    public function get_by_id($id)
  	{
      //comprobamos si es una petición ajax y existe la variable post id
        if($this->input->is_ajax_request())
        {
            $sales = $this->sales_model->get_by_id($id);
            $salesdetails = $this->sales_model->get_details($id);
            $data['id'] = $sales->id;
            $data['sales_check'] = $sales->sales_check;
            $data['total'] = $sales->total;
            $data['date_sale'] = $sales->date_sale;
            $data['estatus'] = $sales->estatus;
            $data['status'] = $sales->status;
            $data['detalles'] = $salesdetails;

           echo json_encode($data);
        }
  	}

    //devolucion de venta
    public function devolucion($id)
  	{
      //comprobamos si es una petición ajax y existe la variable post id
        if($this->input->is_ajax_request())
        {
          try {
            $user = $this->ion_auth->user()->row();//obtiene el usuario logeado
            //recuperar los detalles
            $detalles['arrDetalles']  = json_decode($this->input->post('arrDetalles'));
            $this->sales_model->devolucion($id,$detalles);//actualizar la nota principal
            //registrar el movimiento de caja
            $total = 0;
            foreach($detalles['arrDetalles'] as $key => $value){
                  $total += ($value->amount * $value->price);
            }  //salida de dinero de la caja
            $this->cashmovements_model->add('2','3',$total,'',$user->id,$this->input->post('sucursalid'));
            //dar entrada a los articulos
            $this->stockproduct_model->update_stock($detalles['arrDetalles'],$user->id,$this->input->post('sucursalid'));
            echo json_encode(array("status" => TRUE));
          } catch (\Exception $e) {
              //echo 'Excepción capturada: ',  $e->getMessage(), "\n";
              echo json_encode(array("status" => FALSE, 'mensaje' => 'Ocurrio un error al realizar la devolución'));
          }//fin catch

        }//fin ajax
  	}//fin devolucion

    //obtener detalles venta
    public function get_by_filter($fechaIni,$fechaFin,$factura)
  	{
      //comprobamos si es una petición ajax y existe la variable post id
        if($this->input->is_ajax_request())
        {
           $sales = $this->sales_model->get_by_filter($fechaIni,$fechaFin,$factura);
           echo json_encode($sales);
        }
  	}

    //iniciar el dia
    public function add_startday()
    {
      //comprobamos si es una petición ajax y existe la variable post id
        if($this->input->is_ajax_request())
        {
          try
          {
            $user = $this->ion_auth->user()->row();//obtiene el usuario logeado
            $this->cashmovements_model->add('1','1',$this->input->post('amount_ini'),$this->input->post('observaciones'),$user->id,$this->input->post('sucursal_id'));
            echo json_encode(array("status" => TRUE));
          } catch (\Exception $e) {
            echo json_encode(array("status" => FALSE,  'mensaje' => 'Ocurrio un error al iniciar el día'));
          }
        }
    }

    //retiros parciales de efectivo
    public function retiros()
    {
        //valida si esta logeado y si es administrador
        if ($this->ion_auth->logged_in())
        {
              $data['tittle'] = "Retiros";
              $data['opcion'] = "4";
              $user = $this->ion_auth->user()->row();//obtiene el usuario logeado
              $sucursal = $this->branchoffice_model->get_by_iduser($user->id);
              $data['diafin'] = $this->cashmovements_model->get_endday($sucursal->id);
              $data['diainicio'] = $this->cashmovements_model->get_startday($sucursal->id);
              $data['user'] = $user->first_name . ' ' . $user->last_name;
              //enviar datos y cargar
              $data['the_view_content'] = $this->load->view('sales/retiroscorte_view', $data ,TRUE);

              $this->load->view('templates/auth_master_view', $data);

         }else{
            echo 'no estas logeado';
             //enviar mensaje de logearse o mostrar pantalla de login
            //	redirect('auth/login');
         }
    }

    //cierre del dia
    public function corte()
    {
      //valida si esta logeado y si es administrador
      if ($this->ion_auth->logged_in())
      {
        $user = $this->ion_auth->user()->row();//obtiene el usuario logeado
        $sucursal = $this->branchoffice_model->get_by_iduser($user->id);
            $data['tittle'] = "Corte (Cierre de caja)";
            $data['opcion'] = "5";
            $data['diafin'] = $this->cashmovements_model->get_endday($sucursal->id);
            $data['diainicio'] = $this->cashmovements_model->get_startday($sucursal->id);
            $user = $this->ion_auth->user()->row();//obtiene el usuario logeado
            $data['user'] = $user->first_name . ' ' . $user->last_name;
            //enviar datos y cargar
            $data['the_view_content'] = $this->load->view('sales/retiroscorte_view', $data ,TRUE);

            $this->load->view('templates/auth_master_view', $data);

       }else{
          echo 'no estas logeado';
           //enviar mensaje de logearse o mostrar pantalla de login
          //	redirect('auth/login');
       }
    }

    public function addretirocorte()
    {
       //comprobamos si es una petición ajax y existe la variable post id
        if($this->input->is_ajax_request())
        {
          try
          {
            $user = $this->ion_auth->user()->row();//obtiene el usuario logeado
              $sucursal = $this->branchoffice_model->get_by_iduser($user->id);
            $this->cashmovements_model->add('2',$this->input->post('opcion'),$this->input->post('total'),$this->input->post('observaciones'),$user->id,$sucursal->id);
            if($this->input->post('opcion') == '5')
            {
              //obtener diferencia de caja
              $this->cashmovements_model->add_balance($user->id,$sucursal);
            }
            echo json_encode(array("status" => TRUE));
          } catch (\Exception $e) {
            echo json_encode(array("status" => FALSE,  'mensaje' => 'Ocurrio un error'));
          }
        }
    }

    //metodo para creacion de graficas de Ventas
    public function graficasventas()
    {
        if($this->input->is_ajax_request())
        {
          $data = $this->sales_model->get_datagrafic();
          echo json_encode($data);
       }
    }

}

?>
