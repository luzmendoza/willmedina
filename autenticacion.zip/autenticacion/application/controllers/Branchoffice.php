<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Branchoffice extends MY_Controller {  //cambiar CI por MY_Controller por la seguridad

    public function __construct()
    {
      parent::__construct();
        $this->load->library('ion_auth');
      $this->load->model('branchoffice_model');
      //carga las reglas de validacion de formulario
      $this->load->library('form_validation');
      //establece las reglas de validacion
      $this->form_validation->set_rules('name', 'Nombre', 'trim|required');
    }

    public function index()
    {
        //valida si esta logeado y si es administrador
  			if ($this->ion_auth->logged_in())
  			{
          $data['branchs'] = $this->branchoffice_model->get_all();
          //enviar datos y cargar
   				$data['the_view_content'] = $this->load->view('Branchoffice/branchoffice_view', $data, TRUE);

   				$this->load->view('templates/auth_master_view', $data);
        }else{
           echo 'no estas logeado';
            //enviar mensaje de logearse o mostrar pantalla de login
           //	redirect('auth/login');
        }
    }

    public function add()
		{
        if($this->input->is_ajax_request())
         {
           //reglas de validaciones
           if($this->form_validation->run() == FALSE || !is_array($_FILES))
           {
             	//de esta forma devolvemos los errores de formularios
             	//con ajax desde codeigniter, aunque con php es lo mismo
             	$errors = array(
 					           'name' => form_error('name'),
 					           'respuesta' => 'error'
 				               );
 						//y lo devolvemos así para parsearlo con JSON.parse
 		            echo json_encode($errors);
 		            return FALSE;
 			    }
           else{
        			$data = array(
        					'name' => $this->input->post('name'),
        					'address' => $this->input->post('address'),
        				);

                //si estamos editando
              if($this->input->post('id'))
              {
                  //actualizar
                  $this->branchoffice_model->update(array('id' => $this->input->post('id')), $data);
              }
              else{
                  //guardar en la tabla productos
                  $productID = $this->branchoffice_model->add($data);
              }

        			echo json_encode(array("status" => TRUE));
            }
        }
		}

    public function edit($id)
    {
      //comprobamos si es una petición ajax y existe la variable post id
        if($this->input->is_ajax_request())
        {
            $data = array();
            $product = $this->branchoffice_model->get_by_id($id);
            $data['id'] = $product->id;
            $data['address'] = $product->address;
            $data['name'] = $product->name;

            echo json_encode($data);
        }
    }

    public function delete($id)
  	{
      if($this->input->is_ajax_request())
      {
    		$this->branchoffice_model->delete($id);
    		echo json_encode(array("status" => TRUE));
      }
  	}

    //autocomplete para busqueda
    public function autocomplete()
    {
       $branchs =  $this->branchoffice_model->get_autocomplete();
      echo json_encode($branchs);
    }
}

?>
