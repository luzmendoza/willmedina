<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard extends CI_Controller {

  function __construct()
    {
      parent::__construct();
  		$this->load->library('ion_auth');
			$this->load->model('menu_model');
  	}


    public function index()
    {
       $data = array();
       $user = $this->ion_auth->user()->row();//obtiene el usuario logeado
       $this->permisosmenu($user);
       $_SESSION['username'] = $user->first_name. ' '. $user->last_name;
       $_SESSION['admin'] = 1;
       //recuperar datos de ventas y pedidos para realizar graficas
        //enviar datos y cargar
        $data['the_view_content'] = $this->load->view('dashboard/index_view', $data, TRUE);

        $this->load->view('templates/auth_master_view', $data);
    }
    public function employee()//mostrara la venta de empleados
    {
      $data = array();
      $user = $this->ion_auth->user()->row();//obtiene el usuario logeado
      $this->permisosmenu($user);
      $_SESSION['username'] = $user->first_name. ' '. $user->last_name;
      $_SESSION['employe'] = 2;
      //recuperar datos de ventas y pedidos para realizar graficas
         //enviar datos y cargar
           $data['the_view_content'] = $this->load->view('dashboard/index_view', $data, TRUE);
         //$data['the_view_content'] = $this->load->view('dashboard/employee_view', $data, TRUE);
         $this->load->view('templates/auth_master_view', $data);
        // $this->load->view('templates/emp_master_view', $data);//CREAR PANTALLA EMPLEADO.. Y CLIENTE TAMBIEN
    }

    public function permisosmenu($user)
    {

      //recuperar datos del menu
     $permisosmenu = $this->menu_model->get_by_user($user->id);
      foreach ($permisosmenu as $key => $value) {
        // code...
        switch ($value->controller) {
          case 'sales/ventas':
                  $_SESSION['salesventas'] = '1';
            break;
          case 'sales':
                  $_SESSION['sales'] = '1';
            break;
          case 'sales/retiros':
                  $_SESSION['salesretiros'] = '1';
            break;
          case 'sales/corte':
                  $_SESSION['salescorte'] = '1';
            break;
          case 'user':
                  $_SESSION['user'] = '1';
            break;
          case 'customer':
                  $_SESSION['customer'] = '1';
            break;
          case 'employe':
                  $_SESSION['employe'] = '1';
            break;
          case 'supply':
                  $_SESSION['supply'] = '1';
            break;
          case 'product':
                  $_SESSION['product'] = '1';
            break;
          case 'production':
                  $_SESSION['production'] = '1';
            break;
          case 'stocktaking/supply':
                  $_SESSION['stocktakingsupply'] = '1';
            break;
          case 'stocktaking/product':
                  $_SESSION['stocktakingproduct'] = '1';
            break;
          case 'permisos':
                    $_SESSION['permisosacceso'] = '1';
              break;
          case 'branchoffice':
                      $_SESSION['branchoffice'] = '1';
                break;

          default:
            // code...
            break;
        }
      }
    }
}
?>
