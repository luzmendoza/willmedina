<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * }
 */
class sales_model extends CI_Model
{

  var $table = 'sales';

    function __construct()
    {
        parent::__construct();
    }

    public function max(){
       $this->db->select('max(id) as total');
       $this->db->from($this->table);
       $consulta = $this->db->get();
       if ($consulta->num_rows() > 0)
       {
          $res2 = $consulta->result_array();
          $resultado = $res2[0]['total']+1;
      }
       return $resultado;
    }
    //agregar nuevo registro
    public function add($data)
    {
      $this->db->insert($this->table, $data);
      return $this->db->insert_id();

    }

    //agregar nuevo registro
    public function adddetails($detalles, $idventa,$userID,$sucID)
    {
        foreach ($detalles['arrDetalles'] as $key => $value) {
           //buscar existencia actual para modificarla
           $existencia = $this->get_producto_suc($value[0],$value[1],$sucID);

           $data = array(
               'id_sale' => $idventa,
               'id_product' => $value[0],
               'id_size' => $value[1],
               'amount' => $value[2]
            );
             // inserta nuevo registro
            $this->db->insert('sales_details', $data);
            //actualiza el stock_products
            $cantidad=$existencia->cantidad-$value[2];
            $this->db->set('amount', $cantidad);
            $this->db->where('id_product', $value[0]);
            $this->db->where('id_size', $value[1]);
            $this->db->update('stock_products');

            //ingresa el detalle en el inventario
            $dataH = array(
                'id_product' => $value[0],
                'id_size' => $value[1],
                'amount' => $value[2],
                'type_mov' => '2',
                'description' => "Salida por venta",
                'id_user'=>$userID,
                'id_branchoffice'=>$sucID,
             );

             $this->db->insert('stockproducts_history', $dataH);

        }
        return $this->db->insert_id();
    }
    //recuperar por id y Talla
    public function get_producto_suc($id,$idsize,$idsuc){
      $this->db->select('amount as cantidad');
      $this->db->from('stock_products');
      $this->db->where('id_product', $id);
      $this->db->where('id_size', $idsize);
      $this->db->where('id_branchoffice', $idsuc);
      $consulta = $this->db->get();
      $resultado = $consulta->row();
      return $resultado;
    }

    public function get_all()
    {
      $fecha = date("Y-m-d");
      $this->db->select("id, sales_check,total, date_sale,status,CASE  WHEN status = '1' THEN 'Activa' WHEN status = '2' THEN 'Cancelada' WHEN status = '3' THEN 'Devolución' END AS estatus ");
      $this->db->from($this->table);
      $this->db->where('date_sale >',$fecha.' 00:00:00');
      $this->db->where('date_sale <',$fecha.' 23:59:59');
      $this->db->order_by('id', 'asc');//ordena el select
      return  $this->db->get()->result();
    }

    //actualizar
    public function cancel($id)
    {
      $fecha = date("Y-m-d H:i:s");
      $this->db->set('status', '2');
      $this->db->set('date_cancel', $fecha);
      $this->db->where('id',$id);
      $this->db->update($this->table);
      return $this->db->affected_rows();
    }

    public function get_details($id)
    {
      $this->db->select("sd.id, sd.id_product,sd.id_size,sd.amount,sd.amount_dev,p.name,p.sku,p.price,s.abbreviation as talla ");
      $this->db->from('sales_details as sd');
      $this->db->join('cat_products as p','sd.id_product=p.id');
      $this->db->join('cat_sizes as s','sd.id_size=s.id');
      $this->db->where('sd.id_sale',$id);
      $this->db->order_by('sd.id', 'asc');//ordena el select
      return  $this->db->get()->result();
    }
    public function get_by_id($id)
    {
      $this->db->select("id, sales_check,total, date_sale,status,CASE  WHEN status = '1' THEN 'Activa' WHEN status = '2' THEN 'Cancelada' WHEN status = '3' THEN 'Devolución' END AS estatus ");
      $this->db->from($this->table);
      $this->db->where('id',$id);
      $this->db->order_by('id', 'asc');//ordena el select
      return  $this->db->get()->row();
    }

    //actualizar los detalles de la devolucion
    public function devolucion($id,$detalles)
    {
      $fecha = date("Y-m-d H:i:s");
      $this->db->set('status', '3');//devolucion
      $this->db->set('date_dev', $fecha);
      $this->db->where('id',$id);
      $this->db->update($this->table);

      //devolucion de los productos
      foreach ($detalles['arrDetalles'] as $key => $value) {

        $cantdev = $value->amount + $value->devact;
        $this->db->set('amount_dev',  $cantdev, FALSE   );
        $this->db->where('id',$value->id);
        $this->db->update('sales_details');
      }
      return $this->db->affected_rows();
    }

    public function get_by_filter($fechaIni,$fechaFin,$factura)
    {
      $this->db->select("id, sales_check,total, date_sale,status,CASE  WHEN status = '1' THEN 'Activa' WHEN status = '2' THEN 'Cancelada' WHEN status = '3' THEN 'Devolución' END AS estatus ");
      $this->db->from($this->table);
      if($fechaIni!='A' && $fechaFin!='B')
      {
        $this->db->where('date_sale >',$fechaIni.' 00:00:00');
        $this->db->where('date_sale <',$fechaFin.' 23:59:59');
      }
      if($factura!='C')
      {
        $this->db->where('sales_check',$factura);
      }
      $this->db->order_by('id', 'asc');//ordena el select
      return  $this->db->get()->result();
    }

    public function get_datagrafic()
    {
      //SELECT sum(total) as totaldinero, count(id) as totalventas, date_sale from sales WHERE date_sale BETWEEN '2018-08-01 00:00:00' and '2018-08-21 23:59:59' group by date_sale
      $fecha = date("Y-m-d");
      $this->db->select("sum(total) as totaldinero, count(id) as totalventas, DATE_FORMAT(date_sale, '%d/%m/%y') as fecha, (select sum(total) from sales where status<>1) as egresos");
      $this->db->from('sales');
      $this->db->where('date_sale >','2018-08-01 00:00:00');
      $this->db->where('date_sale <','2018-08-21 23:59:59');
      $this->db->group_by('fecha');//ordena el select
      $this->db->order_by('fecha', 'asc');//ordena el select
      return  $this->db->get()->result();
    }
}

 ?>
