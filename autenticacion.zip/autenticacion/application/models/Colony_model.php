<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * }
 */
class Colony_model extends CI_Model
{

    var $table = 'cat_colonies';

    function __construct()
    {
        parent::__construct();
    }


    //recuperar todos los Products
    public function get_all_by_id($cp){
       $this->db->select('key_colony,key_cp, name');
       $this->db->from($this->table);
       $this->db->order_by('name', 'asc');//ordena el select
       $this->db->where('key_cp', $cp);
       $consulta = $this->db->get();
       $resultado = $consulta->result();
       return $resultado;
    }

}

?>
