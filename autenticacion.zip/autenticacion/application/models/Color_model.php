<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * }
 */
class Color_model extends CI_Model
{

    var $table = 'cat_colors';

    function __construct()
    {
        parent::__construct();
    }


    //recuperar todos los Products
    public function get_all(){
       $this->db->select('id, name');
       $this->db->from($this->table);
       $this->db->order_by('name', 'asc');//ordena el select
       $consulta = $this->db->get();
       $resultado = $consulta->result();
       return $resultado;
    }

}

?>
