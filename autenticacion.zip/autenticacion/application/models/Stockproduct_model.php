<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * }
 */
class Stockproduct_model extends CI_Model
{

  var $table = 'stock_products';//inventarios

    function __construct()
    {
        parent::__construct();
    }

        //recuperar por id
        public function get_by($idProd,$idSuc){
          $this->db->select('sum(amount) as stock');
          $this->db->from($this->table);
          $this->db->where('id_product', $idProd);
            $this->db->where('id_branchoffice', $idSuc);
          $consulta = $this->db->get();
          $resultado = $consulta->row();
          return $resultado;
        }

        //agregar nuevo registro
        public function add($detalles, $idproducto,$sucID)
        {

          foreach ($detalles['arrDetalles'] as $key => $value) {

             $existencia = $this->get_by_productsuc($idproducto,$value[0],$sucID);

             $data = array(
                 'id_product' => $idproducto,
                 'id_size' => $value[0],
                 'amount' => $value[1],
                 'id_branchoffice' =>$sucID
              );
             if($existencia>0)
             {
               $cantidad = $value[1] +$existencia;
               //actualiza
               $this->db->set('amount', $cantidad);
               $this->db->where('id_product', $idproducto);
               $this->db->where('id_size', $value[0]);
                $this->db->where('id_branchoffice', $sucID);
               $this->db->update($this->table);
             }else {
               // inserta nuevo registro
                $this->db->insert($this->table, $data);

             }

          }
          return $this->db->insert_id();
        }

        /**HISTORIAL INVENTARIO **/
        public function get_history($idProduct,$idSuc){
          $this->db->select('h.id,h.id_product,h.id_size,h.amount,h.type_mov,h.description,h.date_mov,h.id_user,u.first_name,u.last_name');
          $this->db->from('stockproducts_history as h');
          $this->db->join('users as u', 'h.id_user = u.id');
          $this->db->where('h.id_product', $idProduct);
          $this->db->where('h.id_branchoffice', $idSuc);
          $this->db->order_by('id', 'asc');//ordena el select
          $consulta = $this->db->get();
          $resultado = $consulta->result();
          return $resultado;
        }

        //agregar nuevo registro
        public function addhistory($detalles,$descripcion,$userID,$productID,$sucursalID)
        {
          foreach ($detalles['arrDetalles'] as $key => $value) {
               $data = array(
                   'id_product' => $productID,
                   'id_size' => $value[0],
                   'amount' => $value[1],
                   'type_mov' => '1',
                   'description' =>$descripcion,
                   'id_user'=>$userID,
                   'id_branchoffice'=>$sucursalID
                );

                $this->db->insert('stockproducts_history', $data);
            }
          return $this->db->insert_id();
        }

        //recuperar por id, Talla y sucursal
        public function get_by_productsuc($id,$idsize,$idsuc){
          $this->db->select('amount as cantidad');
          $this->db->from($this->table);
          $this->db->where('id_product', $id);
          $this->db->where('id_size', $idsize);
          $this->db->where('id_branchoffice', $idsuc);
          $consulta = $this->db->get();
          $resultado = $consulta->row();
          return $resultado;
        }

        //actualizacion por cancelacion y devolucion
        public function update_stock($salesdetails,$userID,$sucursal)
        {
            foreach($salesdetails as $key => $value){
               //buscar existencia actual para modificarla
               $existencia = $this->get_by_productsuc($value->id_product,$value->id_size,$sucursal);

                //actualiza el stock_products
                $cantidad=$existencia->cantidad+$value->amount;
                $this->db->set('amount', $cantidad);
                $this->db->where('id_product', $value->id_product);
                $this->db->where('id_size', $value->id_size);
                $this->db->where('id_branchoffice', $sucursal);
                $this->db->update('stock_products');

                //ingresa el detalle en el inventario
                $dataH = array(
                    'id_product' => $value->id_product,
                    'id_size' => $value->id_size,
                    'amount' => $value->amount,
                    'type_mov' => '1', //1-Entrada 2.-Salida
                    'description' => "Entrada por cancelación/devolución",
                    'id_user'=>$userID,
                    'id_branchoffice'=>$sucursal,
                 );

                 $this->db->insert('stockproducts_history', $dataH);
            }
            return $this->db->insert_id();
        }

}
?>
