<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * }
 */
class Customer_model extends CI_Model
{

  var $table = 'cat_customers';

    function __construct()
    {
        parent::__construct();
    }

    //recuperar todos los Products
    public function get_all(){
      $this->db->select('cte.id,cte.cell_phone,u.first_name,u.last_name');
      $this->db->from('cat_customers as cte');
      $this->db->join('users as u', 'cte.id_user = u.id');
      $consulta = $this->db->get();
      $resultado = $consulta->result();
      //$resultado = $consulta->result_array(); //consulta por array asociativo
      return $resultado;
    }

    //obtener el ultimo registro
    public function count(){
       $this->db->select('max(id) as total');
       $this->db->from($this->table);
       $consulta = $this->db->get();
       if ($consulta->num_rows() > 0)
       {
          $res2 = $consulta->result_array();
          $resultado = $res2[0]['total']+1;
      }
       return $resultado;
    }

    //agregar nuevo Empleado
    public function add($data)
    {
      $this->db->insert($this->table, $data);
      return $this->db->insert_id();

    }

    //recuperar por id
    public function get_by_id($id){
      $this->db->select('cte.id AS id ,cte.cell_phone AS cell_phone,cte.image AS image,cte.imageurl AS imageurl,cte.id_user AS id_user,cte.phone AS phone,cte.sex AS sex,cte.birth_date AS birth_date,u.first_name AS first_name,u.last_name AS last_name');
      $this->db->from('cat_customers as cte');
      $this->db->join('users as u', 'cte.id_user = u.id');
      $this->db->where('cte.id', $id);
      $consulta = $this->db->get();
      $resultado = $consulta->row();
      return $resultado;
    }

    //actualizar
    public function update($where,$data)
    {
      $this->db->update($this->table, $data, $where);
  		return $this->db->affected_rows();
    }

    //elimina un empleado por su id
    public function delete($id){
       $this->db->where('id', $id);
       $this->db->delete($this->table);
    }

    public function get_user_by_id($id){
       $this->db->select('id_user');
       $this->db->from($this->table);
       $this->db->where('id', $id);
       $consulta = $this->db->get();
       if ($consulta->num_rows() > 0)
       {
          $res2 = $consulta->result_array();
          $resultado = $res2[0]['id_user'];
      }
       return $resultado;
    }
}
?>
