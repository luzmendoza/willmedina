<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * }
 */
class Branchoffice_model extends CI_Model
{

  var $table = 'cat_branchoffice';

    function __construct()
    {
        parent::__construct();
    }

    //guarda y actualiza los datos
    public function add($data)
    {
        $this->db->insert($this->table, $data);
        return $this->db->insert_id();
    }
    //elimina por su id
    public function delete($id){
       $this->db->where('id', $id);
       $this->db->delete($this->table);
    }

    //recuperar todos
    public function get_all(){
       $this->db->select("id,address, name");
       $this->db->from($this->table);
       $this->db->order_by('id', 'asc');//ordena el select
       $resultado = $this->db->get()->result();
       return $resultado;
    }

    //recuperar uno especifico
    public function get_by_id($id){
       $this->db->select('id, address, name');
       $this->db->from($this->table);
       $this->db->where('id', $id);
       $resultado = $this->db->get()->row();
       return $resultado;
    }

    //actualiza uno especifico
    public function update($where, $data)
  	{
  		$this->db->update($this->table, $data, $where);
  		return $this->db->affected_rows();
  	}

    //recuperar todos las sucursales
    public function get_autocomplete(){
       $this->db->select("id,address, name");
       $this->db->from($this->table);
       $this->db->order_by('id', 'asc');//ordena el select
       $resultado = $this->db->get()->result();
       return $resultado;
    }

    //recuperar uno especifico
    public function get_by_iduser($id){
       $this->db->select('cat.id, cat.address, cat.name');
       $this->db->from('cat_branchoffice as cat');
       $this->db->join('users_branchoffice as ub', 'cat.id = ub.id_branchoffice');
       $this->db->where('ub.id_user', $id);
       $resultado = $this->db->get()->row();
       return $resultado;
    }
}

 ?>
