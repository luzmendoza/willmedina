<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * }
 */
class Stocksupply_model extends CI_Model
{

  var $table = 'stock_supplies';//inventarios

    function __construct()
    {
        parent::__construct();
    }

    //recuperar por id
    public function get_by_id($id){
      $this->db->select('id,id_supply,existence,unit_measure,unit_price,date_mov');
      $this->db->from($this->table);
      $this->db->where('id_supply', $id);
      $consulta = $this->db->get();
      $resultado = $consulta->row();
      return $resultado;
    }



    //agregar nuevo registro
    public function add($data)
    {
      $this->db->insert($this->table, $data);
      return $this->db->insert_id();

    }
    //actualizar
    public function update($where,$data)
    {
      $this->db->update($this->table, $data, $where);
  		return $this->db->affected_rows();

    }

    /**HISTORIAL INVENTARIO **/
    public function get_history($id){
      $this->db->select('h.id,h.amount,h.type_mov,h.description,h.date_mov,h.id_user,u.first_name,u.last_name');
      $this->db->from('stocksupplies_history as h');
      $this->db->join('users as u', 'h.id_user = u.id');
      $this->db->where('h.id_supply', $id);
      $this->db->order_by('id', 'asc');//ordena el select
      $consulta = $this->db->get();
      $resultado = $consulta->result();
      return $resultado;
    }

    //agregar nuevo registro
    public function addhistory($data)
    {
      $this->db->insert('stocksupplies_history', $data);
      return $this->db->insert_id();

    }

}
?>
