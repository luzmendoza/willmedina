<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * }
 */
class Production_model extends CI_Model
{

  var $table = 'production_costs';

    function __construct()
    {
        parent::__construct();
        $this->load->model('stocksupply_model');
    }

    //guarda y actualiza los datos de los Products
    public function add($detalles,$data,$userid)
    {
      //insertar en tabla principal
        $this->db->insert($this->table, $data);
        $idcp = $this->db->insert_id();
        //insertar detalles
        foreach ($detalles['arrDetalles'] as $key => $value) {
          //modificar la cantidad y la unidad para usar solo centimentros
          if($value[2] == 1)//metros
          {
            $amount = $value[1] * 100;
            $meausure = '2';
          }else{
            $amount = $value[1];
            $meausure = $value[2];
          }

           $data = array(
               'id_productioncost' => $idcp,
               'id_supply' => $value[0],
               'amount' => $amount,
               'meausure_supply' => $meausure,
            );
             // inserta nuevo registro
            $this->db->insert('production_details', $data);
            //busca la cantidad actual para actualizar el inventario
            $supply = $this->stocksupply_model->get_by_id( $value[0]);
            //modificar las existencias
            $data = array(
                'existence' => $supply->existence-$amount,
              );
              //actualizar stock
            $this->stocksupply_model->update(array('id' => $supply->id),$data);
            //agregar datos al historial
            $datahistory = array(
                'id_supply' => $value[0],
                'amount' => $value[1],
                'type_mov' => '2',
                'description' => 'Salida por producción',
                'id_user' => $userid,
              );
              $this->stocksupply_model->addhistory($datahistory);

        }//fin foreach ($variable as $key => $value) {

        return $idcp;
         //realizar guardado de imagenes y detalles con ese id
    }
}

 ?>
