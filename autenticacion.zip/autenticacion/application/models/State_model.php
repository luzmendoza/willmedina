<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * }
 */
class State_model extends CI_Model
{

    var $table = 'cat_state';

    function __construct()
    {
        parent::__construct();
    }


    //recuperar todos los Products
    public function get_all_by_id($id,$tipoId){
       $this->db->select('key_state,key_country, name');
       $this->db->from($this->table);
       $this->db->order_by('name', 'asc');//ordena el select
       if($tipoId == '1')
       {
          $this->db->where('key_country', $id);
        }else {
          $this->db->where('key_state', $id);
        }
       $consulta = $this->db->get();
       $resultado = $consulta->result();
       return $resultado;
    }


    public function get_all($country){
       $this->db->select('key_state,key_country, name');
       $this->db->from($this->table);
       $this->db->order_by('name', 'asc');//ordena el select

          $this->db->where('key_country', $country);

       $consulta = $this->db->get();
       $resultado = $consulta->result();
       return $resultado;
    }
}

?>
