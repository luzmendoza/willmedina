<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * }
 */
class Permisos_model extends CI_Model
{

    var $tablePM = 'menu';
    var $tablePU = 'users_menu';

    function __construct()
    {
        parent::__construct();
    }


    //recuperar todos los registros del menu
    public function get_menu(){
       $this->db->select('id, menu,submenu');
       $this->db->from($this->tablePM);
       $this->db->order_by('menu,submenu', 'asc');//ordena el select
       $resultado = $this->db->get()->result();
       return $resultado;
    }

    public function add($detalles)
    {
        foreach ($detalles as $key => $value) {

          $data = array(
              'id_user' => $value->id_user,
              'id_menu' => $value->id_menu,
           );
          $this->db->insert($this->tablePU , $data);
      }

    }

    public function delete($user)
    {
      $this->db->where('id_user', $user);
      $this->db->delete($this->tablePU);
    }

    public function get_usermenu($user){
       $this->db->select('id_menu');
       $this->db->from($this->tablePU);
       $this->db->where('id_user', $user);
       $resultado = $this->db->get()->result();
       return $resultado;
    }

}

?>
