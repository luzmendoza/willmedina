<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * }
 */
class Municipality_model extends CI_Model
{

    var $table = 'cat_municipalities';

    function __construct()
    {
        parent::__construct();
    }


    //recuperar todos los municipios del estado enviado
    public function get_all_by_id($idEstado,$idMun){
       $this->db->select('key_municipality,key_state, name');
       $this->db->from($this->table);
       $this->db->order_by('name', 'asc');//ordena el select
       if ($idMun != '')
       {
         $this->db->where('key_municipality', $idMun);
       }
       $this->db->where('key_state', $idEstado);
       $consulta = $this->db->get();
       $resultado = $consulta->result();
       return $resultado;
    }

    public function get_all($idEstado){
       $this->db->select('key_municipality,key_state, name');
       $this->db->from($this->table);
       $this->db->order_by('name', 'asc');//ordena el select
       $this->db->where('key_state', $idEstado);
       $consulta = $this->db->get();
       $resultado = $consulta->result();
       return $resultado;
    }


    //obtener la clave
  /*  public function clave_by_id($id){
       $this->db->select('clave');
       $this->db->from($this->table);
       $this->db->where('id', $id);
       $consulta = $this->db->get();

       if ($consulta->num_rows() > 0)
       {
          $res2 = $consulta->result_array();
          $resultado = $res2[0]['clave'];
      }
       return $resultado;
    }
*/
}

?>
