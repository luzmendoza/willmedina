<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * }
 */
class Menu_model extends CI_Model
{

    var $table = 'users_menu';

    function __construct()
    {
        parent::__construct();
    }


    //recuperar
    public function get_by_user($userID){
       $this->db->select('um.id_menu,m.controller as controller');
       $this->db->from('users_menu as um');
       $this->db->join('menu as m','um.id_menu=m.id');
       $this->db->where('um.id_user',$userID);
       $resultado = $this->db->get()->result();
       return $resultado;
    }

}

?>
