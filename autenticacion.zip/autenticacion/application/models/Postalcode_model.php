<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * }
 */
class Postalcode_model extends CI_Model
{

    var $table = 'cat_postalcode';

    function __construct()
    {
        parent::__construct();
    }


    //recuperar todos los Products
    public function get_all_by_id($id){
       $this->db->select('key_cp,key_state,key_municipality,key_locality');
       $this->db->from($this->table);
      $this->db->where('key_cp', $id);
       $consulta = $this->db->get();
       $resultado = $consulta->result();
       return $resultado;
    }

}

?>
