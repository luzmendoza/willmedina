<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * }
 */
class Useraddress_model extends CI_Model
{

  var $table = 'users_address';

    function __construct()
    {
        parent::__construct();
    }


    //agregar nueva direccion de usuario
    public function add($data)
    {
      $this->db->insert($this->table, $data);
      return $this->db->insert_id();

    }

    public function get_by_user($id,$type){
      $this->db->select('key_country,key_state,key_cp,key_colony,street,num_exterior,num_inside,street_between1,street_between2,complement');
      $this->db->from($this->table);
      $this->db->where('id_user', $id);
      $this->db->where('type_user', $type);
      $consulta = $this->db->get();
      $resultado = $consulta->row();
      return $resultado;
    }

    //actualizar
    public function update($where,$data)
    {
      $this->db->update($this->table, $data, $where);
      return $this->db->affected_rows();

    }

    //elimina un empleado por su id
    public function delete($id,$type){
       $this->db->where('id_user', $id);
       $this->db->where('type_user',  $type);
       $this->db->delete($this->table);
    }
}
?>
