<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * }
 */
class Locality_model extends CI_Model
{

    var $table = 'cat_localities';

    function __construct()
    {
        parent::__construct();
          $this->load->model('state_model');
            $this->load->model('municipality_model');
    }


    //recuperar todos los municipios del estado enviado
    public function get_all_by_id($idEstado,$idLocalidad){

       $this->db->select('key_locality,key_state, name');
       $this->db->from($this->table);
       $this->db->order_by('name', 'asc');//ordena el select
       $this->db->where('key_state', $idEstado);
       $this->db->where('key_locality', $idLocalidad);
       $consulta = $this->db->get();
       $resultado = $consulta->result();
       return $resultado;
    }

}

?>
