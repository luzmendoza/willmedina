<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * }
 */
class Userbranch_model extends CI_Model
{

  var $table = 'users_branchoffice';

    function __construct()
    {
        parent::__construct();
    }


    //agregar nueva direccion de usuario
    public function add($user,$sucursal)
    {
      $data = array(
          'id_user' => $user,
          'id_branchoffice' => $sucursal,
        );
      $this->db->insert($this->table, $data);
      return $this->db->insert_id();

    }

    //actualizar
    public function update($where,$sucursal)
    {
      $data = array(
          'id_branchoffice' => $sucursal,
        );
      $this->db->update($this->table, $data, $where);
      return $this->db->affected_rows();
    }

    public function delete($id){
       $this->db->where('id_user', $id);
       $this->db->delete($this->table);
    }

    
}
?>
