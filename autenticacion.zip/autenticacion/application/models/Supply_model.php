<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * }
 */
class Supply_model extends CI_Model
{

  var $table = 'cat_supplies';//suministros

    function __construct()
    {
        parent::__construct();
    }

    //recuperar todos los registros
    public function get_all(){
      $this->db->select('id,code, name');
      $this->db->from($this->table);
      $this->db->order_by('id', 'asc');//ordena el select
      $consulta = $this->db->get();
      $resultado = $consulta->result();
      return $resultado;
    }

    //agregar nuevo Empleado
    public function add($data)
    {
      $this->db->insert($this->table, $data);
      return $this->db->insert_id();

    }

    //recuperar por id
    public function get_by_id($id){
      $this->db->select('id,code, name');
      $this->db->from($this->table);
      $this->db->where('id', $id);
      $consulta = $this->db->get();
      $resultado = $consulta->row();
      return $resultado;
    }

    //actualizar
    public function update($where,$data)
    {
      $this->db->update($this->table, $data, $where);
  		return $this->db->affected_rows();

    }

    //elimina un registro por su id
    public function delete($id){
       $this->db->where('id', $id);
       $this->db->delete($this->table);
    }

    //obtener el ultimo registro
    public function count(){
       $this->db->select('max(id) as total');
       $this->db->from($this->table);
       $consulta = $this->db->get();
       if ($consulta->num_rows() > 0)
       {
          $res2 = $consulta->result_array();
          $resultado = $res2[0]['total']+1;
      }
       return $resultado;
    }

}
?>
