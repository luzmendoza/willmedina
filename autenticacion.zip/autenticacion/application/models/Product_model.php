<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * }
 */
class Product_model extends CI_Model
{

  var $table = 'cat_products';

    function __construct()
    {
        parent::__construct();
    }

    //guarda y actualiza los datos de los Products
    public function add($data)
    {
        $this->db->insert($this->table, $data);
        return $this->db->insert_id();
         //realizar guardado de imagenes y detalles con ese id
    }
    //elimina un Product por su id
    public function delete($id){
       $this->db->where('id', $id);
       $this->db->delete($this->table);
    }

    //recuperar todos los Products
    public function get_all(){
       $this->db->select("id,sku, name, description, price, id_category, CASE  WHEN status = '1' THEN 'Activo' WHEN status = '2' THEN 'Inactivo' END AS estatus");
       $this->db->from($this->table);
       $this->db->order_by('id', 'asc');//ordena el select
       $consulta = $this->db->get();
       $resultado = $consulta->result();
       //$resultado = $consulta->result_array(); //consulta por array asociativo
    //   $cantidad_encontrados = $consulta->num_rows();//obtiene el numero de registros
       return $resultado;
    }

    //recuperar un Product especifico
    public function get_by_id($id){
       $this->db->select('id, sku, name, description, price, id_category, id_color,name_image,url_image, status');
       $this->db->from($this->table);
       $this->db->where('id', $id);
       $consulta = $this->db->get();
       $resultado = $consulta->row();
       return $resultado;
    }


    public function update($where, $data)
  	{
  		$this->db->update($this->table, $data, $where);
  		return $this->db->affected_rows();
  	}

    //obtener el ultimo registro
    public function max(){
       $this->db->select('max(id) as total');
       $this->db->from($this->table);
       $consulta = $this->db->get();

       if ($consulta->num_rows() > 0)
       {
          $res2 = $consulta->result_array();
          $resultado = $res2[0]['total']+1;
      }
       return $resultado;
    }

    //recuperar todos los Products
    public function get_autocomplete(){
       $this->db->select("id,sku, name, description, price, id_category, status");
       $this->db->where('status', '1');
       $this->db->from($this->table);
       $this->db->order_by('id', 'asc');//ordena el select
       $consulta = $this->db->get();
       $resultado = $consulta->result();
       //$resultado = $consulta->result_array(); //consulta por array asociativo
    //   $cantidad_encontrados = $consulta->num_rows();//obtiene el numero de registros
       return $resultado;
    }
}

 ?>
