<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * }
 */
class Cashmovements_model extends CI_Model
{

    var $table = 'cash_movements';

    function __construct()
    {
        parent::__construct();
    }


    //recuperar inicio del dia
    public function get_startday($sucursal){
      //SELECT * from cash_movements where date = '2018-07-10'
       $fecha = date("Y-m-d");
       $this->db->select('amount');
       $this->db->from($this->table);
       $this->db->where('date >',$fecha.' 00:00:00');
       $this->db->where('date <',$fecha.' 23:59:59');
       $this->db->where('type_mov','1');
       $this->db->where('id_branchoffice',$sucursal);

       $consulta = $this->db->get();
       if ($consulta->num_rows() > 0)
       {
          $resp = '1';//se inicio el dia
        }else{
          $resp = '2';//No se inicio el dia
        }

       return $resp;
    }

    public function add($operation,$movimiento,$cantidad,$observ,$User,$sucursal)
    {
        $data = array(
            'type_operation' => $operation,
            'type_mov' => $movimiento,
            'amount' => $cantidad,
            'observations' => $observ,
            'id_user' => $User,
            'id_branchoffice' =>$sucursal,
         );
         // inserta nuevo registro
        $this->db->insert($this->table, $data);
        return $this->db->insert_id();
    }

    public function add_balance($User,$sucursal)
    {
       $query = $this->db->query("select (select sum(amount) from cash_movements where type_operation='1') as entradas, sum(amount) as salidas
       from cash_movements where type_operation='2' ");
       $row  =  $query->row();
        if(isset($row))
        {
            $balance = $row->entradas - $row->salidas ;
        }
        $data = array(
            'id_user' => $User,
            'balance' => $balance,
         );
         // inserta nuevo registro
        $this->db->insert('balances_cut', $data);
        return $this->db->insert_id();
    }

    //fin de dia
    public function get_endday($sucursal){
      //SELECT * from cash_movements where date = '2018-07-10'
       $fecha = date("Y-m-d");
       $this->db->select('amount');
       $this->db->from($this->table);
       $this->db->where('date >',$fecha.' 00:00:00');
       $this->db->where('date <',$fecha.' 23:59:59');
       $this->db->where('type_mov','5');
       $this->db->where('id_branchoffice',$sucursal);

       $consulta = $this->db->get();
       if ($consulta->num_rows() > 0)
       {
          $resp = '1';//se finalizo el dia
      }else{
        $resp = '2';//No se finalizo el dia
      }

       return $resp;
    }


}

?>
