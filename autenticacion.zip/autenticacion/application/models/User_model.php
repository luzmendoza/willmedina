<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * }
 */
class User_model extends CI_Model
{

    var $table = 'users';

    function __construct()
    {
        parent::__construct();
    }


    //recuperar todos los Products
    public function get_all(){
       $this->db->select('users.id,users.username,users.email,users.first_name,users.last_name,groups.description');
       $this->db->from('users');
       $this->db->join('users_groups', 'users.id = users_groups.user_id');
       $this->db->join('groups', 'users_groups.group_id = groups.id');
       $this->db->group_by('users_groups.user_id', 'asc');//ordena el select
       $this->db->order_by('users.id', 'asc');//ordena el select
       $consulta = $this->db->get();
       $resultado = $consulta->result();
       return $resultado;

       /*
       SELECT users.first_name,groups.description from users inner join
      users_groups on users.id=users_groups.user_id inner join groups on users_groups.group_id=groups.id
      GROUP BY users_groups.user_id
      */
    }
    //recuperar por id
    public function get_by_id($id){
       $this->db->select('id,username,email,first_name,last_name,password');
       $this->db->from($this->table);
       $this->db->where('id', $id);
       $consulta = $this->db->get();
       $resultado = $consulta->row();
       return $resultado;
    }

    //actualizar datos de Usuario
    public function update($id,$name,$last_name,$email,$phone)
    {
        $data = array(
          'first_name' => $name,
          'last_name' => $last_name,
          'email' => $email,
          'phone' => $phone
        );
        $this->db->where('id', $id);
        $this->db->update($this->table, $data);
        return $this->db->affected_rows();
    }


    //recuperar por id
    public function get_groups_by_userid($id){
       $this->db->select('group_id');
       $this->db->from('users_groups');
       $this->db->where('user_id', $id);
       $consulta = $this->db->get();
       $resultado = $consulta->result();
       return $resultado;
    }

    //eliminar grupos de Usuario
    public function delete_fromgroup($userid)
    {
        $this->db->where('user_id', $userid);
        $this->db->delete('users_groups');

    }



}

?>
