<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * }
 */
class Employe_model extends CI_Model
{

  var $table = 'cat_employees';

    function __construct()
    {
        parent::__construct();
    }

    //recuperar todos los Products
    public function get_all(){
      $this->db->select('emp.id,emp.cell_phone,emp.key_employe,u.first_name,u.last_name');
      $this->db->from('cat_employees as emp');
      $this->db->join('users as u', 'emp.id_user = u.id');
      $consulta = $this->db->get();
      $resultado = $consulta->result();
      //$resultado = $consulta->result_array(); //consulta por array asociativo
      return $resultado;
    }

    //obtener el ultimo registro
    public function count(){
       $this->db->select('max(id) as total');
       $this->db->from($this->table);
       $consulta = $this->db->get();
       if ($consulta->num_rows() > 0)
       {
          $res2 = $consulta->result_array();
          $resultado = $res2[0]['total']+1;
      }
       return $resultado;
    }

    //agregar nuevo Empleado
    public function add($data)
    {
      $this->db->insert($this->table, $data);
      return $this->db->insert_id();

    }

    //recuperar por id
    public function get_by_id($id){
      $this->db->select('emp.id AS id ,emp.cell_phone AS cell_phone,emp.key_employe AS key_employe,emp.image AS image,emp.imageurl AS imageurl,emp.id_user AS id_user,emp.phone AS phone,
      emp.sex AS sex,emp.birth_date AS birth_date,u.first_name AS first_name,u.last_name AS last_name,us.id_branchoffice as sucursal');
      $this->db->from('cat_employees as emp');
      $this->db->join('users as u', 'emp.id_user = u.id');
      $this->db->join('users_branchoffice as us', 'emp.id_user = us.id_user');
      $this->db->where('emp.id', $id);
      $consulta = $this->db->get();
      $resultado = $consulta->row();
      return $resultado;
    }

    //actualizar
    public function update($where,$data)
    {
      $this->db->update($this->table, $data, $where);
  		return $this->db->affected_rows();

    }

    //elimina un empleado por su id
    public function delete($id){
       $this->db->where('id', $id);
       $this->db->delete($this->table);
    }

    public function get_user_by_id($id){
       $this->db->select('id_user');
       $this->db->from($this->table);
       $this->db->where('id', $id);
       $consulta = $this->db->get();
       if ($consulta->num_rows() > 0)
       {
          $res2 = $consulta->result_array();
          $resultado = $res2[0]['id_user'];
      }
       return $resultado;
    }

    //recuperar por usuario
    public function get_by_userid($iduser){
      $this->db->select('emp.id AS id ,emp.cell_phone AS cell_phone,emp.key_employe AS key_employe,emp.image AS image,emp.imageurl AS imageurl,emp.id_user AS id_user,emp.phone AS phone,emp.sex AS sex,emp.birth_date AS birth_date,u.first_name AS first_name,u.last_name AS last_name');
      $this->db->from('cat_employees as emp');
      $this->db->join('users as u', 'emp.id_user = u.id');
      $this->db->where('emp.id_user', $iduser);
      $consulta = $this->db->get();
      $resultado = $consulta->row();
      return $resultado;
    }
}
?>
