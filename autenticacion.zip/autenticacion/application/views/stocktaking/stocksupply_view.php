<?php defined('BASEPATH') OR exit('No direct script access allowed');?>

   <div class="card">
     <div class="card-header">Inventario Suministros (Insumos)</div>
     <div class="card-body">
      <form action="#" id="form" class="form-horizontal">
         <input type="hidden" name="<?php echo $this->security->get_csrf_token_name();?>" value="<?php echo $this->security->get_csrf_hash();?>">

         <div id="errores" class="col-md-10 alert alert-danger respuesta" role="alert" style="display:none;">
         </div>
         <div id="exito" class="col-md-10 alert alert-success respexito" role="alert" style="display:none;">
         </div>


         <input  type="hidden" id="id" name="id"><!--id del stock-->
         <input  type="hidden" id="id_supply" name="id_supply">

         <!--Totales-->
           <div class="form-group">
             <div class="form-row">
               <div class="col-md-2">
                 <label for="codigo">Código </label>
                 <input class="form-control" id="autocompletecodigo" name="codigo" type="text" placeholder="ejemplo: wm-s-0001" maxlength="10" tabindex="1" required>
               </div>
               <div class="col-md-2">
                 <label for="nombre">Nombre </label>
                 <input class="form-control" id="autocompletesupply" name="name" type="text" placeholder="ejemplo: cierre" maxlength="50" tabindex="2" required>
               </div>
               <div class="col-md-1">
                 <label for="cantidad">Stock </label>
                 <input class="form-control" id="stock" name="stock" type="text" placeholder="0" tabindex="3" readonly>
               </div>
               <div class="col-md-2">
                 <label for="cantidad">Cantidad </label>
                 <input class="form-control numeros" onblur="validateDecimal(value)" id="cantidad" name="cantidad" type="text" placeholder="Cantidad" maxlength="5" tabindex="4" required>
               </div>
               <div class="col-md-1">
                 <label for="medidad">Medida</label>
                 <select class="form-control" id="medida" name="medida" aria-describedby="medidaHelp"   tabindex="5" required>
                   <option value="1">mt(s)</option>
                   <option value="2">cm(s)</option>
                   <option value="3">pza(s)</option>
                 </select>
               </div>
               <div class="col-md-2">
                 <label for="precio">Precio Unitario</label>
                 <div class="input-group mb-3">
                  <div class="input-group-prepend">
                    <span class="input-group-text">$</span>
                  </div>
                  <input type="text" id="precio" name="precio" tabindex="6" maxlength="7" required class="form-control numeros" aria-label="Amount (to the nearest dollar)">
                  <div class="input-group-append">
                    <span class="input-group-text">.00</span>
                  </div>
                </div>
               </div>
             </div>
           </div>

           <div class="form-group">
             <div class="form-row">
               <div class="col-md-4">
                 <input class="form-control" id="descripcion" name="descripcion" type="text" placeholder="Agregar comentarios" maxlength="100" tabindex="6" required>
               </div>
               <div class="col-md-1">
                 <button type="button" id="btnCancelar" onclick="limpiar()" class="btn btn-danger">Cancelar</button>
               </div>
               <div class="col-md-1">
                 <button type="button" id="btnSave" onclick="save()" class="btn btn-primary">Guardar</button>
               </div>

             </div>
           </div>


<!--historial-->
<div class="form-group">
  <div class="form-row">
    <div class="col-md-10">
        <div class="card" >
          <div class="card-header">Historial de Inventario</div>
            <div class="card-body">

              <div class="table-responsive">

              <!--tabla para agregar detalles-->
              <table class="table" id="dtDetalles" name="dtDetalles">
                <thead>
                  <tr>
                    <th>Fecha</th>
                    <th>Hora</th>
                    <th>Tipo Movimiento</th>
                    <th>Cantidad</th>
                    <th>Descripción</th>
                    <th>Usuario</th>
                  </tr>
                </thead>

                <tbody id="dtDetallesBody">
                  <tr>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                  </tr>
                </tbody>
              </table>

            </div>  <!--responsive <table>-->

              </div>
          </div>
        </div>
      </div>
  </div>



       </form>
     </div>
   </div>


   <script type="text/javascript">
   $(document).ready( function () {
        $('#errores').slideUp();

     // Validar solo numeros
     	$(".numeros").keypress(function (e) {
     	 	if (e.which != 8 && e.which != 0 && e.which != 46 && (e.which < 48 || e.which > 57)) {
                 return false;
     		}
     	});



   });// fin ready function

   function validateDecimal(valor) {
     console.log('entro');
     console.log(valor);
    var RE = /^\d*(\.\d{1})?\d{0,1}$/;
    if (RE.test(valor)) {
       console.log('bien');
        return true;
    } else {
       console.log('mal');
      $("#cantidad").focus();
      $(".respuesta").html('<button type="button" class="btn btn-sm close" data-dismiss="alert" aria-label="Close"><i class="fa fa-times" aria-hidden="true"></i> </button>');
        $(".respuesta").html("La cantidad es incorrecta");
       $('#errores').slideDown().fadeOut(3000);
        return false;
    }
  }

   function save()
   {
      if(validar())
      {
          var url = "<?php echo site_url('stocktaking/addsum')?>";

          // ajax adding data to database
            $.ajax({
              url : url,
              type: "POST",
              data: $('#form').serialize(),
              dataType: "JSON",
              success: function(data)
              {
                 console.log(data);
                 console.log(data.Usuario);
                 if(data.respuesta == 'error')
                 {
                   $(".respuesta").html('<button type="button" class="btn btn-sm close" data-dismiss="alert" aria-label="Close"><i class="fa fa-times" aria-hidden="true"></i> </button>');
                     $(".respuesta").html(data.supply + data.amount + data.price);
                    $('#errores').slideDown().fadeOut(8000);
                     return false;
                  }else{
                    $(".respexito").html('<button type="button" class="btn btn-sm close" data-dismiss="alert" aria-label="Close"><i class="fa fa-times" aria-hidden="true"></i> </button>');
                    $(".respexito").html("Registro realizado exitosamente");
                     $('#exito').slideDown().fadeOut(5000);
                      //return true;
                      // location.reload();// for reload a page  ?????
                      limpiar();
                  }
              },
              error: function (jqXHR, textStatus, errorThrown)
              {
                  alert('Error al registrar los datos');
              }
          });

      }
   }
   //validar que los datos obligatorios sean ingresados antes de realizar el registro
   function validar()
   {
       var mensaje = 'Campos requeridos:  <br>';
       var respuesta = true;

       if($("#id_supply").val()=="" )
       {
         mensaje += 'Insumo <br>';
         respuesta = false;
       }
       if($("#cantidad").val()=="" ||  parseInt($("#cantidad").val()) == 0)
       {
         mensaje += 'Cantidad <br>';
         respuesta = false;
       }
       if($("#precio").val()=="" ||  parseInt($("#cantidad").val()) == 0)
       {
         mensaje += 'Precio  <br>';
         respuesta = false;
       }


       if(respuesta == false)
       {
           $(".respuesta").html('<button type="button" class="btn btn-sm close" data-dismiss="alert" aria-label="Close"><i class="fa fa-times" aria-hidden="true"></i> </button>');
             $(".respuesta").html(mensaje);
            $('#errores').slideDown().fadeOut(5000);
       }
       return respuesta;
   }


   //limpiar todo..
   function limpiar()
   {
     //no eliminar la primera fila nunca
       var trs=$("#dtDetallesBody tr").length;
       for (var i = 0; i < trs-1; i++) {
           $("#dtDetallesBody tr:last").remove();
       }

       $("#id_supply").val("");
       $("#id").val("");
       $("#stock").val("0");
       $("#medidad option:selected").text("");
       $("#cantidad").val("");
       $("#precio").val("");
       $("#autocompletecodigo").val("");
       $("#autocompletesupply").val("");
       $("#descripcion").val("");
   }

   //autocomplete para recuperar al producto
   var optionscodigo = {
     url: "<?php echo site_url('supply/autocomplete')?>", //esta es la data
     getValue: "code", //este es el valor que busca el autocomplete, puede ser string o funcion
     template: {  //muestra una descripcion sumado al elemento de busqueda, aparece en letra mas pequeña :)
       type: "description",
       fields: {
         description: "name"
       }
     },
     list: {
         match: { //este hace una busqueda por coincidencia
           enabled: true
         },
         sort: { //ordena los datos de la lista
           enabled: true
         },
         onChooseEvent: function() {
           //llenar los combos y cajas
           var nombre = $("#autocompletecodigo").getSelectedItemData().name.trim();
           var id = $("#autocompletecodigo").getSelectedItemData().id;
             $("#autocompletesupply").val(nombre).trigger("change");
             $("#id_supply").val(id).trigger("change");

               getdetailsinventario(id);
               gethistorialinventario(id);


         }
       },
     theme: "bootstrap",
     placeholder: "ejemplo: wm-s-0001",
     adjustWidth: false //linea super necesaria para que se vea la lista en horizontal :) y no letra por letra hacia abajo
   };
   //opcion de busqueda cpor nombre
   var optionssupply = {
     url: "<?php echo site_url('supply/autocomplete')?>", //esta es la data
     getValue: "name", //este es el valor que busca el autocomplete, puede ser string o funcion
     template: {  //muestra una descripcion sumado al elemento de busqueda, aparece en letra mas pequeña :)
       type: "description",
       fields: {
         description: "code"
       }
     },
     list: {
         match: { //este hace una busqueda por coincidencia
           enabled: true
         },
         sort: { //ordena los datos de la lista
           enabled: true
         },
         onChooseEvent: function() {
           //llenar los combos y cajas
           var code = $("#autocompletesupply").getSelectedItemData().code.trim();
           var id = $("#autocompletesupply").getSelectedItemData().id;
             $("#autocompletecodigo").val(code).trigger("change");
             $("#id_supply").val(id).trigger("change");

               getdetailsinventario(id);
               gethistorialinventario(id);


         }
       },
     theme: "bootstrap",
     placeholder: "Ejemplo: cierre",
     adjustWidth: false //linea super necesaria para que se vea la lista en horizontal :) y no letra por letra hacia abajo
   };

   //asignar propiedad autocomplete a los campos
   $("#autocompletecodigo").easyAutocomplete(optionscodigo);
    $("#autocompletesupply").easyAutocomplete(optionssupply);


    //obtiene la lista de detalles si existe en el inventario
    function getdetailsinventario(id)
    {
        //Ajax Load data from ajax
        $.ajax({
          url : "<?php echo site_url('stocktaking/getstocksupply/')?>"+id,
          type: "GET",
          dataType: "JSON",
          success: function(data)
          {
            console.log(data);
            $(data).each(function(i, v){ // indice, valor
              //hacer algo
                 //$("#stock").val(v.existence);
                 $("#id_supply").val(v.id_supply);
                 $("#id").val(v.id);
                 //$('[name="medida"]').val(v.unit_measure);
                 if(v.unit_measure == 2)
                 {
                   if(v.existence>100) //convertir a metros
                   {
                     cant = v.existence/100;
                     $("#stock").val(cant);
                     $('[name="medida"]').val(1);
                   }else {
                     $("#stock").val(v.existence);
                     $('[name="medida"]').val(v.unit_measure);
                   }
                 }else{ //piezas
                   $("#stock").val(v.existence);
                   $('[name="medida"]').val(v.unit_measure);
                 }

            });
          },
          error: function (jqXHR, textStatus, errorThrown)
          {
              alert('Error al obtener datos');
          }
      });

    }

    //mostrar el historial de movimientos
    function gethistorialinventario(id)
    {
        //Ajax Load data from ajax
        $.ajax({
          url : "<?php echo site_url('stocktaking/gethistorysupply/')?>"+id,
          type: "GET",
          dataType: "JSON",
          success: function(data)
          {
            console.log(data);
            $(data).each(function(i, v){ // indice, valor
              var movimiento = '';
              if(v.type_mov=='1')
              {
                movimiento = 'Entrada';
              }else if(v.type_mov=='2')
                {
                  movimiento = 'Salida';
                }

              var usuario = v.first_name + ' ' + v.last_name;
              var fecha = v.date_mov.substring(0,10);
              var hora = v.date_mov.substring(11,19);

              if(v.amount>100) //convertir a metros
              {
                cant = v.amount/100;
                cantd = 'mt(s)';
              }else {
                cant = v.amount;
                cantd = 'cm(s)';
              }
              //hacer algo
              var fila='<tr><td>'+fecha+'</td><td>'+hora+'</td><td>'+movimiento+
                 '</td><td>'+cant+' '+cantd+'</td><td>'+v.description+'</td><td>'+usuario+'</td></tr>';
                 //asigna la fila
                 $('#dtDetallesBody tr:last').after(fila);
            });
          },
          error: function (jqXHR, textStatus, errorThrown)
          {
              alert('Error al obtener datos');
          }
      });

    }





   </script>
