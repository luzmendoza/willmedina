<?php defined('BASEPATH') OR exit('No direct script access allowed');?>

   <div class="card">
     <div class="card-header">Inventario Productos</div>
     <div class="card-body">
      <form action="#" id="form" class="form-horizontal">
         <input type="hidden" name="<?php echo $this->security->get_csrf_token_name();?>" value="<?php echo $this->security->get_csrf_hash();?>">

         <div id="errores" class="col-md-10 alert alert-danger respuesta" role="alert" style="display:none;">
         </div>
         <div id="exito" class="col-md-10 alert alert-success respexito" role="alert" style="display:none;">
         </div>

         <input type="hidden" name="arrDetalles" id="arrDetalles" >
         <input  type="hidden" id="id" name="id"><!--id del stock-->
         <input  type="hidden" id="id_product" name="id_product">
         <input  type="hidden" id="id_sucursal" name="id_sucursal">

         <!--Totales-->
           <div class="form-group">
             <div class="form-row">
               <div class="col-md-2">
                 <label for="codigo">Código </label>
                 <input class="form-control" id="autocompletecodigo" name="codigo" type="text" placeholder="ejemplo: wm-p-0001" maxlength="10" tabindex="1" required>
               </div>
               <div class="col-md-2">
                 <label for="nombre">Nombre </label>
                 <input class="form-control" id="autocompleteproduct" name="name" type="text" placeholder="ejemplo: palazzo" maxlength="50" tabindex="2" required>
               </div>
               <div class="col-md-5">
                  <label for="sucursal">Sucursal</label>
                 <input class="form-control" id="autocompletesucursal" name="sucursal" type="text" placeholder="Ingrese sucursal" maxlength="50" tabindex="3" required>
               </div>
               <div class="col-md-1">
                 <label for="stock">Stock Total</label>
                 <input class="form-control" id="stock" name="stock" type="text" placeholder="0" tabindex="4" readonly>
               </div>
             </div>
           </div>
           <!-- SECCION PARA AGREGAR DETALLES-->
             <div class="form-group">
               <div class="form-row">
                 <div class="col-md-5">
                     <div class="table-responsive">
                           <!--tabla para agregar detalles-->
                           <table class="table" id="dtDetalles" name="dtDetalles">
                             <thead>
                               <tr>
                                 <th hidden></th>
                                 <th scope="col">Tamaño
                                   <select class="form-control" id="size" name="size" aria-describedby="sizeHelp"   tabindex="5">
                                   </select>
                                 </th>
                                 <th scope="col">Cantidad
                                   <input class="form-control numeros"  id="cantidad" name="cantidad" type="text" placeholder="0" maxlength="3"  tabindex="6">
                                 </th>
                                 <th scope="col">
                                   <a class="btn btn-primary btn-sm " data-toggle="tooltip" data-placement="top" title="Agregar" onclick="agregardetalles()" href="#">
                                     <i class="fa fa-plus"></i>
                                   </a>
                                 </th>
                               </tr>
                             </thead>

                             <tbody id="dtDetallesBody">
                               <tr>
                                <td hidden></td>
                                 <td></td>
                                 <td></td>
                                 <td></td>
                               </tr>
                             </tbody>


                           </table>

                         </div><!--fin responsive table-->

                     </div>

                     <div class="col-md-5">
                        <label for="cantidad">Comentarios</label>
                       <input class="form-control" id="descripcion" name="descripcion" type="text" placeholder="Agregar comentarios" maxlength="100" tabindex="7" required>
                     </div>

                   </div>
               </div>
   <!--FIN SECCION PARA AGREGAR DETALLES-->


           <div class="form-group">
             <div class="form-row">
               <div class="col-md-8">
               </div>
               <div class="col-md-1">
                 <button type="button" id="btnCancelar" onclick="limpiar()" class="btn btn-danger">Cancelar</button>
               </div>
               <div class="col-md-1">
                 <button type="button" id="btnSave" onclick="save()" class="btn btn-primary">Guardar</button>
               </div>

             </div>
           </div>


<!--historial-->
<div class="form-group">
  <div class="form-row">
    <div class="col-md-10">
        <div class="card" >
          <div class="card-header">Historial de Inventario</div>
            <div class="card-body">

              <div class="table-responsive">

              <!--tabla para agregar detalles-->
              <table class="table" id="dtDetallesH" name="dtDetallesH">
                <thead>
                  <tr>
                    <th>Fecha</th>
                    <th>Hora</th>
                    <th>Tipo Movimiento</th>
                    <th>Cantidad</th>
                    <th>Descripción</th>
                    <th>Usuario</th>
                  </tr>
                </thead>

                <tbody id="dtDetallesHBody">
                  <tr>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                  </tr>
                </tbody>
              </table>

            </div>  <!--responsive <table>-->

              </div>
          </div>
        </div>
      </div>
  </div>



       </form>
     </div>
   </div>


   <script type="text/javascript">
   $(document).ready( function () {
        $('#errores').slideUp();

     // Validar solo numeros
     	$(".numeros").keypress(function (e) {
     	 	if (e.which != 8 && e.which != 0 && (e.which < 48 || e.which > 57)) {
                 return false;
     		}
     	});
      getsizes();

   });// fin ready function

   function validadecimal()
   {

     if (isNaN($("#cantidad")) == true) {
        alert("Inserte una cantidad válida");
        txtAge.focus();
        txtAge.select();
     }
   }

   function save()
   {
      if(validar())
      {
          var url = "<?php echo site_url('stocktaking/addpro')?>";

          // ajax adding data to database
            $.ajax({
              url : url,
              type: "POST",
              data: $('#form').serialize(),
              dataType: "JSON",
              success: function(data)
              {
                 console.log(data);
                 console.log(data.Usuario);
                 if(data.respuesta == 'error')
                 {
                   $(".respuesta").html('<button type="button" class="btn btn-sm close" data-dismiss="alert" aria-label="Close"><i class="fa fa-times" aria-hidden="true"></i> </button>');
                     $(".respuesta").html(data.producto, data.sucursal );
                    $('#errores').slideDown().fadeOut(5000);
                     return false;
                  }else{
                    $(".respexito").html('<button type="button" class="btn btn-sm close" data-dismiss="alert" aria-label="Close"><i class="fa fa-times" aria-hidden="true"></i> </button>');
                    $(".respexito").html("Registro realizado exitosamente");
                     $('#exito').slideDown().fadeOut(5000);
                      //return true;
                      // location.reload();// for reload a page  ?????
                      limpiar();
                  }
              },
              error: function (jqXHR, textStatus, errorThrown)
              {
                  alert('Error al registrar los datos');
              }
          });

      }
   }
   //validar que los datos obligatorios sean ingresados antes de realizar el registro
   function validar()
   {
       var mensaje = 'Campos requeridos:  <br>';
       var respuesta = true;

       if($("#id_product").val()=="" )
       {
         mensaje += 'Producto <br>';
         respuesta = false;
       }
       if($("#id_sucursal").val()=="" )
       {
         mensaje += 'Sucursal <br>';
         respuesta = false;
       }
       if($("#arrDetalles").val()=="")
       {
         mensaje += 'Cantidad y Talla <br>';
         respuesta = false;
       }


       if(respuesta == false)
       {
           $(".respuesta").html('<button type="button" class="btn btn-sm close" data-dismiss="alert" aria-label="Close"><i class="fa fa-times" aria-hidden="true"></i> </button>');
             $(".respuesta").html(mensaje);
            $('#errores').slideDown().fadeOut(5000);
       }
       return respuesta;
   }


   //limpiar todo..
   function limpiar()
   {
     //no eliminar la primera fila nunca
       var trs=$("#dtDetallesBody tr").length;
       for (var i = 0; i < trs-1; i++) {
           $("#dtDetallesBody tr:last").remove();
       }
       var trs2=$("#dtDetallesHBody tr").length;
       for (var i = 0; i < trs2-1; i++) {
           $("#dtDetallesHBody tr:last").remove();
       }

       $("#id_product").val("");
       $("#id").val("");
       $("#stock").val("0");
       $("#cantidad").val("");
       $("#autocompletecodigo").val("");
       $("#autocompleteproduct").val("");
       $("#descripcion").val("");
       $("#arrDetalles").val("");
       $("#autocompletesucursal").val("");
   }

   //autocomplete para recuperar al producto
   var optionscodigo = {
     url: "<?php echo site_url('product/autocomplete')?>", //esta es la data
     getValue: "sku", //este es el valor que busca el autocomplete, puede ser string o funcion
     template: {  //muestra una descripcion sumado al elemento de busqueda, aparece en letra mas pequeña :)
       type: "description",
       fields: {
         description: "name"
       }
     },
     list: {
         match: { //este hace una busqueda por coincidencia
           enabled: true
         },
         sort: { //ordena los datos de la lista
           enabled: true
         },
         onChooseEvent: function() {
           //llenar los combos y cajas
           var nombre = $("#autocompletecodigo").getSelectedItemData().name.trim();
           var id = $("#autocompletecodigo").getSelectedItemData().id;
             $("#autocompleteproduct").val(nombre).trigger("change");
             $("#id_product").val(id).trigger("change");
              // getdetailsinventario(id);
              // gethistorialinventario(id);
         }
       },
     theme: "bootstrap",
     placeholder: "ejemplo: wm-pn-0001",
     adjustWidth: false //linea super necesaria para que se vea la lista en horizontal :) y no letra por letra hacia abajo
   };
   //opcion de busqueda cpor nombre
   var optionsproduct = {
     url: "<?php echo site_url('product/autocomplete')?>", //esta es la data
     getValue: "name", //este es el valor que busca el autocomplete, puede ser string o funcion
     template: {  //muestra una descripcion sumado al elemento de busqueda, aparece en letra mas pequeña :)
       type: "description",
       fields: {
         description: "sku"
       }
     },
     list: {
         match: { //este hace una busqueda por coincidencia
           enabled: true
         },
         sort: { //ordena los datos de la lista
           enabled: true
         },
         onChooseEvent: function() {
           //llenar los combos y cajas
           var code = $("#autocompleteproduct").getSelectedItemData().sku.trim();
           var id = $("#autocompleteproduct").getSelectedItemData().id;
             $("#autocompletecodigo").val(code).trigger("change");
             $("#id_product").val(id).trigger("change");
              // getdetailsinventario(id);
              // gethistorialinventario(id);
         }
       },
     theme: "bootstrap",
     placeholder: "Ejemplo: vestido negro",
     adjustWidth: false //linea super necesaria para que se vea la lista en horizontal :) y no letra por letra hacia abajo
   };

   //autocomplete para recuperar sucursales
   var optionsbranchoffice = {
     url: "<?php echo site_url('branchoffice/autocomplete')?>", //esta es la data
     getValue: "name", //este es el valor que busca el autocomplete, puede ser string o funcion
     template: {  //muestra una descripcion sumado al elemento de busqueda, aparece en letra mas pequeña :)
       type: "description",
       fields: {
         description: "address"
       }
     },
     list: {
         match: { //este hace una busqueda por coincidencia
           enabled: true
         },
         sort: { //ordena los datos de la lista
           enabled: true
         },
         onChooseEvent: function() {
           //llenar los combos y cajas
           var nombre = $("#autocompletesucursal").getSelectedItemData().name.trim();
           var idSuc = $("#autocompletesucursal").getSelectedItemData().id;
             $("#id_sucursal").val(idSuc).trigger("change");

             idProd = $("#id_product").val();
             getdetailsinventario(idProd,idSuc);
             gethistorialinventario(idProd,idSuc);
         }
       },
     theme: "bootstrap",
     placeholder: "Ingrese sucursal",
     adjustWidth: false //linea super necesaria para que se vea la lista en horizontal :) y no letra por letra hacia abajo
   };


   //asignar propiedad autocomplete a los campos
   $("#autocompletecodigo").easyAutocomplete(optionscodigo);
    $("#autocompleteproduct").easyAutocomplete(optionsproduct);
$("#autocompletesucursal").easyAutocomplete(optionsbranchoffice);

    //obtiene la lista de detalles si existe en el inventario
    function getdetailsinventario(idProd,idSuc)
    {
        //Ajax Load data from ajax
        $.ajax({
          url : "<?php echo site_url('stocktaking/getstockproduct/')?>"+idProd+"/"+idSuc,
          type: "GET",
          dataType: "JSON",
          success: function(data)
          {
            console.log(data);
            $(data).each(function(i, v){ // indice, valor
              //hacer algo
                 $("#stock").val(v.stock);
                 //$("#id_product").val(v.id_product);
            });
          },
          error: function (jqXHR, textStatus, errorThrown)
          {
              alert('Error al obtener datos');
          }
      });

    }

    //mostrar el historial de movimientos
    function gethistorialinventario(idProd,idSuc)
    {
        //Ajax Load data from ajax
        $.ajax({
          url : "<?php echo site_url('stocktaking/gethistoryproduct/')?>"+idProd+"/"+idSuc,
          type: "GET",
          dataType: "JSON",
          success: function(data)
          {
            console.log(data);
            $(data).each(function(i, v){ // indice, valor
              var movimiento = '';
              if(v.type_mov=='1')
              {
                movimiento = 'Entrada';
              }else if(v.type_mov=='2')
                {
                  movimiento = 'Salida';
                }

              var usuario = v.first_name + ' ' + v.last_name;
              var fecha = v.date_mov.substring(0,10);
              var hora = v.date_mov.substring(11,19);
              //hacer algo
              var fila='<tr><td>'+fecha+'</td><td>'+hora+'</td><td>'+movimiento+
                 '</td><td>'+v.amount+'</td><td>'+v.description+'</td><td>'+usuario+'</td></tr>';
                 //asigna la fila
                 $('#dtDetallesHBody tr:last').after(fila);
            });
          },
          error: function (jqXHR, textStatus, errorThrown)
          {
              alert('Error al obtener datos');
          }
      });

    }

    //obtiene la lista de tallas disponibles
    function getsizes()
    {
        //Ajax Load data from ajax
        $.ajax({
          url : "<?php echo site_url('size/get_all/')?>",
          type: "GET",
          dataType: "JSON",
          success: function(data)
          {
            console.log('obtiene Tamaños');
            console.log(data);
            //cargar datos en el formulario
            $(data).each(function(i, v){ // indice, valor
                        $("#size").append('<option value="' + v.id + '">' + v.abbreviation + '</option>');
                    })

          },
          error: function (jqXHR, textStatus, errorThrown)
          {
              alert('Error al obtener datos');
          }
      });
    }

    //agrega detalles a la tabla
    function agregardetalles()
    {
        var arrProdDetalles = new Array();
        var nuevafila = true;

        var sizeid = $("#size").val();
        var size = $("#size option:selected").text();
        var cantidad = $("#cantidad").val();

        if(cantidad == "" || cantidad == "0"  )
        {
          alert('ingrese cantidad válida');
        }
        else{
          console.log($('#arrDetalles').val());
            cantidad = parseInt(cantidad);
              //verificar si ya tiene datos el array detalles
              if($('#arrDetalles').val() != '')
              {
                var deserializedDetalles = JSON.parse($('#arrDetalles').val());
                //recorre los datos y asigna la informacion
                for (var i = 0; i < deserializedDetalles.length; i++) {
                   var idS = deserializedDetalles[i][0];
                   var cant = deserializedDetalles[i][1];

                   //validar si ya esta registrado el mismo articulo
                   if(sizeid==idS )
                   {
                       cant = cant+cantidad;
                       nuevafila = false;
                   }

                   var renglon = new Array(idS,cant);
                    arrProdDetalles.push( renglon );
                }
              }

             if(nuevafila)
              {
                    //asignar datos de la fila nueva
                    var renglon = new Array(sizeid,cantidad);
                     arrProdDetalles.push( renglon );
                     //serializar en json el array de detalles
                     var jsonArray = JSON.stringify(arrProdDetalles)
                       //asignar datos al campo hidden
                    $('#arrDetalles').val(jsonArray) ;

                    //crea una nueva fila para la tabla
                      var fila='<tr id='+sizeid+'><td id="sizeid" hidden> ' +sizeid+'</td><td>'+size+'</td><td id="cantidad">'+cantidad+'</td><td><a href="#" class="btn btn-danger btn-sm eliminarFila"  ><i class="fa fa-trash"></i> </a></td></tr>';
                         //asigna la fila
                     $('#dtDetallesBody tr:last').after(fila);
                 }
                 else{
                     console.log('no agrega fila');
                     //serializar en json el array de detalles
                     var jsonArray = JSON.stringify(arrProdDetalles)
                       //asignar datos al campo hidden
                     $('#arrDetalles').val(jsonArray) ;

                      $('#'+sizeid).each(function() {
                        var cantActual = $(this).find("td").eq(2).html();
                        console.log(cantActual);
                        cantActual= parseInt(cantActual)+cantidad;
                         $(this).find("td").eq(2).html(cantActual);
                      });
                 }
                  //limpiar todas
                   $("#cantidad").val('');

      }

    }

   </script>
