<div class="row">
      <div class="col-1">
      <button class="btn btn-primary btn-sm" onclick="add_user()"><i class="fa fa-plus"></i> Agregar usuario</button>
      <p> </p>
      </div>
    </div>


    <!-- Example DataTables Card-->
<div class="card mb-3">
  <div class="card-header">
    <i class="fa fa-table"></i> Listado de Usuarios</div>
  <div class="card-body">
    <div class="table-responsive">
      <table class="table table-bordered" id="dtUsuarios" width="100%" cellspacing="0">
        <thead>
          <tr>
            <th> Usuario </th>
            <th> Nombre </th>
            <!--<th> Tipo </th>-->
            <th style="width:125px;">Acciones
            </p></th>
          </tr>
        </thead>
        <tbody>
          <?php foreach($users as $user): ?>
          <tr>
             <td style="width: 30%" id="user"> <?php echo $user->username ?> </td>
             <td style="width: 50%" id="name"> <?php echo $user->first_name.' '.$user->last_name ?> </td>
          <!--   <td style="width: 30%" id="tipo"> <?php echo $user->description ?> </td>-->
             <td>
                <button class="btn btn-primary btn-sm" data-toggle="tooltip" data-placement="top" title="Editar" onclick="edit_user(<?php echo $user->id;?>)"><i class="fa fa-edit"></i></button>
                <button class="btn btn-danger btn-sm " data-toggle="tooltip" data-placement="top" title="Eliminar" onclick="eliminar(<?php echo $user->id;?>)" ><i class="fa fa-trash"></i></button>

             </td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
  <div class="card-footer small text-muted"></div>
</div>

<script type="text/javascript">
$(document).ready( function () {
     $('#errores').slideUp();

      $('#dtUsuarios').DataTable({
        "language": {
                 "infoFiltered": " - filtrado de _MAX_ registros",
                 "info": "Mostrando página _PAGE_ de _PAGES_",
                 "emptyTable": "No hay datos disponibles en la tabla"
                }
      });


});// fin ready function


  var save_method; //for save method string
  var table;

  //configuraciones para un nuevo producto
  function add_user()
  {
      $('#errores').slideUp();
      save_method = 'add';
      $('#form')[0].reset(); // reset form on modals
      $('#modal_form').modal('show'); // show bootstrap modal
    //$('.modal-title').text('Add Person'); // Set Title to Bootstrap modal title
  }

//metodo para guarda un usuario
  function save()
  {
     if (validar())
     {
          var url = "<?php echo site_url('user/add')?>";

         // ajax adding data to database
              $.ajax({
                url : url,
                type: "POST",
                data: $('#form').serialize(),
                dataType: "JSON",
                success: function(data)
                {
                  console.log(data);
                   if(data.respuesta == 'error')
                   {
                     $(".respuesta").html('<button type="button" class="btn btn-sm close" data-dismiss="alert" aria-label="Close"><i class="fa fa-times" aria-hidden="true"></i> </button>');
                       $(".respuesta").html(data.first_name + data.last_name + data.username + data.email + data.password + data.confirm_password);
                      $('#errores').slideDown().fadeOut(8000);
                       return false;
                    }else{
                      if(data.status == false)
                      {
                          $(".respuesta").html('<button type="button" class="btn btn-sm close" data-dismiss="alert" aria-label="Close"><i class="fa fa-times" aria-hidden="true"></i> </button>');
                          $(".respuesta").html(data.mensaje);
                          $('#errores').slideDown().fadeOut(8000);
                          return false;
                      }
                      else
                      {                     //if success close modal and reload ajax table
                         $('#modal_form').modal('hide');
                         location.reload();// for reload a page
                      }
                    }
                },
                error: function (jqXHR, textStatus, errorThrown)
                {
                    alert('Error al registrar los datos');
                }
            });
      }//fin validar
  }

  //validar que los datos obligatorios sean ingresados antes de realizar el registro
  function validar()
  {
      var mensaje = 'Campos requeridos:  <br>';
      var respuesta = true;

      if($("#first_name").val()=="")
      {
        mensaje += 'Nombre <br>';
        respuesta = false;
      }
      if($("#last_name").val()=="")
      {
        mensaje += 'Apellido  <br>';
        respuesta = false;
      }
      if($("#username").val()=="")
      {
        mensaje += 'Usuario <br>';
        respuesta = false;
      }
      if($("#email").val()=="")
      {
        mensaje += 'Email <br>';
        respuesta = false;
      }
      if(  save_method == 'add')
      {
        if($("#password").val()=="")
        {
          mensaje += 'Contraseña <br>';
          respuesta = false;
        }
        if($("#confirm_password").val()=="")
        {
          mensaje += 'Confirmar Contraseña <br>';
          respuesta = false;
        }
      }

      if(respuesta == false)
      {
          $(".respuesta").html('<button type="button" class="btn btn-sm close" data-dismiss="alert" aria-label="Close"><i class="fa fa-times" aria-hidden="true"></i> </button>');
            $(".respuesta").html(mensaje);
           $('#errores').slideDown().fadeOut(8000);
      }
      return respuesta;
  }

  function edit_user(id)
  {
    $('#errores').slideUp();
    save_method = 'update';
    $('#form')[0].reset(); // reset form on modals

    //Ajax Load data from ajax
    $.ajax({
      url : "<?php echo site_url('user/edit/')?>" + id,
      type: "GET",
      dataType: "JSON",
      success: function(data)
      {

          $('[name="id"]').val(data.id);
          $('[name="username"]').val(data.username);
          $('[name="first_name"]').val(data.first_name);
          $('[name="last_name"]').val(data.last_name);
          $('[name="email"]').val(data.email);

          for (var i = 0; i < data.arrGrupos.length; i++)
          {
             switch (data.arrGrupos[i]['group_id']) {
               case "1": //administrador
                    $("#ckbAdmin").attr('checked', true);
                 break;
               case "2": //usuario general,clientes
                    $("#ckbmember").attr('checked', true);
                 break;
               case "3"://empleados
                    $("#ckbEmploye").attr('checked', true);
                 break;

             }
          }

          //$('[name="password"]').val(data.password);
          $("#username").attr('disabled', true);
          $("#password").attr('disabled', true);
          $("#confirm_password").attr('disabled', true);

          $('#modal_form').modal('show'); // show bootstrap modal when complete loaded
          $('.modal-title').text('Editar Usuario'); // Set title to Bootstrap modal title

      },
      error: function (jqXHR, textStatus, errorThrown)
      {
          alert('Error al obtener datos');
      }
  });
  }

  //eliminamos datos
  function eliminar(id)
     {
        $('#id_delet').val(id);//enviar id de control al modal
        $('#modalEliminar').modal('show'); // abrir
    };

    function delete_user()
    {
          id = $('#id_delet').val();//recuperar id de control al modal
            console.log('eliminar '+id);
        // ajax delete data from database
          $.ajax({
            url : "<?php echo site_url('user/delete/')?>"+id,
            type: "POST",
            dataType: "JSON",
            success: function(data)
            {
               location.reload();
            },
            error: function (jqXHR, textStatus, errorThrown)
            {
                alert('Error al eliminar información');
            }
        });
    }

</script>

<!-- Bootstrap modal -->
<div class="modal fade" id="modal_form" role="dialog">
<div class="modal-dialog modal-lg">
  <div class="modal-content">
    <div class="modal-header">
    <!--  <button type="button" class="btn btn-danger btn-sm" data-dismiss="modal" aria-label="Close"><i class="fa fa-times" aria-hidden="true"></i></button> -->
      <h4 class="modal-title">Nuevo Usuario</h4>
      <button type="button" class="btn btn-sm" data-dismiss="modal" aria-label="Close"><i class="fa fa-times" aria-hidden="true"></i></button>
    </div>


    <div class="modal-body form">
      <form action="#" id="form" class="form-horizontal">

        <div class="form-body">

          <!--mostrar mensajes de error/validacion-->
          <div id="errores" class="col-md-10 alert alert-danger respuesta" role="alert" style="display:none;">
          </div>

          <!--campos ocultos del formulario-->
          <input type="hidden" name="id" id="id" >

    <!--campos visibles del formulario-->
          <div class="form-group">
            <div class="form-row">
              <div class="col-md-6">
                <label for="first_name">Nombre</label>
                <input class="form-control" id="first_name" name="first_name" type="text" aria-describedby="first_nameHelp" placeholder="Ingrese Nombre" required tabindex="1">
             <!--   oninvalid="this.setCustomValidity('Por favor ingrese un nombre')">-->
              </div>
              <div class="col-md-6">
                <label for="last_name">Apellido</label>
                <input class="form-control" id="last_name" name="last_name" type="text" aria-describedby="last_nameHelp"  placeholder="Ingrese Apellido" required tabindex="2">
              </div>
            </div>
          </div>
          <div class="form-group">
            <label for="username">Usuario</label>
            <input class="form-control" id="username" name="username" type="text" aria-describedby="usernameHelp"  placeholder="Ingrese nombre de usuario" required tabindex="3">
          </div>
          <div class="form-group">
            <label for="email">Email</label>
            <input class="form-control" id="email" name="email" type="email" aria-describedby="emailHelp"  placeholder="Ingrese email" required tabindex="4">
          </div>
          <div class="form-group">
            <div class="form-row">
              <div class="col-md-6">
                <label for="password">Contraseña</label>
                <input class="form-control" id="password" name="password" type="password"  placeholder="Contraseña" required tabindex="5">
              </div>
              <div class="col-md-6">
                <label for="confirm_password">Confirmar Contraseña</label>
                <input class="form-control" id="confirm_password" name="confirm_password" type="password" placeholder="Confirmar Contraseña" required tabindex="6">
              </div>
            </div>
          </div>


          <div class="form-group">
              <label for="confirm_password"><b>Grupos</b></label>
          </div>

          <div class="form-group">
              <div class="form-row">
                <div class="col-md-2">
                  <div class="form-check">
                    <input type="checkbox" class="form-check-input" id="ckbAdmin" name="ckbAdmin" data-toggle="tooltip" data-placement="top" title="Acceso a todo el sistema">
                    <label class="form-check-label" for="ckbAdmin" data-toggle="tooltip" data-placement="top" title="Acceso a todo el sistema">Administrador</label>
                  </div>
                </div>
                <div class="col-md-2">
                  <div class="form-check">
                    <input type="checkbox" class="form-check-input" id="ckbEmploye" name="ckbEmploye" data-toggle="tooltip" data-placement="top" title="Acceso a funciones de venta">
                    <label class="form-check-label" for="ckbEmploye" data-toggle="tooltip" data-placement="top" title="Acceso a funciones de venta">Empleado</label>
                  </div>
                </div>
                <div class="col-md-2">
                  <div class="form-check">
                    <input type="checkbox" class="form-check-input" id="ckbmember" name="ckbmember" data-toggle="tooltip" data-placement="top" title="Acceso a funciones de cliente">
                    <label class="form-check-label" for="ckbmember" data-toggle="tooltip" data-placement="top" title="Acceso a funciones de cliente">General</label>
                  </div>
                </div>
              </div>
          </div>

        </div>
      </form>
        </div>
        <div class="modal-footer">
          <button type="button" id="btnSave" onclick="save()" class="btn btn-primary">Guardar</button>
          <button type="button" class="btn btn-danger"  data-dismiss="modal">Cancelar</button>
        </div>
      </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
  </div><!-- /.modal -->
<!-- End Bootstrap modal -->



  <!-- Modal Eliminar-->
  <div class="modal fade" id="modalEliminar" tabindex="-1" role="dialog" aria-labelledby="modalEliminarLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="modalEliminarLabel">¿Seguro desea eliminar este usuario?</h5>
        <button class="close" type="button" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">×</span>
        </button>
      </div>
      <input type="hidden" value="" name="id_delet" id="id_delet"/>
    <!--  <div class="modal-body">Seleccione "Eliminar" si está seguro de la acción.</div>-->
      <div class="modal-footer">
        <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancelar</button>
          <button type="button" id="btnSave" onclick="delete_user()" class="btn btn-primary">Eliminar</button>
      </div>
    </div>
  </div>
  </div>
