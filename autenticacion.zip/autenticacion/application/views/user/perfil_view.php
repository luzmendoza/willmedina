<?php defined('BASEPATH') OR exit('No direct script access allowed');?>



   <div class="card">
     <div class="card-header">Mi Perfil</div>
     <div class="card-body">
      <form action="#" id="form" class="form-horizontal">

         <div id="errores" class="col-md-10 alert alert-danger respuesta" role="alert" style="display:none;">
         </div>
         <div id="exito" class="col-md-10 alert alert-success respexito" role="alert" style="display:none;">
         </div>

         <input type="hidden" id="csrf" name="<?php echo $this->security->get_csrf_token_name();?>" value="<?php echo $this->security->get_csrf_hash();?>">
        <input type="hidden" name="id_user" id="id_user" value="<?php echo $id; ?>" >


         <div class="form-group">
           <div class="form-row">
             <div class="col-md-6 " >
                   <label for="username">Usuario</label>
                   <input class="form-control"  id="username" name="username" type="text" aria-describedby="nombre_dateHelp"  maxlength="50"  tabindex="0" value="<?php echo $username; ?>" readonly></input>
             </div>
           </div>
         </div>
         <div class="form-group">
           <div class="form-row">
             <div class="col-md-3 " >
                   <label for="name">Nombre</label>
                   <input class="form-control"  id="first_name" name="first_name" type="text" aria-describedby="nombre_dateHelp"  maxlength="50"  tabindex="1" value="<?php echo $first_name; ?>" required></input>
             </div>
             <div class="col-md-3 " >
                   <label for="name">Apellido</label>
                   <input class="form-control"  id="last_name" name="last_name" type="text" aria-describedby="nombre_dateHelp"  maxlength="50"  tabindex="2" value="<?php echo $last_name; ?>" required></input>
             </div>
           </div>
         </div>

         <div class="form-group">
           <div class="form-row">
             <div class="col-md-3 " >
                   <label for="phone">Telefono</label>
                   <input class="form-control"  id="phone" name="phone" type="text" aria-describedby="nombre_dateHelp"  maxlength="10"  tabindex="3" value="<?php echo $phone; ?>" required></input>
             </div>
             <div class="col-md-3 " >
                   <label for="name">email</label>
                   <input class="form-control"  id="email" name="email" type="email" aria-describedby="nombre_dateHelp"  maxlength="50"  tabindex="4" value="<?php echo $email; ?>" required></input>
             </div>
           </div>
         </div>



<!--pie de pagina... botones-->
        <div class="form-group">
          <div class="form-row">
          <!--  <div class="col-md-1">
              <button type="button" id="btnCancel" onclick="cancel()" class="btn btn-danger">Cancelar</button>
            </div>
          -->
            <div class="col-md-1">
              <button type="button" id="btnSave" onclick="save()" class="btn btn-primary">Guardar</button>
            </div>
          </div>
        </div>
       </form>
     </div>
   </div>


<script type="text/javascript">

function validar()
{
  var resp = false;
  var first_name = "<?php echo $first_name; ?>";
  var last_name = "<?php echo $last_name; ?>";
  var phone = "<?php echo $phone; ?>";
  var email = "<?php echo $email; ?>";
  console.log(first_name);
  console.log(last_name);
  console.log(phone);
  console.log(email);
  //validar que haya sido modificado algo
  if($("#first_name").val()!=first_name)
  {
    resp = true;
  }
  if($("#last_name").val()!=last_name)
  {
    resp = truetrue;
  }
  if($("#phone").val()!=phone)
  {
    resp = true;
  }
  if($("#email").val()!=email)
  {
    resp = true;
  }

  return resp;
}

function save()
{
   if (validar())
   {
     console.log('valido');
        var url = "<?php echo site_url('user/update')?>";

         // ajax adding data to database
            $.ajax({
              url : url,
              type: "POST",
              data: $('#form').serialize(),
              dataType: "JSON",
              success: function(data)
              {
                 if(data.respuesta == 'error')
                 {
                   $(".respuesta").html('<button type="button" class="btn btn-sm close" data-dismiss="alert" aria-label="Close"><i class="fa fa-times" aria-hidden="true"></i> </button>');
                     $(".respuesta").html(data.first_name + data.last_name + data.email + data.phone  );
                    $('#errores').slideDown().fadeOut(5000);
                     return false;
                  }else{
                     //if success close modal and reload ajax table
                     $(".respexito").html('<button type="button" class="btn btn-sm close" data-dismiss="alert" aria-label="Close"><i class="fa fa-times" aria-hidden="true"></i> </button>');
                     $(".respexito").html("Datos actualizados exitosamente");
                      $('#exito').slideDown().fadeOut(5000);
                     //location.reload();// for reload a page
                  }
              },
              error: function (jqXHR, textStatus, errorThrown)
              {
                console.log(errorThrown);
                  alert('Error al registrar los datos');
              }
          });
    }//fin validar
    else{
      alert('Favor de modificar los datos a actualizar.');
    }
}
</script>
