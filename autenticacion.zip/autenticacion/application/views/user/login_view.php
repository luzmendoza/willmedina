<?php defined('BASEPATH') OR exit('No direct script access allowed');?>
<div class="container">
	<?php
    echo isset($_SESSION['auth_message']) ? $_SESSION['auth_message'] : FALSE;
    ?>
	 <div class="card card-login mx-auto mt-5">
		 <div class="card-header">Iniciar Sesión</div>
		 <div class="card-body">
			 <form  method="post" action="<?php echo base_url()."user/login" ?>" >
				 <!--<div class="form-group">
					 <label for="exampleInputEmail1">Email address</label>
					 <input class="form-control" id="exampleInputEmail1" type="email" aria-describedby="emailHelp" placeholder="Enter email">
				 </div>-->
				 <input type="hidden" name="<?php echo $this->security->get_csrf_token_name();?>" value="<?php echo $this->security->get_csrf_hash();?>">

				 <div class="form-group">
					 <label for="username">Usuario</label>
					 <input class="form-control" id="username" name="username" type="text" aria-describedby="usernameHelp" placeholder="Ingrese usuario">
				 </div>
				 <div class="form-group">
					 <label for="password">Contraseña</label>
					 <input class="form-control" id="password" name="password" type="password" placeholder="Contraseña">
				 </div>
				 <div class="form-group">
					 <div class="form-check">
						 <label class="form-check-label">
							 <input class="form-check-input" name="remember" id="remember" type="checkbox"> Recordar Contraseña</label>
					 </div>
				 </div>
				<!-- <a class="btn btn-primary btn-block" href="">Iniciar Sesión</a>-->
				  <input type="submit" class="btn btn-primary btn-block" value="Iniciar Sesión" />
			 </form>
			 <div class="text-center">
				 <a class="d-block small mt-3" href="<?php echo base_url() ?>register">Registrar una cuenta</a>
				 <a class="d-block small" href="<?php echo base_url() ?>register/recuperarPass">Se te olvidó tu Contraseña?</a>

			 </div>
		 </div>
	 </div>
 </div>
