<?php defined('BASEPATH') OR exit('No direct script access allowed');?>

   <div class="card">
     <div class="card-header">Registro de Permisos de Acceso</div>
     <div class="card-body">
      <form action="#" id="form" class="form-horizontal">
         <input type="hidden" name="<?php echo $this->security->get_csrf_token_name();?>" value="<?php echo $this->security->get_csrf_hash();?>">

         <div id="errores" class="col-md-10 alert alert-danger respuesta" role="alert" style="display:none;">
         </div>
         <div id="exito" class="col-md-10 alert alert-success respexito" role="alert" style="display:none;">
         </div>

        <input type="hidden" name="arrDetalles" id="arrDetalles" >
        <input type="hidden" name="iduser" id="iduser" >

      <!--informacion del formulario-->
         <div class="form-group">
           <div class="form-row">
             <div class="col-md-8">
               <label for="user">Usuario</label>
                <input class="form-control" id="autocomplete" name="usuario" type="text" aria-describedby="usuarioHelp"  maxlength="100"  tabindex="1" required>
             </div>
           </div>
         </div>

         <!-- SECCION PARA AGREGAR DETALLES-->
                   <div class="form-group">
                     <div class="form-row">
                       <div class="col-md-10">


                           <div class="table-responsive">
                                 <!--tabla para agregar detalles-->
                                 <table class="table" id="dtDetalles" name="dtDetalles">
                                   <thead>
                                     <tr>
                                       <th hidden>
                                         <input  type="hidden" id="id_menu" name="id_menu">
                                       </th>
                                       <th scope="col">Menu
                                       </th>
                                       <th scope="col">Submenu
                                       </th>
                                       <th scope="col">Dar Permiso
                                       </th>

                                     </tr>
                                   </thead>

                                   <tbody id="dtDetallesBody">
                                     <tr>
                                       <td hidden></td>
                                       <td></td>
                                       <td></td>
                                       <td></td>
                                     </tr>
                                   </tbody>


                                 </table>

                               </div><!--fin responsive table-->

                           </div>
                         </div>
                     </div>

<!--pie de pagina... botones-->
        <div class="form-group">
          <div class="form-row">
            <div class="col-md-1">
              <button type="button" id="btnCancel" onclick="cancel()" class="btn btn-danger">Cancelar</button>
            </div>
            <div class="col-md-1">
            </div>
            <div class="col-md-1">
              <button type="button" id="btnSave" onclick="save()" class="btn btn-primary">Guardar</button>
            </div>
          </div>
        </div>
       </form>
     </div>
   </div>


   <script type="text/javascript">
   $(document).ready( function () {
      //obtener todos los permisos
      getmenu();

     //autocomplete para recuperar al usuario
     var options = {
       //data: ["blue", "green", "pink", "red", "yellow"],
       url: "<?php echo site_url('user/autocomplete')?>", //esta es la data
       //getValue: "first_name", //este es el valor que busca el autocomplete, puede ser string o funcion :)
       getValue: function(element) {
         var nombre = element.first_name + ' '+ element.last_name;
         return nombre;
       },
       template: {  //muestra una descripcion sumado al elemento de busqueda, aparece en letra mas pequeña :)
         type: "description",
         fields: {
           description: "username"
         }
       },
       list: {
           match: { //este hace una busqueda por coincidencia
             enabled: true
           },
           sort: { //ordena los datos de la lista
             enabled: true
           },
           onChooseEvent: function() {
             //alert("item seleccionado !");
             var nombre = $("#autocomplete").getSelectedItemData().first_name;
             var apellido = $("#autocomplete").getSelectedItemData().last_name;
             var userid = $("#autocomplete").getSelectedItemData().id;
               $("#first_name").val(nombre).trigger("change");
               $("#last_name").val(apellido).trigger("change");
               $("#iduser").val(userid).trigger("change");

               //buscar y actualizar los permisos de este usuario
               getpermisouser(userid);
           }
         },
       theme: "bootstrap",
       placeholder: "Ingresar nombre",
       adjustWidth: false //linea super necesaria para que se vea la lista en horizontal :) y no letra por letra hacia abajo
     };

     $("#autocomplete").easyAutocomplete(options);
   });// fin ready function

   function cancel()
   {
       location.reload();
   }
   //obtiene la lista de menu
   function getmenu()
   {
       //Ajax Load data from ajax
       $.ajax({
         url : "<?php echo site_url('permisos/get_menu')?>",
         type: "GET",
         dataType: "JSON",
         success: function(data)
         {
           //cargar datos en el formulario
           $(data).each(function(i, v){ // indice, valor

             //crea una nueva fila para la tabla
               var fila='<tr><td hidden> <input hidden name="id_menu" value="' +v.id+'" /></td><td> ' +v.menu+'</td><td> ' +v.submenu+
               '</td><td><input type="checkbox"  class="form-control"  name="checkpermiso" /></td></tr>';
                  //asigna la fila
              $('#dtDetallesBody tr:last').after(fila);

           })

         },
         error: function (jqXHR, textStatus, errorThrown)
         {
             alert('Error al obtener datos');
         }
     });
   }

   function save()
   {
     //valida tenga usuario para asignarle permisos
     if($("#iduser").val()!='')
     {
       var continuar = false;
       var arrProdDetalles = new Array();
        //validar que seleccione por lo menos un permiso
        $('#dtDetallesBody tr').each(function(index, element){
            if (index>0)
            {
              var IDMenu = $(element).find("td [name=id_menu]").val();

              if ($(element).find("td [name=checkpermiso]").prop('checked'))
              {
                //agregar datos al array y cambiar el continuar
                continuar = true;
                var renglon = new Object();
                renglon['id_user'] = $("#iduser").val();
                renglon['id_menu'] = IDMenu;

               arrProdDetalles.push( renglon );
              }
            }
        });


        if(continuar)
        {
          //serializar en json el array de detalles
          var jsonArray = JSON.stringify(arrProdDetalles)
          //asignar datos al campo hidden
          $('#arrDetalles').val(jsonArray);
          //llamado ajax
          var url = "<?php echo site_url('permisos/add')?>";
          // ajax adding data to database
           $.ajax({
              url : url,
              type: "POST",
              data: $('#form').serialize(),
              dataType: "JSON",
              success: function(data)
              {
                 if(data.status == false)
                 {
                   $(".respuesta").html('<button type="button" class="btn btn-sm close" data-dismiss="alert" aria-label="Close"><i class="fa fa-times" aria-hidden="true"></i> </button>');
                     $(".respuesta").html(data.mensaje);
                    $('#errores').slideDown().fadeOut(8000);
                     return false;
                  }else{
                    location.reload();
                  }
              },
              error: function (jqXHR, textStatus, errorThrown)
              {
                  alert('Error al registrar los datos');
              }
          });
        }
        else{
          alert("Debe seleccionar al menos una opción del menu");
        }

     }else {
       alert('Debe ingresar un usuario para asignarle permisos');
     }
   }

   function getpermisouser(user)
   {
         //Ajax Load data from ajax
         $.ajax({
           url : "<?php echo site_url('permisos/get_usermenu/')?>"+user,
           type: "GET",
           dataType: "JSON",
           success: function(data)
           {
             //cargar datos en el formulario
             $(data).each(function(i, v){ // indice, valor
                  //seleccionar los que tengan permiso
                  //recorrer la tabla de menu y validar si el id obtenido se encuentra en el
                  $('#dtDetallesBody tr').each(function(index, element){

                      if(index>0)
                      {
                        var IDMenu = $(element).find("td [name=id_menu]").val(),
                            checkpermiso = $(element).find("td [name=checkpermiso]").val();

                         if(v.id_menu == IDMenu)
                         {
                           console.log('actualizar');
                           $(element).find("td [name=checkpermiso]").attr('checked', true);
                         }
                      }
                    });
             })

           },
           error: function (jqXHR, textStatus, errorThrown)
           {
               alert('Error al obtener datos');
           }
       });
   }


   </script>
