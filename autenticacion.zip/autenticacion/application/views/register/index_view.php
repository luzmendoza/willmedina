<?php defined('BASEPATH') OR exit('No direct script access allowed');?>


<div class="container">
  <?php
    echo isset($_SESSION['auth_message']) ? $_SESSION['auth_message'] : FALSE;
    ?>
    <?php if (validation_errors()): ?>
       <div class="alert alert-danger" role="alert">
         <button type="button" class="close" data-dismiss="alert" aria-label="Close">
           <span aria-hidden="true">&times;</span>
         </button>
          <?php echo validation_errors(); ?>
       </div>
    <?php endif; ?>


   <div class="card card-register mx-auto mt-5">
     <div class="card-header">Registrar una cuenta</div>
     <div class="card-body">
       <form id="register-form" method="post" href="<?php echo base_url() ?>register">
         <input type="hidden" name="<?php echo $this->security->get_csrf_token_name();?>" value="<?php echo $this->security->get_csrf_hash();?>">
         <div class="form-group">
           <div class="form-row">
             <div class="col-md-6">
               <label for="first_name">Nombre</label>
               <input class="form-control" id="first_name" name="first_name" type="text" aria-describedby="first_nameHelp" value="<?php echo $first_name; ?>" placeholder="Ingrese Nombre" required tabindex="1">
            <!--   oninvalid="this.setCustomValidity('Por favor ingrese un nombre')">-->
             </div>
             <div class="col-md-6">
               <label for="last_name">Apellido</label>
               <input class="form-control" id="last_name" name="last_name" type="text" aria-describedby="last_nameHelp" value="<?php echo $last_name; ?>" placeholder="Ingrese Apellido" required tabindex="2">
             </div>
           </div>
         </div>
         <div class="form-group">
           <label for="username">Usuario</label>
           <input class="form-control" id="username" name="username" type="text" aria-describedby="usernameHelp" value="<?php echo $username; ?>" placeholder="Ingrese nombre de usuario" required tabindex="3">
         </div>
         <div class="form-group">
           <label for="email">Email</label>
           <input class="form-control" id="email" name="email" type="email" aria-describedby="emailHelp" value="<?php echo $email; ?>" placeholder="Ingrese email" required tabindex="4">
         </div>
         <div class="form-group">
           <div class="form-row">
             <div class="col-md-6">
               <label for="password">Contraseña</label>
               <input class="form-control" id="password" name="password" type="password" value="<?php echo $password; ?>" placeholder="Contraseña" required tabindex="5">
             </div>
             <div class="col-md-6">
               <label for="confirm_password">Confirmar Contraseña</label>
               <input class="form-control" id="confirm_password" name="confirm_password" value="<?php echo $confirm_password; ?>" type="password" placeholder="Confirmar Contraseña" required tabindex="6">
             </div>
           </div>
         </div>
        <!-- <a class="btn btn-primary btn-block" id="register" href="<?php //echo base_url() ?>register">Registrar</a>-->
        <input type="submit" class="btn btn-primary btn-block" value="Registrar" />
       </form>
       <div class="text-center">
         <a class="d-block small mt-3" href="<?php echo base_url() ?>user/login">Iniciar Sesión</a>
         <a class="d-block small" href="forgot-password.html">¿Se te olvidó tu Contraseña?</a>
       </div>
     </div>
   </div>
 </div>

<!--
<script src="/autenticacion/js/jquery.validate.min.js"></script>
<script src="/autenticacion/application/js/register.js"></script>
-->
