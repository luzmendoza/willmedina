
<?php defined('BASEPATH') OR exit('No direct script access allowed');?>
<div class="container">
   <div class="card card-login mx-auto mt-5">
     <div class="card-header">Restablecer Contraseña</div>
     <div class="card-body">
       <div class="text-center mt-4 mb-5">
         <h4>¿Olvidaste tu Contraseña?</h4>
         <p>Ingrese su dirección de correo electrónico y le enviaremos instrucciones sobre cómo restablecer su contraseña.</p>
       </div>
       <form>
         <div class="form-group">
           <input class="form-control" id="emailrest" name="emailrest" type="email" aria-describedby="emailHelp" placeholder="Ingrese email">
         </div>
         <a class="btn btn-primary btn-block" href="login.html">Reset Password</a>
       </form>
       <div class="text-center">
          <a class="d-block small mt-3" href="<?php echo base_url() ?>register">Registrar una cuenta</a>
          <a class="d-block small mt-3" href="<?php echo base_url() ?>user/login">Iniciar Sesión</a>
       </div>
     </div>
   </div>
 </div>
