<?php defined('BASEPATH') OR exit('No direct script access allowed');?>

<div class="row">
  <div class="col-lg-8">
      <div class="card mb-3">
       <div class="card-header">
         <i class="fa fa-bar-chart"></i> Ventas</div>
       <div class="card-body">
         <div class="row">
           <div class="col-sm-8 my-auto">
             <canvas id="myBarChart" width="100" height="50"></canvas>
           </div>
           <div class="col-sm-4 text-center my-auto">
             <div class="h4 mb-0 text-primary" id="ingresos"></div>
             <div class="small text-muted">Ingresos</div>
             <hr>
             <div class="h4 mb-0 text-warning" id="egresos"></div>
             <div class="small text-muted">Egresos</div>
             <hr>
             <!--<div class="h4 mb-0 text-success">$16,219</div>
             <div class="small text-muted">YTD Margin</div>-->
           </div>
         </div>
       </div>
       <div class="card-footer small text-muted">Información del mes actual.</div>
      </div>
  </div>

<!--  <div class="col-lg-4">
      <!-- Example Pie Chart Card-->
  <!--    <div class="card mb-3">
        <div class="card-header">
          <i class="fa fa-pie-chart"></i>Lo más vendido</div>
        <div class="card-body">
          <canvas id="myPieChart" width="100%" height="75"></canvas>
        </div>
        <div class="card-footer small text-muted">Información del mes actual.</div>
      </div>
  </div>-->

</div>





<script type="text/javascript">
   $(document).ready( function () {
      graficaventas();
      //graficaventasporestilo();
   });




//crear grafica de ventas
function graficaventas()
{
    //Ajax Load data from ajax
    $.ajax({
      url : "<?php echo site_url('sales/graficasventas')?>",
      type: "GET",
      dataType: "JSON",
      success: function(data)
      {
        console.log(data);
        var titulos = [];
        var datos = [];
        var totalingresos = 0;
        var egresos = 0;

          //cargar datos en el formulario
          $(data).each(function(i, v){ // indice, valor
              console.log(i);
              console.log(v.fecha);
              titulos.push(v.fecha); //se agregan los titulos de fecha
              datos.push(v.totaldinero);//se agregan cantidades de ventas
              totalingresos +=parseInt(v.totaldinero);
              egresos=parseInt(v.egresos);
          })


          $("#ingresos").html("$" + new Intl.NumberFormat("en-IN").format(totalingresos));
          $("#egresos").html("$" + new Intl.NumberFormat("en-IN").format(egresos));

          var ctx = document.getElementById("myBarChart");//obtener el canvas en el que se dibujara
          var myLineChart = new Chart(ctx, {
            type: 'bar',
            data: {
              labels: titulos,
              datasets: [{
                label: "Ingresos",
                backgroundColor: "rgba(2,117,216,1)",
                borderColor: "rgba(2,117,216,1)",
                data: datos,
              }],
            },
            options: {
              responsive: true,
              scales: {
                xAxes: [{
                  time: {
                    unit: 'day'
                  },
                  gridLines: {
                    display: false
                  },
                  ticks: {
                    maxTicksLimit: 6
                  }
                }],
                yAxes: [{
                  ticks: {
                    min: 0,
                    max: 50000,
                    maxTicksLimit: 5
                  },
                  gridLines: {
                    display: true
                  }
                }],
              },
              legend: {
                display: false
              }
            }
          });

      },
      error: function (jqXHR, textStatus, errorThrown)
      {
          alert('Error al obtener datos');
      }
  });
}


function graficaventasporestilo()
{
  var ctx = document.getElementById("myPieChart");
  var myPieChart = new Chart(ctx, {
  type: 'pie',
  data: {
    //labels: ["Blue", "Red", "Yellow", "Green"],
    labels: ["Blue", "Red", "Yellow", "Green"],
    datasets: [{
      data: [12.21, 15.58, 11.25, 8.32],
      backgroundColor: ['#007bff', '#dc3545', '#ffc107', '#28a745'],
    }],
  },
  });
}
</script>
