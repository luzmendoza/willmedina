<?php defined('BASEPATH') OR exit('No direct script access allowed');?>
<!DOCTYPE html>
<html> <!-- <html lang="en">-->
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" value="Administracion y tienda virtual"  content="">
    <meta name="author" content="Luz Mendoza">
    <title>Will Medina</title>
  <!--  <script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>-->

    <!-- Bootstrap core CSS-->
  <link rel="stylesheet" type="text/css" href="<?php echo base_url('vendor/bootstrap/css/bootstrap.min.css')?>">
  <!-- Custom fonts for this template-->
  <link rel="stylesheet" type="text/css" href="<?php echo base_url('vendor/font-awesome/css/font-awesome.min.css')?>">
  <!-- Page level plugin CSS-->
  <link rel="stylesheet" type="text/css" href="<?php echo base_url('vendor/datatables/dataTables.bootstrap4.css')?>" rel="stylesheet">
  <!-- Custom styles for this template-->
  <link rel="stylesheet" type="text/css" href="<?php echo base_url('css/sb-admin.css')?>">
  <!--css de bootstrap-datepicker-->
    <link rel="stylesheet" type="text/css" href="<?php echo base_url('css/bootstrap-datepicker.min.css')?>">
    <link rel="stylesheet" type="text/css" href="<?php echo base_url('css/easy-autocomplete.min.css')?>">
    <link rel="stylesheet" type="text/css" href="<?php echo base_url('css/easy-autocomplete.themes.min.css')?>">




  <script src="<?php echo base_url('js/jquery-3.3.1.min.js')?>"></script>
  <!-- Bootstrap core JavaScript-->
  <script src="<?php echo base_url('vendor/jquery/jquery.min.js')?>"></script>
  <script src="<?php echo base_url('vendor/bootstrap/js/bootstrap.bundle.min.js')?>"></script>
 <!-- Core plugin JavaScript-->
  <script src="<?php echo base_url('vendor/jquery-easing/jquery.easing.min.js')?>"></script>
  <!-- Page level plugin JavaScript-->
  <script src="<?php echo base_url('vendor/chart.js/Chart.min.js')?>"></script>
  <script src="<?php echo base_url('vendor/datatables/jquery.dataTables.js')?>"></script>
  <script src="<?php echo base_url('vendor/datatables/dataTables.bootstrap4.js')?>"></script>
  <!-- Custom scripts for all pages-->
   <script src="<?php echo base_url('js/sb-admin.min.js')?>"></script>
   <script src="<?php echo base_url('js/sb-admin-datatables.min.js')?>"></script>
   <!-- <script src="/autenticacion/js/sb-admin-charts.min.js"></script>-->

<!--datepicker-->
 <script src="<?php echo base_url('js/bootstrap-datepicker.min.js')?>"></script>
 <script src="<?php echo base_url('js/locales/bootstrap-datepicker.es.min.js')?>"></script>


 <script type="text/javascript" src="<?php echo base_url('js/jquery.easy-autocomplete.min.js')?>"></script>

</head>
<body class="fixed-nav sticky-footer bg-dark" id="page-top">

  <!-- Navigation-->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top" id="mainNav">
        <a class="navbar-brand" href="<?php echo base_url(); ?>">Will Medina</a>
      <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarResponsive">
        <ul class="navbar-nav navbar-sidenav" id="exampleAccordion">
          <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Tablero">
            <a class="nav-link" href="index.html">
              <i class="fa fa-fw fa-dashboard"></i>
              <span class="nav-link-text">Tablero</span>
            </a>
          </li>
        <!--  <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Ventas">
            <a class="nav-link" href="<?php echo base_url(); ?>sales">
              <i class="fa fa-shopping-cart"></i>
              <span class="nav-link-text">Ventas</span>
            </a>
          </li>-->

          <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Caja">
            <a class="nav-link nav-link-collapse collapsed" data-toggle="collapse" href="#collapseVentas" data-parent="#exampleAccordion">
              <i class="fa fa-shopping-cart"></i>
              <span class="nav-link-text">Caja</span>
            </a>
            <ul class="sidenav-second-level collapse" id="collapseVentas">
              <?php
                  if (isset($_SESSION['salesventas']))
                  {
                    echo "
                    <li>
                      <a href='"?><?php echo base_url(); ?><?php echo "sales/ventas'>Ventas</a>
                    </li> ";
                } ?>
                <?php
                    if (isset($_SESSION['sales']))
                    {
                      echo "
                      <li>
                        <a href='"?><?php echo base_url(); ?><?php echo "sales'>Cancelaciones y Devoluciones</a>
                      </li> ";
                  } ?>

            <!--  <li>
                <a href="<?php //echo base_url(); ?>sales">Cancelaciones y Devoluciones</a>
              </li>-->
              <?php
                  if (isset($_SESSION['salesretiros']))
                  {
                    echo "
                    <li>
                      <a href='"?><?php echo base_url(); ?><?php echo "sales/retiros'>Retiros</a>
                    </li> ";
                } ?>
                <?php
                    if (isset($_SESSION['salescorte']))
                    {
                      echo "
                      <li>
                        <a href='"?><?php echo base_url(); ?><?php echo "sales/corte'>Corte</a>
                      </li> ";
                  } ?>
            </ul>
        </li>

          <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Catalogos">
            <a class="nav-link nav-link-collapse collapsed" data-toggle="collapse" href="#collapseCatalogos" data-parent="#exampleAccordion">
              <i class="fa fa-folder-open-o"></i>
              <span class="nav-link-text">Catalogos</span>
            </a>
            <ul class="sidenav-second-level collapse" id="collapseCatalogos">

              <?php
                  if (isset($_SESSION['user']))
                  {
                    echo "
                    <li>
                      <a href='"?><?php echo base_url(); ?><?php echo "user'>Usuarios</a>
                    </li> ";
                }
                if (isset($_SESSION['customer']))
                {
                  echo "
                  <li>
                    <a href='"?><?php echo base_url(); ?><?php echo "customer'>Clientes</a>
                  </li> ";
                }
                if (isset($_SESSION['employe']))
                {
                  echo "
                  <li>
                    <a href='"?><?php echo base_url(); ?><?php echo "employe'>Empleados</a>
                  </li> ";
                }
                if (isset($_SESSION['supply']))
                {
                  echo "
                  <li>
                    <a href='"?><?php echo base_url(); ?><?php echo "supply'>Suministros</a>
                  </li> ";
                }
                if (isset($_SESSION['product']))
                {
                  echo "
                  <li>
                    <a href='"?><?php echo base_url(); ?><?php echo "product'>Productos</a>
                  </li> ";
                }
                if (isset($_SESSION['branchoffice']))
                {
                  echo "
                  <li>
                    <a href='"?><?php echo base_url(); ?><?php echo "branchoffice'>Sucursales</a>
                  </li> ";
                }  ?>
            </ul>
          </li>
          <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Administracion">
          <a class="nav-link nav-link-collapse collapsed" data-toggle="collapse" href="#collapseAdministracion" data-parent="#exampleAccordion">
            <i class="fa fa-calculator"></i>
            <span class="nav-link-text">Administración</span>
          </a>
          <ul class="sidenav-second-level collapse" id="collapseAdministracion">
            <li>
              <a href="#">Gastos</a>
            </li>
            <?php
                if (isset($_SESSION['production']))
                {
                  echo "
                  <li>
                    <a href='"?><?php echo base_url(); ?><?php echo "production'>Costos de producción</a>
                  </li> ";
              }
                if (isset($_SESSION['permisosacceso']))
                {
                  echo "
                  <li>
                    <a href='"?><?php echo base_url(); ?><?php echo "permisos'>Permisos de Acceso</a>
                  </li> ";
              } ?>
            <li>
              <a href="#">Otra cosa</a>
            </li>
          </ul>
        </li>
        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Inventarios">
          <a class="nav-link nav-link-collapse collapsed" data-toggle="collapse" href="#collapseInventarios" data-parent="#exampleAccordion">
            <i class="fa fa-file-text-o"></i>
            <span class="nav-link-text">Inventarios</span>
          </a>
          <ul class="sidenav-second-level collapse" id="collapseInventarios">
            <?php
                if (isset($_SESSION['stocktakingsupply']))
                {
                  echo "
                  <li>
                    <a href='"?><?php echo base_url(); ?><?php echo "stocktaking/supply'>Inv. Suministros</a>
                  </li> ";
                }
                if (isset($_SESSION['stocktakingproduct']))
                {
                  echo "
                  <li>
                    <a href='"?><?php echo base_url(); ?><?php echo "stocktaking/product'>Inv. Productos</a>
                  </li> ";
              } ?>
          </ul>
      </li>
          <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Reportes">
            <a class="nav-link nav-link-collapse collapsed" data-toggle="collapse" href="#collapseReportes" data-parent="#exampleAccordion">
              <i class="fa fa-line-chart"></i>
              <span class="nav-link-text">Reportes</span>
            </a>
            <ul class="sidenav-second-level collapse" id="collapseReportes">
              <li>
                <a href="<?php echo base_url(); ?>reports">Gastos</a>
              </li>
              <li>
                <a href="<?php echo base_url(); ?>reports/sales">Ventas</a>
              </li>
            </ul>
          </li>


        </ul>
        <!--esto no se que es-->
        <ul class="navbar-nav sidenav-toggler">
          <li class="nav-item">
            <a class="nav-link text-center" id="sidenavToggler">
              <i class="fa fa-fw fa-angle-left"></i>
            </a>
          </li>
        </ul>
        <!--fin esto no se que es-->
        <ul class="navbar-nav ml-auto">

          <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownBlog" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <i class="fa fa-fw fa-user"></i>
              </a>
              <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdownBlog">
                <h6 class="dropdown-header">Sesión de <?php echo $_SESSION['username'] ?></h6>
                <div class="dropdown-divider"></div>
                <?php if(isset($_SESSION['admin'])) { //administrador
                    echo "<a class='dropdown-item' href='"?><?php echo base_url(); ?><?php echo "user/perfil'>Mi perfil</a>";
                  }
                  else if(isset($_SESSION['employe'])) { //empleado
                      echo "<a class='dropdown-item' href='"?><?php echo base_url(); ?><?php echo "employe/perfil'>Mi perfil</a>";
                  }
                  else if(isset($_SESSION['customer'])) { //customer
                      echo "<a class='dropdown-item' href='"?><?php echo base_url(); ?><?php echo "customer/perfil'>Mi perfil</a>";
                    }?>
                <!--<a class="dropdown-item" href="sidebar.html">Mis pedidos</a>-->
                <a class="dropdown-item" data-toggle="modal" data-target="#modalCerrarSesion">Cerrar Sesión</a>
              </div>
            </li>

          <!--Cerrar sesion-->
        <!--  <li class="nav-item">
            <a class="nav-link" data-toggle="modal" data-target="#modalCerrarSesion">
              <i class="fa fa-fw fa-sign-out"></i>Cerrar Sesión</a>
          </li>-->
        </ul>
      </div>
    </nav>


<div class="content-wrapper">
  <div class="container-fluid">
