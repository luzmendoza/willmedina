<?php defined('BASEPATH') OR exit('No direct script access allowed');?>

</div> <!-- FIN/.container-fluid-->
   <!-- /.container-fluid-->
   <!-- /.content-wrapper-->
   <footer class="sticky-footer">
     <div class="container">
       <div class="text-center">
         <small>Copyright © Will Medina 2018</small>
       </div>
     </div>
   </footer>
   <!-- Scroll to Top Button-->
   <a class="scroll-to-top rounded" href="#page-top">
     <i class="fa fa-angle-up"></i>
   </a>


<!--modal iniciar sesion-->
   <div class="modal fade" id="modalIniciarSesion" tabindex="-1" role="dialog" aria-labelledby="modalIniciarSesionLabel" aria-hidden="true">
   <div class="modal-dialog" role="document">
     <div class="modal-content">


       <div class="card card-login mx-auto mt-5">
         <div class="card-header">Iniciar Sesión</div>
         <div class="card-body">
           <!--<form  method="post" action="<?php// echo base_url()."user/login_ajax" ?>" >-->
             <form action="#" id="form" class="form-horizontal">

               <!--mostrar mensajes de error/validacion-->
               <div id="errores" class="col-md-10 alert alert-danger respuesta" role="alert" style="display:none;">
               </div>

             <input type="hidden" name="<?php echo $this->security->get_csrf_token_name();?>" value="<?php echo $this->security->get_csrf_hash();?>">

             <div class="form-group">
               <label for="username">Usuario</label>
               <input class="form-control" id="username_ajax" name="username_ajax" type="text" aria-describedby="usernameHelp" placeholder="Ingrese usuario">
             </div>
             <div class="form-group">
               <label for="password">Contraseña</label>
               <input class="form-control" id="password_ajax" name="password_ajax" type="password" placeholder="Contraseña">
             </div>
             <div class="form-group">
               <div class="form-check">
                 <label class="form-check-label">
                   <input class="form-check-input" name="remember_ajax" id="remember_ajax" type="checkbox"> Recordar Contraseña</label>
               </div>
             </div>
            <!-- <a class="btn btn-primary btn-block" href="">Iniciar Sesión</a>-->
              <button type="button" id="btnSave" onclick="save()" class="btn btn-primary">Iniciar Sesión</button>
           </form>
           <div class="text-center">
             <a class="d-block small mt-3" href="<?php echo base_url() ?>register">Registrar una cuenta</a>
             <a class="d-block small" href="<?php echo base_url() ?>register/recuperarPass">Se te olvidó tu Contraseña?</a>

           </div>
         </div>
       </div>


     </div>
   </div>
 </div> <!--fin modal sesion -->









 <!--</div> <!-- FIN /.content-wrapper-->
</body>
</html>





<script type="text/javascript">

function save()
{
        var url = "<?php echo site_url('user/login_ajax')?>";

       // ajax adding data to database
      $.ajax({
        url : url,
        type: "POST",
        data: $('#form').serialize(),
        dataType: "JSON",
        success: function(data)
        {
          console.log(data);
           /*if(data.respuesta == 'error')
           {
             $(".respuesta").html('<button type="button" class="btn btn-sm close" data-dismiss="alert" aria-label="Close"><i class="fa fa-times" aria-hidden="true"></i> </button>');
               $(".respuesta").html( data.username +  data.password );
              $('#errores').slideDown().fadeOut(5000);
               return false;
            }else{*/
              if(data.status == false)
              {
                  $(".respuesta").html('<button type="button" class="btn btn-sm close" data-dismiss="alert" aria-label="Close"><i class="fa fa-times" aria-hidden="true"></i> </button>');
                  $(".respuesta").html( data.username +  data.password + data.error);
                  $('#errores').slideDown().fadeOut(5000);
                  return false;
              }
              else
              {                     //if success close modal and reload ajax table
                 $('#modal_form').modal('hide');
                 alert('estamos logeados!');
                 if(data.tipo == 'admin')
                 {
                     var redirect = "<?php echo site_url('dashboard')?>";
                   location.href = redirect;
                 }
                 else if(data.tipo == 'employe')
                 {
                     var redirect = "<?php echo site_url('dashboard/employee')?>";
                   location.href = redirect;
                 }
                 else{
                   location.reload();// for reload a page
                  }
              }
          //  }
        },
        error: function (jqXHR, textStatus, errorThrown)
        {
            alert('Error al registrar los datos');
        }
    });
}

</script>
