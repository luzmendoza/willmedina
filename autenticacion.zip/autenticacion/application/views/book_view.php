<div class="row">
    <div class="col-1">
      <button class="btn btn-primary btn-sm" onclick="add_book()"><i class="fa fa-plus"></i> Agregar Libro</button>
    </div>
  </div>

  <!-- Example DataTables Card-->
<div class="card mb-3">
<div class="card-header">
  <i class="fa fa-table"></i> Listado de Productos</div>
<div class="card-body">
  <div class="table-responsive">
    <table class="table table-bordered" id="table_id" width="100%" cellspacing="0">
      <thead>
        <tr>
          <th>Book ID</th>
          <th>Book ISBN</th>
          <th>Book Title</th>
          <th>Book Author</th>
          <th>Book Category</th>

          <th style="width:125px;">Action
          </p></th>
        </tr>
      </thead>
    <!--  <tfoot>
        <tr>
          <th> SKU </th>
          <th> Nombre </th>
          <th> Precio </th>
          <th> &nbsp; </th>
        </tr>
      </tfoot>-->
      <tbody>
        <?php foreach($books as $book): ?>
        <tr>
          <td><?php echo $book->book_id;?></td>
          <td><?php echo $book->book_isbn;?></td>
          <td><?php echo $book->book_title;?></td>
          <td><?php echo $book->book_author;?></td>
          <td><?php echo $book->book_category;?></td>
           <td>
              <button class="btn btn-info btn-sm" data-toggle="tooltip" data-placement="top" title="Editar" onclick="edit_book(<?php echo $book->book_id;?>)"><i class="fa fa-edit"></i></button>
              <button class="btn btn-danger btn-sm " data-toggle="tooltip" data-placement="top" title="Eliminar" onclick="eliminar(<?php echo $book->book_id;?>)" ><i class="fa fa-trash"></i></button>

           </td>
        </tr>
        <?php endforeach; ?>
      </tbody>

      <tfoot>
        <tr>
          <th>Book ID</th>
          <th>Book ISBN</th>
          <th>Book Title</th>
          <th>Book Author</th>
          <th>Book Category</th>
          <th>Action</th>
        </tr>
      </tfoot>

    </table>
  </div>
</div>
<div class="card-footer small text-muted"></div>
</div>



  <script type="text/javascript">
  $(document).ready( function () {
      $('#table_id').DataTable();

      $("#btnModal").click(function(){
        alert('oye');
      });
  } );
    var save_method; //for save method string
    var table;


    function add_book()
    {
      save_method = 'add';
      $('#form')[0].reset(); // reset form on modals
      $('#modal_form').modal('show'); // show bootstrap modal
    //$('.modal-title').text('Add Person'); // Set Title to Bootstrap modal title
    }

    function edit_book(id)
    {
      save_method = 'update';
      $('#form')[0].reset(); // reset form on modals

      //Ajax Load data from ajax
      $.ajax({
        url : "<?php echo site_url('book/ajax_edit/')?>/" + id,
        type: "GET",
        dataType: "JSON",
        success: function(data)
        {

            $('[name="book_id"]').val(data.book_id);
            $('[name="book_isbn"]').val(data.book_isbn);
            $('[name="book_title"]').val(data.book_title);
            $('[name="book_author"]').val(data.book_author);
            $('[name="book_category"]').val(data.book_category);


            $('#modal_form').modal('show'); // show bootstrap modal when complete loaded
            $('.modal-title').text('Edit Book'); // Set title to Bootstrap modal title

        },
        error: function (jqXHR, textStatus, errorThrown)
        {
            alert('Error get data from ajax');
        }
    });
    }



    function save()
    {
      var url;
      if(save_method == 'add')
      {
          url = "<?php echo site_url('book/book_add')?>";
      }
      else
      {
        url = "<?php echo site_url('book/book_update')?>";
      }

       // ajax adding data to database
          $.ajax({
            url : url,
            type: "POST",
            data: $('#form').serialize(),
            dataType: "JSON",
            success: function(data)
            {
               //if success close modal and reload ajax table
               $('#modal_form').modal('hide');
              location.reload();// for reload a page
            },
            error: function (jqXHR, textStatus, errorThrown)
            {
                alert('Error adding / update data');
            }
        });
    }

    function delete_book()
    {
          id = $('#book_id_delet').val();//recuperar id de control al modal
            console.log('eliminar '+id);
        // ajax delete data from database
          $.ajax({
            url : "<?php echo site_url('book/book_delete')?>/"+id,
            type: "POST",
            dataType: "JSON",
            success: function(data)
            {

               location.reload();
            },
            error: function (jqXHR, textStatus, errorThrown)
            {
                alert('Error deleting data');
            }
        });


    }

    //eliminamos datos del usuario
    function eliminar(id)
       {
          console.log('entro '+id);
        $('#book_id_delet').val(id);//enviar id de control al modal

          $('#modalEliminar').modal('show'); // abrir
      };

  </script>

  <!-- Bootstrap modal -->
  <div class="modal fade" id="modal_form" role="dialog">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="btn btn-danger btn-sm" data-dismiss="modal" aria-label="Close"><i class="fa fa-times" aria-hidden="true"></i></button>
        <h3 class="modal-title">Book Form</h3>
      </div>
      <div class="modal-body form">
        <form action="#" id="form" class="form-horizontal">
          <input type="hidden" value="" name="book_id"/>
          <div class="form-body">
            <div class="form-group">
              <label class="control-label col-md-3">Book ISBN</label>
              <div class="col-md-9">
                <input name="book_isbn" placeholder="Book ISBN" class="form-control" type="text">
              </div>
            </div>
            <div class="form-group">
              <label class="control-label col-md-3">Book Title</label>
              <div class="col-md-9">
                <input name="book_title" placeholder="Book_title" class="form-control" type="text">
              </div>
            </div>
            <div class="form-group">
              <label class="control-label col-md-3">Book Author</label>
              <div class="col-md-9">
								<input name="book_author" placeholder="Book Author" class="form-control" type="text">

              </div>
            </div>
						<div class="form-group">
							<label class="control-label col-md-3">Book Category</label>
							<div class="col-md-9">
								<input name="book_category" placeholder="Book Category" class="form-control" type="text">

							</div>
						</div>

          </div>
        </form>
          </div>
          <div class="modal-footer">
            <button type="button" id="btnSave" onclick="save()" class="btn btn-primary">Save</button>
            <button type="button" class="btn btn-danger" data-dismiss="modal">Cancel</button>
          </div>
        </div><!-- /.modal-content -->
      </div><!-- /.modal-dialog -->
    </div><!-- /.modal -->
  <!-- End Bootstrap modal -->



  <!-- Modal Eliminar producto-->
  <div class="modal fade" id="modalEliminar" tabindex="-1" role="dialog" aria-labelledby="modalEliminarLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="modalEliminarLabel">¿Seguro desea eliminar este producto?</h5>
        <button class="close" type="button" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">×</span>
        </button>
      </div>
      <input type="hidden" value="" name="book_id_delet" id="book_id_delet"/>
      <div class="modal-body">Seleccione "Eliminar" si está seguro de la acción.</div>
      <div class="modal-footer">
        <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancelar</button>
          <button type="button" id="btnSave" onclick="delete_book()" class="btn btn-primary">Eliminar</button>
      </div>
    </div>
  </div>
  </div>
