<?php defined('BASEPATH') OR exit('No direct script access allowed');?>



   <div class="card">
     <div class="card-header">Mi Perfil</div>
     <div class="card-body">
      <form action="#" id="form" class="form-horizontal">

         <div id="errores" class="col-md-10 alert alert-danger respuesta" role="alert" style="display:none;">
         </div>
         <div id="exito" class="col-md-10 alert alert-success respexito" role="alert" style="display:none;">
         </div>

         <input type="hidden" id="csrf" name="<?php echo $this->security->get_csrf_token_name();?>" value="<?php echo $this->security->get_csrf_hash();?>">
         <input type="hidden" name="id_employe" id="id_employe" value="<?php echo $id_employe; ?>">
         <input type="hidden" name="key_employe" id="key_employe" value="<?php echo $key_employe; ?>">
         <input type="hidden" name="id_user" id="id_user" value="<?php echo $id_user; ?>" >
         <input type="hidden" name="llevaImagen" id="llevaImagen" >
         <input type="hidden" name="nameImagen" id="nameImagen" >
         <input type="hidden" name="urlImagen" id="urlImagen" >

         <div class="form-group">
           <div class="form-row">
             <div class="col-md-2" >
                   <label for="name">Usuario</label>
                   <input class="form-control"  id="username" name="username" type="text" aria-describedby="usernamedateHelp"  maxlength="50"  tabindex="0" value="<?php echo $username; ?>" readonly></input>
             </div>
             <div  class="col-md-2">
               <!--MOSTRAR IMAGENE-->
               <img id="imgSalida" width="100%" height="100%" src="" class="img-thumbnail rounded float-right"/>
             </div>
             <div  class="col-md-2">
               <!--<label for="exampleFormControlFile1">Seleccione la imagen</label>-->
               <!--<input type="file" class="form-control" id="imagenes[]" name="imagenes[]" multiple>-->
               <input type="file" class="form-control" name="images[]" id="img_select">
             </div>
          </div>
        </div>

         <div class="form-group">
           <div class="form-row">
             <div class="col-md-2" >
                   <label for="name">Nombre</label>
                   <input class="form-control"  id="first_name" name="first_name" type="text" aria-describedby="nombre_dateHelp"  maxlength="50"  tabindex="1" value="<?php echo $first_name; ?>" required></input>
             </div>
             <div class="col-md-2" >
                   <label for="name">Apellido</label>
                   <input class="form-control"  id="last_name" name="last_name" type="text" aria-describedby="nombre_dateHelp"  maxlength="50"  tabindex="1" value="<?php echo $last_name; ?>" required></input>
             </div>

               <div class="col-md-2" >
                     <label for="birth_date">Fecha de Nacimiento</label>
                       <input class="form-control date numeros" data-provide="datepicker" data-date-language="es" autoclose="true" data-date-end-date="0d" data-date-format="yyyy-mm-dd"
                       id="birth_date" name="birth_date" type="text" aria-describedby="birth_dateHelp"  placeholder="yyyy-mm-dd" maxlength="10"  tabindex="3" value="<?php echo $birth_date; ?>"  required>
                     </input>
               </div>

           </div>
         </div>

         <div class="form-group">
                     <div class="form-row">
                       <div class="col-md-2">
                         <label for="sex">Sexo</label>
                         <select class="form-control" id="sex" name="sex" aria-describedby="sexHelp"   tabindex="6" value="<?php echo $sex; ?>" required>
                           <option value="F">Femenino</option>
                           <option value="M">Masculino</option>
                         </select>
                       </div>
                       <div class="col-md-2">
                         <label for="cell_phone">Teléfono Celular</label>
                         <input class="form-control numeros" id="cell_phone_" name="cell_phone" type="text"  placeholder="Ingrese No." maxlength="10"  tabindex="4" value="<?php echo $cell_phone; ?>" required>

                        </div>
                       <div class="col-md-2">
                         <label for="phone">Tel. Casa</label>
                         <input class="form-control numeros" id="phone" name="phone" type="text"  placeholder="Ingrese No." maxlength="10"  tabindex="5" value="<?php echo $phone; ?>">
                       </div>
                     </div>
                   </div>

                   <div class="form-group">
                     <div class="form-row">
                       <div class="col-md-2">
                         <label for="email">Email</label>
                         <input class="form-control" id="email" name="email" type="text" aria-describedby="emailHelp"  placeholder="email@email.com" maxlength="50"  tabindex="7" value="<?php echo $email; ?>" required>
                        </div>
                       <div class="col-md-2">
                         <label for="country">País</label>
                         <select class="form-control" id="country" name="country" aria-describedby="countryHelp"   tabindex="6"  required>
                         </select>
                        </div>
                        <div class="col-md-2">
                          <label for="cp">C.P.</label>
                          <input class="form-control numeros" id="cp" name="cp" type="text" aria-describedby="cpHelp"  placeholder="Código" maxlength="5"  tabindex="7" value="<?php echo $key_cp; ?>" required>
                         </div>
                     </div>
                   </div>
                   <div class="form-group">
                     <div class="form-row">
                       <div class="col-md-2">
                         <label for="state">Estado</label>
                         <select class="form-control" id="state" name="state" aria-describedby="stateHelp"   tabindex="8" required>

                         </select>
                       </div>
                       <div class="col-md-2">
                         <label for="municipality">Municipio</label>
                         <select class="form-control" id="municipality" name="municipality" aria-describedby="municipalityHelp"   tabindex="9" required>

                         </select>
                        </div>
                        <div class="col-md-2">
                          <label for="colony">Colonia/Asentamiento</label>
                          <select class="form-control" id="colony" name="colony" aria-describedby="localityHelp"   tabindex="10" required>

                          </select>
                        </div>
                     </div>
                   </div>
                   <div class="form-group">
                     <div class="form-row">

                       <div class="col-md-2">
                         <label for="street">Calle</label>
                         <input class="form-control" id="street" name="street" type="text" aria-describedby="streetHelp"  placeholder="Ingrese Calle" maxlength="50"  tabindex="11" value="<?php echo $street; ?>" required>
                        </div>
                        <div class="col-md-2">
                          <label for="num_exterior">No. Exterior</label>
                          <input class="form-control numeros" id="num_exterior" name="num_exterior" type="text" aria-describedby="num_exteriorHelp"  placeholder="Ingrese No" maxlength="4"  tabindex="12" value="<?php echo $num_exterior; ?>" required>

                        </div>
                        <div class="col-md-2">
                          <label for="num_inside">No. Interior</label>
                          <input class="form-control numeros" id="num_inside" name="num_inside" type="text" aria-describedby="num_insideHelp"  placeholder="Ingrese No" maxlength="4"  tabindex="13" value="<?php echo $num_inside; ?>" >

                        </div>
                     </div>
                   </div>
                   <div class="form-group">
                     <div class="form-row">
                       <div class="col-md-3">
                         <label for="street1">Entre Calle</label>
                         <input class="form-control" id="street1" name="street1" type="text" aria-describedby="street1Help"  placeholder="Ingrese Calle" maxlength="50"  tabindex="14"  value="<?php echo $street_between1; ?>" >

                        </div>
                       <div class="col-md-3">
                         <label for="street2">y Calle</label>
                         <input class="form-control" id="street2" name="street2" type="text" aria-describedby="street2Help"  placeholder="Ingrese Calle" maxlength="50"  tabindex="15"  value="<?php echo $street_between2; ?>">
                       </div>
                     </div>
                   </div>
                   <div class="form-group">
                     <div class="form-row">
                       <div class="col-md-6">
                         <label for="complement">Complementos de Dirección</label>
                         <input class="form-control" id="complement" name="complement" type="text" aria-describedby="complementHelp"  placeholder="Ingrese complemento" maxlength="50"  tabindex="16" value="<?php echo $complement; ?>">
                        </div>
                     </div>
                   </div>

<!--pie de pagina... botones-->
        <div class="form-group">
          <div class="form-row">
            <div class="col-md-1">
              <button type="button" id="btnSave" onclick="save()" class="btn btn-primary">Guardar</button>
            </div>
          </div>
        </div>
       </form>
     </div>
   </div>



   <script type="text/javascript">

    $(document).ready( function () {

      $('.birth_date').datepicker({
          format: 'yyyy-mm-dd',
          endDate: new Date(),
          autoclose: true,
          language: 'es'

      });


         $('#errores').slideUp();

      // Validar solo numeros
        $(".numeros").keypress(function (e) {
          if (e.which != 8 && e.which != 0 && (e.which < 48 || e.which > 57)) {
                  return false;
          }
        });

        //cargar datos de paises
         getcountries();
         PostalCode = "<?php echo $key_cp;?>";
         country = "<?php echo $key_country;?>";
         state = "<?php echo $key_state;?>";
         getallstates(country);
         getallmunicipality(state);
         getdatapostalcode(PostalCode,0);
         getscolonies(PostalCode);


         $("#country").change(function () {
             console.log('cambio');
              var paisId = $("#country").val();
              if(paisId == 'MEX')
              {
                //busqueda por codigo postal
                busquedaCP = true;
              }
              else if(paisId == 'USA' || paisId == 'CAN')
              {
                busquedaCP = false;
                 //busqueda por estado... obtener estados
                 $("#state").empty();
                 getstates(paisId,tipoIdPais);
                 //bloquear y limpiar campos municipios,localidades,colonias
              }else{
                busquedaCP = false;
                //bloquear y limpiar campos estado, municipios,localidades,colonias
                $("#state").empty();
                $("#municipality").empty();
                $("#colony").empty();
                $("#cp").val("");
                $("#state").attr('disabled',true);
                $("#municipality").attr('disabled',true);
                $("#colony").attr('disabled',true);
              }

          });

          //se desencadena despues del keypress y ya se cuenta con toda la informacion en el value
            $("#cp").keyup(function (e) {
              if($("#cp").val()=="")
              {
                 $("#state").empty();
                 $("#municipality").empty();
                 $("#colony").empty();
              }
               if($("#cp").val().length==5 && busquedaCP == true)
               {

                 $("#colony").empty();
                  var PostalCode = $("#cp").val();
                  getdatapostalcode(PostalCode,1);
                  getscolonies(PostalCode);
                 //busca el codigo postal para recuperar los estados,municipios, localidades, colonias
                 //  console.log('ir a buscar');
               }
            });

            //Agrega una imagen de vista previa
             $('#img_select').change(function(e) {
                   addImage(e);
                  });


           setTimeout(function(){mostrarSeleccion()},1000);
  });// fin ready function


    //declaracion de variables y constantes
    var tipoIdPais = '1';
    var tipoIdEstado = '2';

    var busquedaCP = false;

    var EstID;
    var MunID;
    var LocID = new Array();


         function addImage(e){
            var file = e.target.files[0],
            imageType = /image.*/;

            if (!file.type.match(imageType))
             return;

            var reader = new FileReader();
            reader.onload = fileOnload;
            reader.readAsDataURL(file);
         }

         function fileOnload(e) {
            var result=e.target.result;
            $('#imgSalida').attr("src",result);
         }


    //obtiene la lista de paises
    function getcountries()
    {
        //Ajax Load data from ajax
      $.ajax({
        url : "<?php echo site_url('country/get_all/')?>",
        type: "GET",
        dataType: "JSON",
        success: function(data)
        {
          console.log('obtiene paises');
          //console.log(data);
          //cargar datos en el formulario
          $(data).each(function(i, v){ // indice, valor
              $("#country").append('<option value="' + v.key_country + '">' + v.name + '</option>');
         })

        },
        error: function (jqXHR, textStatus, errorThrown)
        {
            alert('Error al obtener datos');
        }
      });
    }

    //obtiene la lista de estados por pais
    function getstates(id,tipoId)
    {
      $.ajax({
        url : "<?php echo site_url('state/get_all_by_id/')?>"+id+"/"+tipoId,
        type: "GET",
        dataType: "JSON",
        success: function(data)
        {
          console.log('obtiene estados');
         console.log(data);
          //cargar datos en el formulario
          $(data).each(function(i, v){ // indice, valor
             $("#state").append('<option value="' + v.key_state + '">' + v.name + '</option>');
          })

        },
        error: function (jqXHR, textStatus, errorThrown)
        {
            alert('Error al obtener datos');
        }
    });
    }
    function getallstates(country)
    {
      $.ajax({
        url : "<?php echo site_url('state/get_all/')?>"+country,
        type: "GET",
        dataType: "JSON",
        success: function(data)
        {
          console.log('obtiene estados');
         console.log(data);
          //cargar datos en el formulario
          $(data).each(function(i, v){ // indice, valor
             $("#state").append('<option value="' + v.key_state + '">' + v.name + '</option>');
          })

        },
        error: function (jqXHR, textStatus, errorThrown)
        {
            alert('Error al obtener datos');
        }
    });
    }

    function getallmunicipality(state)
    {
      $.ajax({
        url : "<?php echo site_url('municipality/get_all/')?>"+state,
        type: "GET",
        dataType: "JSON",
        success: function(data)
        {
          console.log('obtiene municipios');
         console.log(data);
          //cargar datos en el formulario
          $(data).each(function(i, v){ // indice, valor
             $("#municipality").append('<option value="' + v.key_municipality + '">' + v.name + '</option>');
          })

        },
        error: function (jqXHR, textStatus, errorThrown)
        {
            alert('Error al obtener datos');
        }
    });
    }

    //obtiene la lista de municipios por pais
    function getsmunicipalities(idEstado,idMun)
    {
      $.ajax({
        url : "<?php echo site_url('municipality/get_all_by_id/')?>"+idEstado+"/"+idMun,
        type: "GET",
        dataType: "JSON",
        success: function(data)
        {
          console.log('obtiene municipios');
         // console.log(data);
          var i=0;
          //cargar datos en el formulario
          $(data).each(function(i, v){ // indice, valor
             $("#municipality").append('<option value="' + v.key_municipality + '" >' + v.name + '</option>');
          })

        },
        error: function (jqXHR, textStatus, errorThrown)
        {
            alert('Error al obtener datos');
        }
    });
    }
    //obtiene la lista de estados, municipios, Localidad por codigo postal
    function getdatapostalcode(PostalCode,busqueda)
    {
      $.ajax({
        url : "<?php echo site_url('postalcode/get_all_by_id/')?>"+PostalCode,
        type: "GET",
        dataType: "JSON",
        success: function(data)
        {
          //cargar datos en el formulario
          $(data).each(function(i, v){ // indice, valor
            EstID = v.key_state;
            MunID = v.key_municipality;

            var renglon = new Array(v.key_locality);
            LocID.push(renglon);
          });
         if(busqueda==1)
          {
            //limpiar antes de buscar
            $("#state").empty();
            $("#municipality").empty();
            getstates(EstID,tipoIdEstado);
            getsmunicipalities(EstID,MunID);
          }
          $('[name="state"]').val(EstID).change();//hacer un selected
          //pendiente localidades
          $('[name="municipality"]').val(MunID).change();//hacer un selected
        },
        error: function (jqXHR, textStatus, errorThrown)
        {
            alert('Error al obtener datos');
        }
    });

    }

    function getscolonies(PostalCode)
    {
      $.ajax({
        url : "<?php echo site_url('colony/get_all_by_id/')?>"+PostalCode,
        type: "GET",
        dataType: "JSON",
        success: function(data)
        {
          console.log('obtiene colonias');
          console.log(data);
          var i=0;
          //cargar datos en el formulario
          $(data).each(function(i, v){ // indice, valor
              $("#colony").append('<option value="' + v.key_colony + '" >' + v.name + '</option>');
          })

        },
        error: function (jqXHR, textStatus, errorThrown)
        {
            alert('Error al obtener datos');
        }
    });
    }

    function mostrarSeleccion()
    {
      console.log('lego');
      country = "<?php echo $key_country; ?>";
      state="<?php echo $key_state; ?>";
      colony="<?php echo $key_colony; ?>";
      imageurl = "<?php echo base_url().$imageurl; ?>";
      image = "<?php echo $image; ?>";
      sex = "<?php echo $sex; ?>";
      console.log(imageurl);
       $('[name="country"]').val(country).change();//hacer un selected
       $('[name="state"]').val(state).change();//hacer un selected
       $('[name="colony"]').val(colony).change();//hacer un selected
       $('[name="sex"]').val(sex).change();//hacer un selected
       $('#imgSalida').attr("src",imageurl);
       $('[name="nameImagen"]').val(image);
       $('[name="urlImagen"]').val(imageurl);
      $('[name="municipality"]').val(MunID).change();//hacer un selected
    }

    function validar()
    {
      var mensaje = 'Debe modificar la información antes de guardar. <br>';
      var respuesta = false;


      first_name = "<?php echo $first_name; ?>";
      last_name = "<?php echo $last_name; ?>";
      birth_date = "<?php echo $birth_date; ?>";
      cell_phone = "<?php echo $cell_phone; ?>";
      phone = "<?php echo $phone; ?>";
      key_cp = "<?php echo $key_cp; ?>";
      street = "<?php echo $street; ?>";
      street1 = "<?php echo $street_between1; ?>";
      street2 = "<?php echo $street_between2; ?>";
      num_exterior = "<?php echo $num_exterior; ?>";
      num_inside = "<?php echo $num_inside; ?>";
      complementos = "<?php echo $complement; ?>";
      sexo = "<?php echo $sex; ?>";
      country = "<?php echo $key_country; ?>";
      state="<?php echo $key_state; ?>";
      colony="<?php echo $key_colony; ?>";
      imageurl = "<?php echo base_url().$imageurl; ?>";
      image = "<?php echo $image; ?>";
      email = "<?php echo $email; ?>";

      if($("#first_name").val()!=first_name)
      {
        console.log('first_name');
        respuesta = true;
      }
      if($("#last_name").val()!=last_name)
      {
        console.log('last_name');
        respuesta = true;
      }
      if($("#birth_date").val()!=birth_date)
      {
        console.log('birth_date');
        respuesta = true;
      }
      if($("#sex").val()!=sexo)
      {
        console.log('sexo');
        respuesta = true;
      }
      if($("#cell_phone_").val()!=cell_phone)
      {
        console.log('cell_phone');
        respuesta = true;
      }
      if($("#phone").val()!=phone)
      {
        console.log('phone');
        respuesta = true;
      }
      if($("#country").val()!=country)
      {
        console.log('country');
        respuesta = true;
      }
      if($("#cp").val()!=key_cp)
      {
        console.log('key_cp');
        respuesta = true;
      }
      if($("#street").val()!=street)
      {
          console.log('street');
        respuesta = true;
      }
      if($("#street1").val()!=street1)
      {
          console.log('street1');
        respuesta = true;
      }
      if($("#street2").val()!=street2)
      {
          console.log('street2');
        respuesta = true;
      }
      if($("#num_exterior").val()!=num_exterior)
      {
          console.log('num_exterior');
        respuesta = true;
      }
      if($("#num_inside").val()!=num_inside)
      {
          console.log('num_inside');
        respuesta = true;
      }
      if($("#complement").val()!=complementos)
      {
          console.log('complementos');
        respuesta = true;
      }
      if($("#state").val()!=state)
      {
          console.log('state');
        respuesta = true;
      }
      if($("#colony").val()!=colony)
      {
          console.log('colony');
        respuesta = true;
      }
      if($("#email").val()!=email)
      {
          console.log('email');
        respuesta = true;
      }
      if($("#municipality").val()!=MunID)
      {
          console.log('MunID');
        respuesta = true;
      }

      if($("#img_select").val()!='')
      {
        console.log('imageurl');
        console.log($("#img_select").val());
          respuesta = true;
      }

      if(respuesta == false)
      {
          $(".respuesta").html('<button type="button" class="btn btn-sm close" data-dismiss="alert" aria-label="Close"><i class="fa fa-times" aria-hidden="true"></i> </button>');
            $(".respuesta").html(mensaje);
           $('#errores').slideDown().fadeOut(5000);
      }
      return respuesta;
    }


     function save()
     {
        if (validar())
        {
          console.log('valido');
             var url = "<?php echo site_url('employe/update')?>";

             if($("#img_select").val() !="")
             {
               $('#llevaImagen').val('si') ;
             }
             var formData = new FormData($("#form")[0]);
             console.log(formData);

              // ajax adding data to database
                 $.ajax({
                   url : url,
                   type: "POST",
                //data: $('#form').serialize(),
                  data : formData,
                   dataType: "JSON",
                   processData: false,
                   contentType: false,
                   success: function(data)
                   {
                      if(data.respuesta == 'error')
                      {
                        $(".respuesta").html('<button type="button" class="btn btn-sm close" data-dismiss="alert" aria-label="Close"><i class="fa fa-times" aria-hidden="true"></i> </button>');
                          $(".respuesta").html(data.id_user +  data.cell_phone + data.birth_date + data.country + data.cp + data.street + data.num_exterior  );
                         $('#errores').slideDown().fadeOut(5000);
                          return false;
                       }else{
                          //if success close modal and reload ajax table
                          //if success close modal and reload ajax table
                          $(".respexito").html('<button type="button" class="btn btn-sm close" data-dismiss="alert" aria-label="Close"><i class="fa fa-times" aria-hidden="true"></i> </button>');
                          $(".respexito").html("Datos actualizados exitosamente");
                           $('#exito').slideDown().fadeOut(5000);
                       }
                   },
                   error: function (jqXHR, textStatus, errorThrown)
                   {
                       alert('Error al registrar los datos');
                   }
               });

         }//fin validar
     }
</script>
