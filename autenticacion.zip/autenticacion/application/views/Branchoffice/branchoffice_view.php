<div class="row">
      <div class="col-1">
      <button class="btn btn-primary btn-sm" onclick="add_branch()"><i class="fa fa-plus"></i> Agregar Sucursal</button>
      <p> </p>
      </div>
    </div>


    <!-- Example DataTables Card-->
<div class="card mb-3">
  <div class="card-header">
    <i class="fa fa-table"></i> Listado de Sucursales</div>
  <div class="card-body">
    <div class="table-responsive">
      <table class="table table-bordered" id="dtSucursals" width="100%" cellspacing="0">
        <thead>
          <tr>
            <th> Id </th>
            <th> Nombre </th>
            <th> Dirrección </th>
            <th style="width:125px;">Acciones
            </p></th>
          </tr>
        </thead>
        <tbody>
          <?php foreach($branchs as $branch): ?>
          <tr>
             <td style="width: 30%" id="sucursal"> <?php echo $branch->id ?> </td>
             <td style="width: 40%" id="name"> <?php echo $branch->name?> </td>
             <td style="width: 40%" id="direccion"> <?php echo $branch->address ?> </td>
             <td>
                <button class="btn btn-primary btn-sm" data-toggle="tooltip" data-placement="top" title="Editar" onclick="edit_branch(<?php echo $branch->id;?>)"><i class="fa fa-edit"></i></button>
                <button class="btn btn-danger btn-sm " data-toggle="tooltip" data-placement="top" title="Eliminar" onclick="eliminar(<?php echo $branch->id;?>)" ><i class="fa fa-trash"></i></button>

             </td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
  <div class="card-footer small text-muted"></div>
</div>

<script type="text/javascript">
$(document).ready( function () {
     $('#errores').slideUp();

      $('#dtSucursals').DataTable({
        "language": {
                 "infoFiltered": " - filtrado de _MAX_ registros",
                 "info": "Mostrando página _PAGE_ de _PAGES_",
                 "emptyTable": "No hay datos disponibles en la tabla"
                }
      });


});// fin ready function


  var save_method; //for save method string
  var table;

  //configuraciones para un nuevo producto
  function add_branch()
  {
      $('#errores').slideUp();
      save_method = 'add';
      $('#form')[0].reset(); // reset form on modals
      $('#modal_form').modal('show'); // show bootstrap modal
    //$('.modal-title').text('Add Person'); // Set Title to Bootstrap modal title
  }

//metodo para guarda un usuario
  function save()
  {
     if (validar())
     {
          var url = "<?php echo site_url('branchoffice/add')?>";

         // ajax adding data to database
              $.ajax({
                url : url,
                type: "POST",
                data: $('#form').serialize(),
                dataType: "JSON",
                success: function(data)
                {
                  console.log(data);
                   if(data.respuesta == 'error')
                   {
                     $(".respuesta").html('<button type="button" class="btn btn-sm close" data-dismiss="alert" aria-label="Close"><i class="fa fa-times" aria-hidden="true"></i> </button>');
                       $(".respuesta").html(data.name);
                      $('#errores').slideDown().fadeOut(5000);
                       return false;
                    }else{
                       //if success close modal and reload ajax table
                       $('#modal_form').modal('hide');
                       location.reload();// for reload a page
                    }
                },
                error: function (jqXHR, textStatus, errorThrown)
                {
                    alert('Error al registrar los datos');
                }
            });
      }//fin validar
  }

  //validar que los datos obligatorios sean ingresados antes de realizar el registro
  function validar()
  {
      var mensaje = 'Campos requeridos:  <br>';
      var respuesta = true;

      if($("#name_").val()=="")
      {
        mensaje += 'Nombre <br>';
        respuesta = false;
      }

      if(respuesta == false)
      {
          $(".respuesta").html('<button type="button" class="btn btn-sm close" data-dismiss="alert" aria-label="Close"><i class="fa fa-times" aria-hidden="true"></i> </button>');
            $(".respuesta").html(mensaje);
           $('#errores').slideDown().fadeOut(5000);
      }
      return respuesta;
  }

  function edit_branch(id)
  {
    $('#errores').slideUp();
    save_method = 'update';
    $('#form')[0].reset(); // reset form on modals

    //Ajax Load data from ajax
    $.ajax({
      url : "<?php echo site_url('branchoffice/edit/')?>" + id,
      type: "GET",
      dataType: "JSON",
      success: function(data)
      {
          $('[name="id"]').val(data.id);
          $('[name="address"]').val(data.address);
          $('[name="name"]').val(data.name);

          $('#modal_form').modal('show'); // show bootstrap modal when complete loaded
          $('.modal-title').text('Editar Sucursal'); // Set title to Bootstrap modal title

      },
      error: function (jqXHR, textStatus, errorThrown)
      {
          alert('Error al obtener datos');
      }
  });
  }

  //eliminamos datos
  function eliminar(id)
     {
        $('#id_delet').val(id);//enviar id de control al modal
        $('#modalEliminar').modal('show'); // abrir
    };

    function delete_branch()
    {
          id = $('#id_delet').val();//recuperar id de control al modal
            console.log('eliminar '+id);
        // ajax delete data from database
          $.ajax({
            url : "<?php echo site_url('branchoffice/delete/')?>"+id,
            type: "POST",
            dataType: "JSON",
            success: function(data)
            {
              //agregar mensaje para notificar
               location.reload();
            },
            error: function (jqXHR, textStatus, errorThrown)
            {
                alert('Error al eliminar información');
            }
        });
    }

</script>

<!-- Bootstrap modal -->
<div class="modal fade" id="modal_form" role="dialog">
<div class="modal-dialog modal-lg">
  <div class="modal-content">
    <div class="modal-header">
    <!--  <button type="button" class="btn btn-danger btn-sm" data-dismiss="modal" aria-label="Close"><i class="fa fa-times" aria-hidden="true"></i></button> -->
      <h4 class="modal-title">Nueva Sucursal</h4>
      <button type="button" class="btn btn-sm" data-dismiss="modal" aria-label="Close"><i class="fa fa-times" aria-hidden="true"></i></button>
    </div>


    <div class="modal-body form">
      <form action="#" id="form" class="form-horizontal">

        <div class="form-body">

          <!--mostrar mensajes de error/validacion-->
          <div id="errores" class="col-md-10 alert alert-danger respuesta" role="alert" style="display:none;">
          </div>

          <!--campos ocultos del formulario-->
          <input type="hidden" name="id" id="id" >

    <!--campos visibles del formulario-->

          <div class="form-group">
            <div class="form-row">
              <div class="col-md-10">
                <label for="name">Nombre</label>
                <input class="form-control" id="name_" name="name" type="text" aria-describedby="nameHelp" placeholder="Ingrese sucursal" required maxlength="50" tabindex="1">
              </div>
            </div>
          </div>
          <div class="form-group">
            <div class="form-row">
              <div class="col-md-10">
                <label for="name">Dirrección</label>
                <input class="form-control" id="address" name="address" type="text" aria-describedby="addressHelp" required maxlength="150" tabindex="2" >
              </div>
            </div>
          </div>

        </div>
      </form>
        </div>
        <div class="modal-footer">
          <button type="button" id="btnSave" onclick="save()" class="btn btn-primary">Guardar</button>
          <button type="button" class="btn btn-danger"  data-dismiss="modal">Cancelar</button>
        </div>
      </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
  </div><!-- /.modal -->
<!-- End Bootstrap modal -->



  <!-- Modal Eliminar-->
  <div class="modal fade" id="modalEliminar" tabindex="-1" role="dialog" aria-labelledby="modalEliminarLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="modalEliminarLabel">¿Seguro desea eliminar esta sucursal?</h5>
        <button class="close" type="button" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">×</span>
        </button>
      </div>
      <input type="hidden" value="" name="id_delet" id="id_delet"/>
    <!--  <div class="modal-body">Seleccione "Eliminar" si está seguro de la acción.</div>-->
      <div class="modal-footer">
        <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancelar</button>
          <button type="button" id="btnSave" onclick="delete_branch()" class="btn btn-primary">Eliminar</button>
      </div>
    </div>
  </div>
  </div>
