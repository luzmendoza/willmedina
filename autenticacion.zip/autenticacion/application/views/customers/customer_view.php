
<div class="row">
      <div class="col-1">
      <button class="btn btn-primary btn-sm" onclick="add_customer()"><i class="fa fa-plus"></i> Agregar Cliente</button>
      <p> </p>
      </div>
    </div>


    <!-- Example DataTables Card-->
<div class="card mb-3">
  <div class="card-header">
    <i class="fa fa-table"></i> Listado de Clientes</div>
  <div class="card-body">
    <div class="table-responsive">
      <table class="table table-bordered" id="dtCustomers" width="100%" cellspacing="0">
        <thead>
          <tr>
            <th> No. </th>
            <th> Nombre </th>
            <th> Teléfono </th>
            <th style="width:125px;">Acciones
            </p></th>
          </tr>
        </thead>
        <tbody>
          <?php foreach($customers as $customer): ?>
          <tr>
             <td style="width: 30%" id="id"> <?php echo $customer->id ?> </td>
             <td style="width: 30%" id="name"> <?php echo $customer->first_name.' '.$customer->last_name ?> </td>
             <td style="width: 30%" id="cell_phone"> <?php echo $customer->cell_phone ?> </td>
             <td>
                <!--<button class="btn btn-info btn-sm" data-toggle="tooltip" data-placement="top" title="Visualizar" onclick="see_customer(<?php echo $customer->id;?>)"><i class="fa fa-eye"></i></button>-->
                <button class="btn btn-primary btn-sm" data-toggle="tooltip" data-placement="top" title="Editar" onclick="edit_customer(<?php echo $customer->id;?>)"><i class="fa fa-edit"></i></button>
                <button class="btn btn-danger btn-sm " data-toggle="tooltip" data-placement="top" title="Eliminar" onclick="eliminar(<?php echo $customer->id;?>)" ><i class="fa fa-trash"></i></button>

             </td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
  <div class="card-footer small text-muted"></div>
</div>



<script type="text/javascript">

 $(document).ready( function () {

   $('#birth_date').datepicker({
       format: 'yyyy-mm-dd',
       endDate: new Date(),
       autoclose: true,
       language: 'es'

   });



      $('#errores').slideUp();

       $('#dtCustomers').DataTable({
         "language": {
                  "infoFiltered": " - filtrado de _MAX_ registros",
                  "info": "Mostrando página _PAGE_ de _PAGES_",
                  "emptyTable": "No hay datos disponibles en la tabla"
                 }
       });

   // Validar solo numeros
     $(".numeros").keypress(function (e) {
       if (e.which != 8 && e.which != 0 && (e.which < 48 || e.which > 57)) {
               return false;
       }
     });

     //cargar datos de paises
      getcountries();

      $("#country").change(function () {
           var paisId = $("#country").val();
           if(paisId == 'MEX')
           {
             //busqueda por codigo postal
             busquedaCP = true;
           }
           else if(paisId == 'USA' || paisId == 'CAN')
           {
             busquedaCP = false;
              //busqueda por estado... obtener estados
              $("#state").empty();
              getstates(paisId,tipoIdPais);
              //bloquear y limpiar campos municipios,localidades,colonias
           }else{
             busquedaCP = false;
             //bloquear y limpiar campos estado, municipios,localidades,colonias
             $("#state").empty();
             $("#municipality").empty();
             $("#colony").empty();
             $("#cp").val("");
             $("#state").attr('disabled',true);
             $("#municipality").attr('disabled',true);
             $("#colony").attr('disabled',true);
           }

       });

       //se desencadena despues del keypress y ya se cuenta con toda la informacion en el value
         $("#cp").keyup(function (e) {
           if($("#cp").val()=="")
           {
              $("#state").empty();
              $("#municipality").empty();
              $("#colony").empty();
           }
            if($("#cp").val().length==5 && busquedaCP == true)
            {
              //limpiar antes de buscar
              $("#state").empty();
              $("#municipality").empty();
              $("#colony").empty();
               var PostalCode = $("#cp").val();
               getdatapostalcode(PostalCode);
               getscolonies(PostalCode);
              //busca el codigo postal para recuperar los estados,municipios, localidades, colonias
              //  console.log('ir a buscar');
            }
         });

         //Agrega una imagen de vista previa
          $('#img_select').change(function(e) {
                addImage(e);
               });


        //autocomplete para recuperar al usuario
        var options = {
          //data: ["blue", "green", "pink", "red", "yellow"],
          url: "<?php echo site_url('user/autocomplete')?>", //esta es la data
          //getValue: "first_name", //este es el valor que busca el autocomplete, puede ser string o funcion :)
          getValue: function(element) {
            var nombre = element.first_name + ' '+ element.last_name;
          	return nombre;
          },
          template: {  //muestra una descripcion sumado al elemento de busqueda, aparece en letra mas pequeña :)
        		type: "description",
        		fields: {
        			description: "username"
        		}
        	},
          list: {
          		match: { //este hace una busqueda por coincidencia
          			enabled: true
          		},
              sort: { //ordena los datos de la lista
          			enabled: true
          		},
              onChooseEvent: function() {
          			//alert("item seleccionado !");
                var nombre = $("#autocomplete").getSelectedItemData().first_name;
                var apellido = $("#autocomplete").getSelectedItemData().last_name;
                var userid = $("#autocomplete").getSelectedItemData().id;
                  $("#first_name").val(nombre).trigger("change");
                  $("#last_name").val(apellido).trigger("change");
                  $("#iduser").val(userid).trigger("change");

          		}
          	},
          theme: "bootstrap",
          placeholder: "Ingresar nombre",
          adjustWidth: false //linea super necesaria para que se vea la lista en horizontal :) y no letra por letra hacia abajo
        };

        $("#autocomplete").easyAutocomplete(options);
        //fin autocomplete usuario
 });// fin ready function



 //declaracion de variables y constantes
 var tipoIdPais = '1';
 var tipoIdEstado = '2';

 var busquedaCP = false;

 var EstID;
 var MunID;
 var LocID = new Array();


      function addImage(e){
         var file = e.target.files[0],
         imageType = /image.*/;

         if (!file.type.match(imageType))
          return;

         var reader = new FileReader();
         reader.onload = fileOnload;
         reader.readAsDataURL(file);
      }

      function fileOnload(e) {
         var result=e.target.result;
         $('#imgSalida').attr("src",result);
      }



 //configuraciones para un nuevo empleado
 function add_customer()
 {
     $('#errores').slideUp();
     save_method = 'add';
     $('#form')[0].reset(); // reset form on modals
     $('#modal_form').modal('show'); // show bootstrap modal
   //$('.modal-title').text('Add Person'); // Set Title to Bootstrap modal title
 }
 //obtiene la lista de paises
 function getcountries()
 {
     //Ajax Load data from ajax
   $.ajax({
     url : "<?php echo site_url('country/get_all/')?>",
     type: "GET",
     dataType: "JSON",
     success: function(data)
     {
       console.log('obtiene paises');
       //console.log(data);
       //cargar datos en el formulario
       $(data).each(function(i, v){ // indice, valor
           $("#country").append('<option value="' + v.key_country + '">' + v.name + '</option>');
       })

     },
     error: function (jqXHR, textStatus, errorThrown)
     {
         alert('Error al obtener datos');
     }
 });
 }

 //obtiene la lista de estados por pais
 function getstates(id,tipoId)
 {
   $.ajax({
     url : "<?php echo site_url('state/get_all_by_id/')?>"+id+"/"+tipoId,
     type: "GET",
     dataType: "JSON",
     success: function(data)
     {
       console.log('obtiene estados');
      // console.log(data);
       //cargar datos en el formulario
       $(data).each(function(i, v){ // indice, valor
          $("#state").append('<option value="' + v.key_state + '">' + v.name + '</option>');
       })

     },
     error: function (jqXHR, textStatus, errorThrown)
     {
         alert('Error al obtener datos');
     }
 });
 }
 //obtiene la lista de municipios por pais
 function getsmunicipalities(idEstado,idMun)
 {
   $.ajax({
     url : "<?php echo site_url('municipality/get_all_by_id/')?>"+idEstado+"/"+idMun,
     type: "GET",
     dataType: "JSON",
     success: function(data)
     {
       console.log('obtiene municipios');
      // console.log(data);
       var i=0;
       //cargar datos en el formulario
       $(data).each(function(i, v){ // indice, valor
          $("#municipality").append('<option value="' + v.key_municipality + '" >' + v.name + '</option>');
       })

     },
     error: function (jqXHR, textStatus, errorThrown)
     {
         alert('Error al obtener datos');
     }
 });
 }
 //obtiene la lista de estados, municipios, Localidad por codigo postal
 function getdatapostalcode(PostalCode)
 {
   $.ajax({
     url : "<?php echo site_url('postalcode/get_all_by_id/')?>"+PostalCode,
     type: "GET",
     dataType: "JSON",
     success: function(data)
     {
       //cargar datos en el formulario
       $(data).each(function(i, v){ // indice, valor
         EstID = v.key_state;
         MunID = v.key_municipality;

         var renglon = new Array(v.key_locality);
         LocID.push(renglon);
       });
       getstates(EstID,tipoIdEstado);
       getsmunicipalities(EstID,MunID);
       //pendiente localidades
     },
     error: function (jqXHR, textStatus, errorThrown)
     {
         alert('Error al obtener datos');
     }
 });

 }

 function getscolonies(PostalCode)
 {
   $.ajax({
     url : "<?php echo site_url('colony/get_all_by_id/')?>"+PostalCode,
     type: "GET",
     dataType: "JSON",
     success: function(data)
     {
       console.log('obtiene colonias');
       console.log(data);
       var i=0;
       //cargar datos en el formulario
       $(data).each(function(i, v){ // indice, valor
        // if(i=0)
        // {
        //   $("#municipality").append('<option value="' + v.key_municipality + '" selected>' + v.name + '</option>');
        // }else {
           $("#colony").append('<option value="' + v.key_colony + '" >' + v.name + '</option>');
        // }
         //i++;
       })

     },
     error: function (jqXHR, textStatus, errorThrown)
     {
         alert('Error al obtener datos');
     }
 });
 }


 function save()
 {
    if (validar())
    {
      console.log('valido');
         var url = "<?php echo site_url('customer/add')?>";

         if($("#img_select").val() !="")
         {
           $('#llevaImagen').val('si') ;
         }
         var formData = new FormData($("#form")[0]);
         console.log(formData);

          // ajax adding data to database
             $.ajax({
               url : url,
               type: "POST",
            //data: $('#form').serialize(),
              data : formData,
               dataType: "JSON",
               processData: false,
               contentType: false,
               success: function(data)
               {
                  if(data.respuesta == 'error')
                  {
                    $(".respuesta").html('<button type="button" class="btn btn-sm close" data-dismiss="alert" aria-label="Close"><i class="fa fa-times" aria-hidden="true"></i> </button>');
                      $(".respuesta").html(data.id_user +  data.cell_phone + data.birth_date + data.country + data.cp + data.street + data.num_exterior  );
                     $('#errores').slideDown().fadeOut(5000);
                      return false;
                   }else{
                      //if success close modal and reload ajax table
                      $('#modal_form').modal('hide');
                      location.reload();// for reload a page
                   }
               },
               error: function (jqXHR, textStatus, errorThrown)
               {
                   alert('Error al registrar los datos');
               }
           });
     }//fin validar
 }

 function limpiarpantalla()
 {
    //$("#country").selected();
    $("#state").empty();
    $("#municipality").empty();
    $("#colony").empty();
     $('#imgSalida').attr("src","");
     $("#id").val("");
     $("#iduser").val("");
     $("#llevaImagen").val("");
     $("#nameImagen").val("");
     $("#urlImagen").val("");

 }

 function validar()
 {
   var mensaje = 'Campos requeridos:  <br>';
   var respuesta = true;

   if($("#iduser").val()=="")
   {
     mensaje += 'Usuario <br>';
     respuesta = false;
   }
   if($("#birth_date").val()=="")
   {
     mensaje += 'Fecha de Nacimiento  <br>';
     respuesta = false;
   }
   if($("#cell_phone_").val()=="")
   {
     mensaje += 'Teléfono Celular <br>';
     respuesta = false;
   }

   if($("#country").val()=="-1")
   {
     mensaje += 'País<br>';
     respuesta = false;
   }
   if($("#cp").val()=="")
   {
     mensaje += 'Código Postal <br>';
     respuesta = false;
   }
   if($("#street").val()=="")
   {
     mensaje += 'Calle <br>';
     respuesta = false;
   }
   if($("#num_exterior").val()=="")
   {
     mensaje += 'No. Exterior <br>';
     respuesta = false;
   }


   if(respuesta == false)
   {
       $(".respuesta").html('<button type="button" class="btn btn-sm close" data-dismiss="alert" aria-label="Close"><i class="fa fa-times" aria-hidden="true"></i> </button>');
         $(".respuesta").html(mensaje);
        $('#errores').slideDown().fadeOut(5000);
   }
   return respuesta;
 }

 function edit_customer(id)
 {
   $('#errores').slideUp();
   save_method = 'update';
   $('#form')[0].reset(); // reset form on modals

   limpiarpantalla();//no resetea bien el formulario, limpiar a mano

   //Ajax Load data from ajax
   $.ajax({
     url : "<?php echo site_url('customer/edit/')?>" + id,
     type: "GET",
     dataType: "JSON",
     success: function(data)
     {
        var nombre = data.first_name + ' '+ data.last_name;

         $('[name="id"]').val(data.id);
         $('[name="id_user"]').val(data.id_user);
        // $('[name="autocomplete"]').val(nombre); //
          $('[name="usuario"]').val(nombre); //usuario
         $('[name="phone"]').val(data.phone);
         $('[name="cell_phone"]').val(data.cell_phone);
         $('[name="birth_date"]').val(data.birth_date);
         $('[name="sex"]').val(data.sex).change();//hacer un selected

         $('#imgSalida').attr("src",data.imageurl);
         $('[name="nameImagen"]').val(data.image);
         $('[name="urlImagen"]').val(data.imageurl);


         $('[name="cp"]').val(data.key_cp);
         $('[name="street"]').val(data.street);
         $('[name="num_exterior"]').val(data.num_exterior);
         $('[name="num_inside"]').val(data.num_inside);
         $('[name="street1"]').val(data.street_between1);
         $('[name="street2"]').val(data.street_between2);
         $('[name="complement"]').val(data.complement);
         $('[name="country"]').val(data.key_country).change();//hacer un selected

         //obtener datos direccion
         getdatapostalcode(data.key_cp);
         getscolonies(data.key_cp);
         $('[name="state"]').val(data.key_state).change();//hacer un selected
         $('[name="colony"]').val(data.key_colony).change();//hacer un selected


         $('#modal_form').modal('show'); // show bootstrap modal when complete loaded
         $('.modal-title').text('Editar Cliente'); // Set title to Bootstrap modal title

     },
     error: function (jqXHR, textStatus, errorThrown)
     {
         alert('Error al obtener datos');
     }
   });
 }

 //eliminamos datos
 function eliminar(id)
    {
       $('#id_delet').val(id);//enviar id de control al modal
       $('#modalEliminar').modal('show'); // abrir
   };

   function delete_customer()
   {
         id = $('#id_delet').val();//recuperar id de control al modal
           console.log('eliminar '+id);
       // ajax delete data from database
         $.ajax({
           url : "<?php echo site_url('customer/delete/')?>"+id,
           type: "POST",
           dataType: "JSON",
           success: function(data)
           {

              location.reload();
           },
           error: function (jqXHR, textStatus, errorThrown)
           {
               alert('Error al eliminar información');
           }
       });
   }




 </script>


 <!-- Bootstrap modal -->
 <div class="modal fade" id="modal_form" role="dialog">
 <div class="modal-dialog modal-lg">
   <div class="modal-content">
     <div class="modal-header">
     <!--  <button type="button" class="btn btn-danger btn-sm" data-dismiss="modal" aria-label="Close"><i class="fa fa-times" aria-hidden="true"></i></button> -->
        <h4 class="modal-title">Nuevo Cliente</h4>
       <button type="button" class="btn btn-sm" data-dismiss="modal"  onclick="limpiarpantalla()" aria-label="Close"><i class="fa fa-times" aria-hidden="true"></i></button>
     </div>


     <div class="modal-body form">
       <form action="#" id="form" class="form-horizontal">
      <!--   <form action="#" id="form" class="form-horizontal" method="post" enctype="multipart/form-data">-->

         <div class="form-body">

           <div id="errores" class="col-md-10 alert alert-danger respuesta" role="alert" style="display:none;">
             <!--<button type="button" class="btn btn-sm close" data-dismiss="alert" aria-label="Close">
                 <i class="fa fa-times" aria-hidden="true"></i>
             </button>-->
           </div>


           <input type="hidden" id="csrf" name="<?php echo $this->security->get_csrf_token_name();?>" value="<?php echo $this->security->get_csrf_hash();?>">
           <input type="hidden" name="id" id="id" >
           <input type="hidden" name="id_user" id="iduser" >
           <input type="hidden" name="llevaImagen" id="llevaImagen" >
           <input type="hidden" name="nameImagen" id="nameImagen" >
           <input type="hidden" name="urlImagen" id="urlImagen" >



           <div class="form-group">
             <div class="form-row">
                 <input class="form-control" id="autocomplete" name="usuario" type="text" aria-describedby="usuarioHelp"  maxlength="100"  tabindex="1" required>
             </div>
           </div>

           <div class="form-group">
                       <div class="form-row">
                         <div class="col-md-3 " >
                               <label for="name">Fecha de Nacimiento</label>
                                 <input class="form-control date numeros" data-provide="datepicker" data-date-language="es" autoclose="true" data-date-end-date="0d" data-date-format="yyyy-mm-dd" id="birth_date" name="birth_date" type="text" aria-describedby="birth_dateHelp"  placeholder="yyyy-mm-dd" maxlength="10"  tabindex="3" required>

                               </input>
                         </div>
                         <div class="col-md-2">
                           <label for="name">Sexo</label>
                           <select class="form-control" id="sex" name="sex" aria-describedby="sexHelp"   tabindex="6" required>
                             <option value="F">Femenino</option>
                             <option value="M">Masculino</option>
                           </select>
                         </div>
                         <div class="col-md-3">
                           <label for="price">Teléfono Celular</label>
                           <input class="form-control numeros" id="cell_phone_" name="cell_phone" type="text" aria-describedby="cell_phoneHelp"  placeholder="Ingrese No." maxlength="10"  tabindex="4" required>

                          </div>
                         <div class="col-md-2">
                           <label for="category">Tel. Casa</label>
                           <input class="form-control numeros" id="phone" name="phone" type="text" aria-describedby="phoneHelp"  placeholder="Ingrese No." maxlength="10"  tabindex="5" >
                         </div>
                       </div>
                     </div>

                     <div class="form-group">
                       <div class="form-row">
                         <div class="col-md-5">
                           <label for="price">País</label>
                           <select class="form-control" id="country" name="country" aria-describedby="countryHelp"   tabindex="6" required>
                             <option value="-1">Seleccione...</option>
                           </select>
                          </div>
                          <div class="col-md-3">
                            <label for="price">C.P.</label>
                            <input class="form-control numeros" id="cp" name="cp" type="text" aria-describedby="cpHelp"  placeholder="Código" maxlength="5"  tabindex="7" required>
                           </div>
                       </div>
                     </div>
                     <div class="form-group">
                       <div class="form-row">
                         <div class="col-md-5">
                           <label for="category">Estado</label>
                           <select class="form-control" id="state" name="state" aria-describedby="stateHelp"   tabindex="8" required>

                           </select>
                         </div>
                         <div class="col-md-5">
                           <label for="price">Municipio</label>
                           <select class="form-control" id="municipality" name="municipality" aria-describedby="municipalityHelp"   tabindex="9" required>

                           </select>
                          </div>
                       </div>
                     </div>
                     <div class="form-group">
                       <div class="form-row">
                         <div class="col-md-5">
                           <label for="category">Colonia/Asentamiento</label>
                           <select class="form-control" id="colony" name="colony" aria-describedby="localityHelp"   tabindex="10" required>

                           </select>
                         </div>
                         <div class="col-md-5">
                           <label for="price">Calle</label>
                           <input class="form-control" id="street" name="street" type="text" aria-describedby="streetHelp"  placeholder="Ingrese Calle" maxlength="50"  tabindex="11" required>

                          </div>
                       </div>
                     </div>
                     <div class="form-group">
                       <div class="form-row">

                         <div class="col-md-2">
                           <label for="category">No. Exterior</label>
                           <input class="form-control numeros" id="num_exterior" name="num_exterior" type="text" aria-describedby="num_exteriorHelp"  placeholder="Ingrese No" maxlength="4"  tabindex="12" required>

                         </div>
                         <div class="col-md-2">
                           <label for="category">No. Interior</label>
                           <input class="form-control numeros" id="num_inside" name="num_inside" type="text" aria-describedby="num_insideHelp"  placeholder="Ingrese No" maxlength="4"  tabindex="13" >

                         </div>
                         <div class="col-md-3">
                           <label for="price">Entre Calle</label>
                           <input class="form-control" id="street1" name="street1" type="text" aria-describedby="street1Help"  placeholder="Ingrese Calle" maxlength="50"  tabindex="14" >

                          </div>
                         <div class="col-md-3">
                           <label for="category">y Calle</label>
                           <input class="form-control" id="street2" name="street2" type="text" aria-describedby="street2Help"  placeholder="Ingrese Calle" maxlength="50"  tabindex="15" >
                         </div>
                       </div>
                     </div>
                     <div class="form-group">
                       <div class="form-row">
                         <div class="col-md-10">
                           <label for="price">Complementos de Dirección</label>
                           <input class="form-control" id="complement" name="complement" type="text" aria-describedby="complementHelp"  placeholder="Ingrese complemento" maxlength="50"  tabindex="16" >
                          </div>
                       </div>
                     </div>

                     <!-- SECCION PARA AGREGAR IMAGENES-->

          <div class="form-group">
            <div class="form-row">
              <div class="col-md-10">
                  <div class="card" >
                    <div class="card-header">Foto</div>
                      <div class="card-body">

                        <!--tabla para agregar detalles-->

                          <div class="form-group" id="drop">
                             <div class="form-row">
                                <div  class="col-md-7">
                                  <!--<label for="exampleFormControlFile1">Seleccione la imagen</label>-->
                                  <!--<input type="file" class="form-control" id="imagenes[]" name="imagenes[]" multiple>-->
                                  <input type="file" class="form-control" name="images[]" id="img_select">
                                </div>

                                <div  class="col-md-3">
                                  <!--MOSTRAR IMAGENE-->
                                  <img id="imgSalida" width="100%" height="100%" src="" class="img-thumbnail rounded float-right"/>
                                </div>
                             </div>
                         </div>

                      </div>
                    </div>
                  </div>
                </div>
            </div>
            <!-- fin SECCION PARA AGREGAR IMAGENES-->

         </div>
       </form>
         </div>
         <div class="modal-footer">
           <button type="button" id="btnSave" onclick="save()" class="btn btn-primary">Guardar</button>
           <button type="button" class="btn btn-danger" onclick="limpiarpantalla()" data-dismiss="modal">Cancelar</button>
         </div>
       </div><!-- /.modal-content -->
     </div><!-- /.modal-dialog -->
   </div><!-- /.modal -->
 <!-- End Bootstrap modal -->



   <!-- Modal Eliminar producto-->
   <div class="modal fade" id="modalEliminar" tabindex="-1" role="dialog" aria-labelledby="modalEliminarLabel" aria-hidden="true">
   <div class="modal-dialog" role="document">
     <div class="modal-content">
       <div class="modal-header">
         <h5 class="modal-title" id="modalEliminarLabel">¿Seguro desea eliminar este cliente?</h5>
         <button class="close" type="button" data-dismiss="modal" aria-label="Close">
           <span aria-hidden="true">×</span>
         </button>
       </div>
       <input type="hidden" value="" name="id_delet" id="id_delet"/>
      <!-- <div class="modal-body">Seleccione "Eliminar" si está seguro de la acción.</div>-->
       <div class="modal-footer">
         <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancelar</button>
           <button type="button" id="btnSave" onclick="delete_customer()" class="btn btn-primary">Eliminar</button>
       </div>
     </div>
   </div>
   </div>
