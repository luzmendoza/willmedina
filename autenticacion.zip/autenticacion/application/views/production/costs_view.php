<?php defined('BASEPATH') OR exit('No direct script access allowed');?>

   <div class="card">
     <div class="card-header">Costos Por Producto</div>
     <div class="card-body">
      <form action="#" id="form" class="form-horizontal">
         <input type="hidden" name="<?php echo $this->security->get_csrf_token_name();?>" value="<?php echo $this->security->get_csrf_hash();?>">

         <div id="errores" class="col-md-10 alert alert-danger respuesta" role="alert" style="display:none;">
         </div>
         <div id="exito" class="col-md-10 alert alert-success respexito" role="alert" style="display:none;">
         </div>

        <input type="hidden" name="arrDetalles" id="arrDetalles" >
         <input  type="hidden" id="id" name="id"><!--id del stock-->
         <input  type="hidden" id="id_product" name="id_product">


         <!--Totales-->
           <div class="form-group">
             <div class="form-row">
               <div class="col-md-2">
                 <label for="codigo">Código </label>
                 <input class="form-control" id="autocompletecodigo" name="codigo" type="text" placeholder="ejemplo: wm-p-0001" maxlength="10" tabindex="1" required>
               </div>
               <div class="col-md-4">
                 <label for="nombre">Nombre </label>
                 <input class="form-control" id="autocompleteproduct" name="name" type="text" placeholder="ejemplo: palazzo" maxlength="50" tabindex="2" required>
               </div>

               <div class="col-md-2">
                 <label for="cantidad">Mano de obra</label>
                 <div class="input-group mb-3">
                  <div class="input-group-prepend">
                    <span class="input-group-text">$</span>
                  </div>
                  <input type="text" id="workforce" name="workforce" tabindex="3" maxlength="7" required class="form-control numeros" aria-label="Amount (to the nearest dollar)">
                  <div class="input-group-append">
                    <span class="input-group-text">.00</span>
                  </div>
                </div>
               </div>

               <div class="col-md-2">
                 <label for="cantidad">Gastos Fijos</label>
                 <div class="input-group mb-3">
                  <div class="input-group-prepend">
                    <span class="input-group-text">$</span>
                  </div>
                  <input type="text" id="gastos" name="gastos" tabindex="4" maxlength="7" required class="form-control numeros" aria-label="Amount (to the nearest dollar)">
                  <div class="input-group-append">
                    <span class="input-group-text">.00</span>
                  </div>
                </div>
               </div>


             </div>
           </div>

           <!-- SECCION PARA AGREGAR DETALLES-->
             <div class="form-group">
               <div class="form-row">
                 <div class="col-md-8">
                     <div class="table-responsive">
                           <!--tabla para agregar detalles-->
                           <table class="table" id="dtDetalles" name="dtDetalles">
                             <thead>
                               <tr>
                                 <th hidden></th>
                                 <th  class="col-sm-2">Insumo
                                   <select class="form-control" id="supply" name="supply" aria-describedby="supplyHelp"   tabindex="5">
                                   </select>
                                 </th>
                                 <th class="col-sm-1">Cantidad
                                   <input class="form-control numeros"  id="cantidad" name="cantidad" type="text" placeholder="0" maxlength="3"  tabindex="6">
                                 </th>
                                 <th class="col-sm-2">Medida
                                   <select class="form-control" id="medida" name="medida" aria-describedby="medidaHelp"   tabindex="7" required>
                                     <option value="1">mt(s)</option>
                                     <option value="2">cm(s) </option>
                                     <option value="3">pza(s)</option>
                                   </select>
                                 </th>
                                 <th hidden></th>
                                 <th scope="col">
                                   <a class="btn btn-primary btn-sm " data-toggle="tooltip" data-placement="top" title="Agregar" onclick="agregardetalles()" href="#">
                                     <i class="fa fa-plus"></i>
                                   </a>
                                 </th>
                               </tr>
                             </thead>

                             <tbody id="dtDetallesBody">
                               <tr>
                                <td hidden></td>
                                 <td class="col-sm-2"></td>
                                 <td class="col-sm-1"></td>
                                 <td class="col-sm-1"></td>
                                   <td hidden></td>
                                 <td></td>
                               </tr>
                             </tbody>


                           </table>

                         </div><!--fin responsive table-->

                     </div>

                     <div class="col-md-2">
                       <label for="total">Total Producción</label>
                       <div class="input-group mb-3">
                        <div class="input-group-prepend">
                          <span class="input-group-text">$</span>
                        </div>
                        <input type="text" id="total" name="total" tabindex="7" maxlength="7" required readonly class="form-control numeros" aria-label="Amount (to the nearest dollar)">
                        <div class="input-group-append">
                          <span class="input-group-text">.00</span>
                        </div>
                      </div>
                     </div>
                   </div>
               </div>
   <!--FIN SECCION PARA AGREGAR DETALLES-->

   <div class="form-group">
     <div class="form-row">
       <div class="col-md-5">
          <label for="descripcion_workforce">Comentarios Mano de Obra</label>
         <input class="form-control" id="descripcion_workforce" name="descripcion_workforce" type="text" placeholder="Agregar comentarios" maxlength="100" tabindex="10" required>
       </div>
       <div class="col-md-5">
          <label for="descripcion_gastos">Comentarios Gastos Fijos</label>
         <input class="form-control" id="descripcion_gastos" name="descripcion_gastos" type="text" placeholder="Agregar comentarios" maxlength="100" tabindex="11" required>
       </div>
     </div>
   </div>


           <div class="form-group">
             <div class="form-row">
               <div class="col-md-8">
               </div>
               <div class="col-md-1">
                 <button type="button" id="btnSave" onclick="save()" class="btn btn-primary">Guardar</button>
               </div>
               <div class="col-md-1">
                 <button type="button" id="btnCancelar" onclick="limpiar()" class="btn btn-danger">Cancelar</button>
               </div>
             </div>
           </div>


       </form>
     </div>
   </div>


   <script type="text/javascript">
   $(document).ready( function () {
        $('#errores').slideUp();

     // Validar solo numeros
     	$(".numeros").keypress(function (e) {
     	 	if (e.which != 8 && e.which != 0 && (e.which < 48 || e.which > 57)) {
                 return false;
     		}
     	});
      getsupplies();

      //sumar el costo total
      $('#workforce').change(function(e) {
           if($('#workforce').val() != '')
           {
               if ( $('#total').val() == '')
               {
                 total = 0;
               }else{
                 total = parseInt($('#total').val());
               }
                total = total + parseInt($('#workforce').val());
                $('#total').val(total);
           }
       });
       $('#gastos').change(function(e) {
            if($('#gastos').val() != '')
            {
                 if ( $('#total').val() == '')
                 {
                   total = 0;
                 }else{
                   total = parseInt($('#total').val());
                 }
                 total = total + parseInt($('#gastos').val());
                 $('#total').val(total);
            }

        });

   });// fin ready function

   var preciosupply = 0;

   function save()
   {
      if(validar())
      {
          var url = "<?php echo site_url('production/add')?>";

          // ajax adding data to database
            $.ajax({
              url : url,
              type: "POST",
              data: $('#form').serialize(),
              dataType: "JSON",
              success: function(data)
              {
                 console.log(data);
                 console.log(data.Usuario);
                 if(data.respuesta == 'error')
                 {
                   $(".respuesta").html('<button type="button" class="btn btn-sm close" data-dismiss="alert" aria-label="Close"><i class="fa fa-times" aria-hidden="true"></i> </button>');
                     $(".respuesta").html(data.producto );
                    $('#errores').slideDown().fadeOut(5000);
                     return false;
                  }else{
                    $(".respexito").html('<button type="button" class="btn btn-sm close" data-dismiss="alert" aria-label="Close"><i class="fa fa-times" aria-hidden="true"></i> </button>');
                    $(".respexito").html("Registro realizado exitosamente");
                     $('#exito').slideDown().fadeOut(5000);
                      //return true;
                      // location.reload();// for reload a page  ?????
                      limpiar();
                  }
              },
              error: function (jqXHR, textStatus, errorThrown)
              {
                  alert('Error al registrar los datos');
              }
          });

      }
   }
   //validar que los datos obligatorios sean ingresados antes de realizar el registro
   function validar()
   {
       var mensaje = 'Campos requeridos:  <br>';
       var respuesta = true;

       if($("#id_product").val()=="" )
       {
         mensaje += 'Producto <br>';
         respuesta = false;
       }
       if($("#gastos").val()=="" )
       {
         mensaje += 'Importe de gastos <br>';
         respuesta = false;
       }
       if($("#workforce").val()=="" )
       {
         mensaje += 'Importe mano de obra <br>';
         respuesta = false;
       }
       if($("#arrDetalles").val()=="" || $('#arrDetalles').val() == '[]' )
       {
         mensaje += 'Minimo un detalle de Insumo <br>';
         respuesta = false;
       }


       if(respuesta == false)
       {
           $(".respuesta").html('<button type="button" class="btn btn-sm close" data-dismiss="alert" aria-label="Close"><i class="fa fa-times" aria-hidden="true"></i> </button>');
             $(".respuesta").html(mensaje);
            $('#errores').slideDown().fadeOut(5000);
       }
       return respuesta;
   }


   //limpiar todo..
   function limpiar()
   {
     //no eliminar la primera fila nunca
       var trs=$("#dtDetallesBody tr").length;
       for (var i = 0; i < trs-1; i++) {
           $("#dtDetallesBody tr:last").remove();
       }

       $("#id_product").val("");
       $("#id").val("");
       $("#descripcion_gastos").val("");
       $("#cantidad").val("0");
       $("#autocompletecodigo").val("");
       $("#autocompleteproduct").val("");
       $("#descripcion_workforce").val("");
       $("#arrDetalles").val("");
       $("#workforce").val("");
       $("#gastos").val("");
       $("#total").val("");
       $("#supply").val("1");
       $("#medida").val("1");
   }

   //autocomplete para recuperar al producto
   var optionscodigo = {
     url: "<?php echo site_url('product/autocomplete')?>", //esta es la data
     getValue: "sku", //este es el valor que busca el autocomplete, puede ser string o funcion
     template: {  //muestra una descripcion sumado al elemento de busqueda, aparece en letra mas pequeña :)
       type: "description",
       fields: {
         description: "name"
       }
     },
     list: {
         match: { //este hace una busqueda por coincidencia
           enabled: true
         },
         sort: { //ordena los datos de la lista
           enabled: true
         },
         onChooseEvent: function() {
           //llenar los combos y cajas
           var nombre = $("#autocompletecodigo").getSelectedItemData().name.trim();
           var id = $("#autocompletecodigo").getSelectedItemData().id;
             $("#autocompleteproduct").val(nombre).trigger("change");
             $("#id_product").val(id).trigger("change");
         }
       },
     theme: "bootstrap",
     placeholder: "ejemplo: wm-pn-0001",
     adjustWidth: false //linea super necesaria para que se vea la lista en horizontal :) y no letra por letra hacia abajo
   };
   //opcion de busqueda cpor nombre
   var optionsproduct = {
     url: "<?php echo site_url('product/autocomplete')?>", //esta es la data
     getValue: "name", //este es el valor que busca el autocomplete, puede ser string o funcion
     template: {  //muestra una descripcion sumado al elemento de busqueda, aparece en letra mas pequeña :)
       type: "description",
       fields: {
         description: "sku"
       }
     },
     list: {
         match: { //este hace una busqueda por coincidencia
           enabled: true
         },
         sort: { //ordena los datos de la lista
           enabled: true
         },
         onChooseEvent: function() {
           //llenar los combos y cajas
           var code = $("#autocompleteproduct").getSelectedItemData().sku.trim();
           var id = $("#autocompleteproduct").getSelectedItemData().id;
             $("#autocompletecodigo").val(code).trigger("change");
             $("#id_product").val(id).trigger("change");
         }
       },
     theme: "bootstrap",
     placeholder: "Ejemplo: vestido negro",
     adjustWidth: false //linea super necesaria para que se vea la lista en horizontal :) y no letra por letra hacia abajo
   };

   //asignar propiedad autocomplete a los campos
   $("#autocompletecodigo").easyAutocomplete(optionscodigo);
    $("#autocompleteproduct").easyAutocomplete(optionsproduct);


    //obtiene la lista de tallas disponibles
    function getsupplies()
    {
        //Ajax Load data from ajax
        $.ajax({
          url : "<?php echo site_url('supply/get_all/')?>",
          type: "GET",
          dataType: "JSON",
          success: function(data)
          {
            //cargar datos en el formulario
            $(data).each(function(i, v){ // indice, valor
                        $("#supply").append('<option value="' + v.id + '">' + v.name + '</option>');
                    })

          },
          error: function (jqXHR, textStatus, errorThrown)
          {
              alert('Error al obtener datos');
          }
      });
    }

    //agrega detalles a la tabla
    function agregardetalles()
    {
        var arrProdDetalles = new Array();
        var nuevafila = true;

        var supplyid = $("#supply").val();
        var supply = $("#supply option:selected").text();
        var cantidad = $("#cantidad").val();
        var medidaid = $("#medida").val();
        var medida = $("#medida option:selected").text();

        if(cantidad == "" || cantidad == "0"  )
        {
          alert('ingrese cantidad válida');
        }
        else{
            cantidad = parseInt(cantidad);
            var medidaid = $("#medida").val();
            //recuperar el precio del Insumo
            calculatotal(supplyid,cantidad,medidaid,'1');
              //verificar si ya tiene datos el array detalles
              if($('#arrDetalles').val() != '')
              {
                var deserializedDetalles = JSON.parse($('#arrDetalles').val());
                //recorre los datos y asigna la informacion
                for (var i = 0; i < deserializedDetalles.length; i++) {
                   var idS = deserializedDetalles[i][0];
                   var cant = deserializedDetalles[i][1];
                   var med = deserializedDetalles[i][2];

                   //validar si ya esta registrado el mismo articulo
                   if(supplyid==idS )
                   {
                       cant = cant+cantidad;
                       nuevafila = false;
                   }

                   var renglon = new Array(idS,cant,med);
                    arrProdDetalles.push( renglon );
                }
              }

             if(nuevafila)
              {
                    //asignar datos de la fila nueva
                    var renglon = new Array(supplyid,cantidad,medidaid);
                     arrProdDetalles.push( renglon );
                     //serializar en json el array de detalles
                     var jsonArray = JSON.stringify(arrProdDetalles)
                       //asignar datos al campo hidden
                    $('#arrDetalles').val(jsonArray) ;

                    //crea una nueva fila para la tabla  class="col-sm-2"
                      var fila='<tr id='+supplyid+'><td id="supplyid" hidden> ' +supplyid+'</td><td class="col-sm-2">'+supply+'</td><td id="cantidad" class="col-sm-1">'+cantidad+
                      '</td><td id="medida" class="col-sm-1">'+medida+'</td><td id="medidaid" hidden> ' +medidaid+'</td><td><a href="#" class="btn btn-danger btn-sm eliminarFila"  ><i class="fa fa-trash"></i> </a></td></tr>';
                         //asigna la fila
                     $('#dtDetallesBody tr:last').after(fila);
                 }
                 else{
                     console.log('no agrega fila');
                     //serializar en json el array de detalles
                     var jsonArray = JSON.stringify(arrProdDetalles)
                       //asignar datos al campo hidden
                     $('#arrDetalles').val(jsonArray) ;

                      $('#'+supplyid).each(function() {
                        var cantActual = $(this).find("td").eq(2).html();
                        console.log(cantActual);
                        cantActual= parseInt(cantActual)+cantidad;
                         $(this).find("td").eq(2).html(cantActual);
                      });
                 }
                  //limpiar todas
                   $("#cantidad").val('');
      }

    }

    function calculatotal(id,cantidad,medidaid,opc)
    {
        //Ajax Load data from ajax
        $.ajax({
          url : "<?php echo site_url('stocktaking/getstocksupply/')?>"+id,
          type: "GET",
          dataType: "JSON",
          success: function(data)
          {
            $(data).each(function(i, v){ // indice, valor
              preciosupply = v.unit_price;
              if(v.unit_measure == '2')//centimentros
              {
                //var medidaid = $("#medida").val();
                if(medidaid == '1')//metros
                {
                  cant = cantidad * 100;
                }else{
                  cant = cantidad;
                }
                //asignar
                if ( $('#total').val() == '')
                {
                  total = 0;
                }else{
                  total = parseInt($('#total').val());
                }
                precio = parseInt(v.unit_price) * cant;

                if(opc == '1')//sumar
                {
                  console.log('aquii');
                  total = total + precio;
                }else{
                  console.log('allaa');
                  total = total - precio;
                }
                $('#total').val(total);
              }else{
                console.log('esta aqui');
                  if ( $('#total').val() == '')
                  {
                    total = 0;
                  }else{
                    total = parseInt($('#total').val());
                  }
                  precio = parseInt(v.unit_price) * cantidad;
                  if(opc == '1')//sumar
                  {
                    total = total + precio;
                  }else{
                    total = total - precio;
                  }
                  $('#total').val(total);
              }
            });
          },
          error: function (jqXHR, textStatus, errorThrown)
          {
              alert('Error al obtener datos');
          }
      });

    }

    //elimina la fila seleccionada de la tabla detalles
    $(document).on('click','.eliminarFila',function()
    {
       //recupera la informacion de la fila a eliminar
       var tds = $(this).parent('td').parent('tr').find('td');
       var supplyElim = 0;
       var cantElim = 0;
       if(tds.length != 0)
        {
          supplyElim = parseInt(tds.eq(0).text());
          cantElim = parseInt(tds.eq(2).text());
          medidaElim = parseInt(tds.eq(4).text());
        }
        calculatotal(supplyElim,cantElim,medidaElim,'2');
        //eliminar datos del array detalles
        var arrProdDetalles = new Array();
        var deserializedDetalles = JSON.parse($('#arrDetalles').val());
        //recorre los datos y asigna la informacion
        for (var i = 0; i < deserializedDetalles.length; i++) {
           var idS = parseInt(deserializedDetalles[i][0]);
           var cant = parseInt(deserializedDetalles[i][2]);
           var medida = parseInt(deserializedDetalles[i][3]);

           //validar si es el renglon eliminado para ya no asignarlo
           if(supplyElim===idS)
           {
             //elimina la fila seleccionada
             $(this).parent('td').parent('tr').remove();
            }else{
              var renglon = new Array(idS,cant,medida);
              arrProdDetalles.push( renglon );
            }
        }
        //serializar en json el array de detalles
        var jsonArray = JSON.stringify(arrProdDetalles)
          //asignar datos al campo hidden
        $('#arrDetalles').val(jsonArray) ;

        console.log($('#arrDetalles').val());

        if($('#arrDetalles').val() == '[]')
        {
          console.log('oyeeee');
        }

    });

   </script>
