<style>
input:invalid + span:after {
    content: '✖';
    color: red;
    padding-left: 5px;
}

input:valid + span:after {
    content: '✓';
    color: green;
    padding-left: 5px;
}
</style>

<div class="row">
      <div class="col-1">
      <button class="btn btn-primary btn-sm" onclick="search_sale()"><i class="fa fa-search"></i> Ventas Anteriores</button>
      <p> </p>
      </div>
    </div>

    <input type="hidden" name="id_sucursal" id="id_sucursal" value="<?php echo $id_sucursal ?>" >


    <!-- Example DataTables Card-->
<div class="card mb-3">
  <div class="card-header">
    <i class="fa fa-table"></i> Ventas del día</div>
  <div class="card-body">
    <div class="table-responsive">
      <table class="table table-bordered" id="dtSales" width="100%" cellspacing="0">
        <thead>
          <tr>
            <th> No. </th>
            <th> Factura </th>
            <th> Fecha </th>
            <th> Total </th>
            <th hidden> </th>
            <th> Estatus </th>
            <th style="width:125px;">Acciones
            </p></th>
          </tr>
        </thead>
        <tbody>
          <?php foreach($sales as $sale): ?>
          <tr>
             <td style="width: 10%" id="id"> <?php echo $sale->id ?> </td>
             <td style="width: 30%" id="sales_check"> <?php echo $sale->sales_check ?> </td>
             <td style="width: 20%" id="date_sale"> <?php echo $sale->date_sale ?> </td>
             <td style="width: 20%" id="total"> <?php echo $sale->total ?> </td>
              <td style="width: 0%" id="status" hidden> <?php echo $sale->status ?> </td>
             <td style="width: 20%" id="estatus"> <?php echo $sale->estatus ?> </td>
             <td>
              <!--  <button class="btn btn-warning btn-sm" data-toggle="tooltip" data-placement="top" title="Devolver Producto(s)" onclick="devolver(<?php echo $sale->id;?>)"><i class="fa fa-ban"></i></button>-->
               <a href="#" class="btn btn-warning btn-sm devolver"  data-toggle="tooltip" data-placement="top" title="Devolver Producto(s)"><i class="fa fa-ban"></i> </a>
               <!--  <button class="btn btn-danger btn-sm " data-toggle="tooltip" data-placement="top" title="Cancelar Venta" onclick="cancelar(this)" ><i class="fa fa-times"></i></button> -->
                <a href="#" class="btn btn-danger btn-sm cancelar" data-toggle="tooltip" data-placement="top" title="Cancelar Venta" ><i class="fa fa-times"></i> </a>
             </td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
  <div class="card-footer small text-muted"></div>
</div>



<script type="text/javascript">
$(document).ready( function () {
     $('#errores').slideUp();

      $('#dtSales').DataTable({
        "language": {
                 "infoFiltered": " - filtrado de _MAX_ registros",
                 "info": "Mostrando página _PAGE_ de _PAGES_",
                 "emptyTable": "No hay datos disponibles en la tabla"
                }
      });

      $('#dateIni').datepicker({
          format: 'yyyy-mm-dd',
          endDate: new Date(),
          autoclose: true,
          language: 'es'

      });
      $('#dateFin').datepicker({
          format: 'yyyy-mm-dd',
          endDate: new Date(),
          autoclose: true,
          language: 'es'

      });
});
$(document).on('click','.cancelar',function()
{
   //recupera la informacion de la fila a eliminar
   var tds = $(this).parent('td').parent('tr').find('td');
   console.log(tds);
   idSale = parseInt(tds.eq(0).text());
   status = parseInt(tds.eq(4).text());

   if(status == 2)//cancelado
   {
     alert('La venta ya se encuentra Cancelada.');
   }else{
     $('#idsale').val(idSale);//enviar id de control al modal
     $('#sucursal').val($('#id_sucursal').val());
     $('#modalEliminar').modal('show'); // abrir
   }

});
$(document).on('click','.devolver',function()
{
   //recupera la informacion de la fila a eliminar
   var tds = $(this).parent('td').parent('tr').find('td');
   console.log(tds);
   idSale = parseInt(tds.eq(0).text());
   status = parseInt(tds.eq(4).text());

   if(status == 2)//cancelado
   {
     alert('La venta se encuentra Cancelada no hay producto(s) para devolver.');
   }else{
     //recuperar datos a mostrar para la devolucion
     $.ajax({
       url : "<?php echo site_url('sales/get_by_id/')?>"+idSale,
       type: "POST",
       dataType: "JSON",
       success: function(data)
       {
         console.log(data.id);
           //  var fecha = v.date_mov.substring(0,10);
           $("#id").val(data.id);
           $("#factura").val(data.sales_check);
           $("#fecha").val(data.date_sale.substring(0,10));
           $("#totaldev").val(data.total);
           $("#estatussale").val(data.estatus);

           //mostrar pantalla devolucion
           for (var i = 0; i < data.detalles.length; i++) {
               cantact = parseInt(data.detalles[i]['amount']) - parseInt(data.detalles[i]['amount_dev']);
               //crea una nueva fila para la tabla
                 var fila='<tr><td hidden><input hidden name="idsaledet" value="' +data.detalles[i]['id']+'" /></td><td id="id_product" hidden><input hidden name="idproduct" value="'
                 +data.detalles[i]['id_product']+'" /></td><td> ' +data.detalles[i]['sku']+'</td><td> ' +data.detalles[i]['name']+
                 '</td><td id="sizeid" hidden><input hidden name="idsize" value="' +data.detalles[i]['id_size']+'" /></td><td> ' +data.detalles[i]['talla']+
                 '</td><td><input class="form-control" maxlength="2" name="priceprod" value="'+data.detalles[i]['price']+'" readonly enabled /></td><td id="existence"><input class="form-control" maxlength="2" name="cant" value="'
                 +cantact+'" readonly enabled /></td><td><input type="number" min="0" max="'+cantact+
                 '" maxlength="2" class="form-control" step="1" name="cantdev" /><span class="validity"></span></td><td hidden><input hidden name="devact" value="' +data.detalles[i]['amount_dev']+'" /></td></tr>';
                    //asigna la fila
                $('#dtDetallesBody tr:last').after(fila);
            }

            $('#modalBuscar').modal('hide'); // cerrar
            $('#sucursalid').val($('#id_sucursal').val());
            $('#modalDevoluciones').modal('show'); // abrir


       },
       error: function (jqXHR, textStatus, errorThrown)
       {
           alert('Error al devolver información');
       }
     });
   }

});
function cancelarSale()
{
    id = $('#idsale').val();//recuperar id de control al modal
    idsuc = $('#sucursal').val();
    console.log('eliminar '+id);
    // ajax delete data from database
    $.ajax({
      url : "<?php echo site_url('sales/cancelar/')?>"+id+'/'+idsuc,
      type: "POST",
      dataType: "JSON",
      success: function(data)
      {
         location.reload();
      },
      error: function (jqXHR, textStatus, errorThrown)
      {
          alert('Error al eliminar información');
      }
  });
}//fin cancelarSale

function devolucionSale()
{
   var continuar = false;
   var arrProdDetalles = new Array();

    $('#dtDetallesBody tr').each(function(index, element){

        if(index>0)
        {
          var IDSaleDet = $(element).find("td [name=idsaledet]").val(),
          IDProd = $(element).find("td [name=idproduct]").val(),
          IDSize = $(element).find("td [name=idsize]").val(),
          Cant = $(element).find("td [name=cant]").val(),
          CantDev = $(element).find("td [name=cantdev]").val();
          devact = $(element).find("td [name=devact]").val();
          precio = $(element).find("td [name=priceprod]").val();

          console.log('el precio');
          console.log(precio);

          //validar si la cantidad a devolver es mayor que la cantidad comprada
          if(CantDev > Cant)
          {
            alert('La cantidad a devolver no puede ser mayor que la cantidad comprada.');
            return;
          }
          //validar si la cantidad a devolver es mayor a cero por lo menos para un producto
          if(CantDev > 0)
          {
             continuar = true;
              var renglon = new Object();
              renglon['id'] = IDSaleDet;
              renglon['id_product'] = IDProd;
              renglon['id_size'] = IDSize;
              renglon['amount'] = CantDev;
              renglon['devact'] = devact;
              renglon['price'] = precio;

             arrProdDetalles.push( renglon );
          }
          console.log($(element).find('[name=cantdev]').val());
          console.log($(element).find('td [name=cantdev]').val());
         }
      });

    if(continuar)
    {
      //serializar en json el array de detalles
      var jsonArray = JSON.stringify(arrProdDetalles)
      //asignar datos al campo hidden
      $('#arrDetalles').val(jsonArray) ;
      console.log($('#arrDetalles').val());
      console.log( $("#id").val());
      idDevolucion = $("#id").val();
      //llamado ajax
      var url = "<?php echo site_url('sales/devolucion/')?>"+idDevolucion;
      // ajax adding data to database
       $.ajax({
          url : url,
          type: "POST",
          data: $('#formDev').serialize(),
          dataType: "JSON",
          success: function(data)
          {
             if(data.status == false)
             {
               $(".respuesta").html('<button type="button" class="btn btn-sm close" data-dismiss="alert" aria-label="Close"><i class="fa fa-times" aria-hidden="true"></i> </button>');
                 $(".respuesta").html(data.mensaje);
                $('#errores').slideDown().fadeOut(8000);
                 return false;
              }else{
                location.reload();
              }
          },
          error: function (jqXHR, textStatus, errorThrown)
          {
              alert('Error al registrar los datos');
          }
      });
    }else{
      alert('No hay productos a devolver.');
    }
}

//levantar modal para realizar busqueda por fechas
function search_sale()
{
     $('#modalBuscar').modal('show'); // abrir
}
function buscar()
{
    var continuar = false;
    var FechaIni = "A",FechaFin = "B",Factura = "C";
     //validar tenga fechas o factura
     if( $("#dateIni").val() != "" && $("#dateFin").val() != "")
     {
       continuar = true;
       FechaIni = $("#dateIni").val(),FechaFin = $("#dateFin").val();
     }
     if($("#facturabus").val() != "")
     {
       continuar = true;
       Factura = $("#facturabus").val();
     }

     if(continuar)
     {
       //recuperar datos a mostrar para la devolucion
       $.ajax({
         url : "<?php echo site_url('sales/get_by_filter/')?>"+FechaIni+"/"+FechaFin+"/"+Factura,
         type: "POST",
         dataType: "JSON",
         success: function(data)
         {
           console.log(data);
             $(data).each(function(i, v){ // indice, valor
               //crea una nueva fila para la tabla
               var fila='<tr><td id="id">'+v.id+'</td><td id="sales_check">'+v.sales_check+' </td><td id="date_sale">'+v.date_sale.substring(0,10)+
               '</td><td id="total">'+v.total+'</td><td id="status" hidden>'+v.status+' </td><td id="estatus">'+v.estatus+
               '</td><td> <a href="#" class="btn btn-warning btn-sm devolver"  data-toggle="tooltip" data-placement="top" title="Devolver Producto(s)"><i class="fa fa-ban"></i> </a> </td></tr>';
                  //asigna la fila
              $('#dtSalesAntBody tr:last').after(fila);
             });
         },
         error: function (jqXHR, textStatus, errorThrown)
         {
             alert('Error al devolver información');
         }
       });
    }
    else{
      alert("Ingrese Fechas o Factura para la busqueda.")
    }
}


</script>

<!-- Modal Eliminar producto-->
<div class="modal fade" id="modalEliminar" tabindex="-1" role="dialog" aria-labelledby="modalEliminarLabel" aria-hidden="true">
<div class="modal-dialog" role="document">
  <div class="modal-content">
    <div class="modal-header">
      <h5 class="modal-title" id="modalEliminarLabel">¿Esta seguro de cancelar la venta?</h5>
      <button class="close" type="button" data-dismiss="modal" aria-label="Close">
        <span aria-hidden="true">×</span>
      </button>
    </div>
    <input type="hidden" value="" name="idsale" id="idsale"/>
    <input type="hidden" value="" name="sucursal" id="sucursal"/>
  <div class="modal-body">Nota: Favor de regresar el importe al cliente.</div>
    <div class="modal-footer">
      <button class="btn btn-secondary" type="button" data-dismiss="modal">Regresar</button>
        <button type="button" id="btnSave" onclick="cancelarSale()" class="btn btn-primary">Cancelar Venta</button>
    </div>
  </div>
</div>
</div>


<!-- Modal Devolucion producto-->
<div class="modal fade" id="modalDevoluciones" role="dialog">
<div class="modal-dialog modal-lg">
  <div class="modal-content">
    <div class="modal-header">
    <!--  <button type="button" class="btn btn-danger btn-sm" data-dismiss="modal" aria-label="Close"><i class="fa fa-times" aria-hidden="true"></i></button> -->
      <h4 class="modal-title">Devoluciones</h4>
      <button type="button" class="btn btn-sm" data-dismiss="modal" aria-label="Close"><i class="fa fa-times" aria-hidden="true"></i></button>
    </div>


    <div class="modal-body form">
      <form action="#" id="formDev" class="form-horizontal">

        <div class="form-body">

          <!--mostrar mensajes de error/validacion-->
          <div id="errores" class="col-md-10 alert alert-danger respuesta" role="alert" style="display:none;">
          </div>

          <!--campos ocultos del formulario-->
          <input type="hidden" name="id" id="id" >
            <input type="hidden" name="arrDetalles" id="arrDetalles" >
            <input type="hidden" value="" name="sucursalid" id="sucursalid"/>

    <!--campos visibles del formulario-->
          <div class="form-group">
            <div class="form-row">
              <div class="col-md-3">
                <label for="factura">Factura</label>
                <input class="form-control" id="factura" readonly>
              </div>
              <div class="col-md-2">
                <label for="fecha">Fecha</label>
                <input class="form-control" id="fecha" readonly>
              </div>
              <div class="col-md-2">
                <label for="totaldev">Total</label>
                <input class="form-control" id="totaldev" readonly>
              </div>
              <div class="col-md-2">
                <label for="estatussale">Estatus</label>
                <input class="form-control" id="estatussale" readonly>
              </div>
            </div>
          </div>


          <div class="form-group">
            <div class="form-row">
              <div class="col-md-10">
                  <div class="table-responsive">
                        <!--tabla para agregar detalles-->
                        <table class="table" id="dtDetalles" name="dtDetalles">
                          <thead>
                            <tr>
                              <th hidden type="hidden" id="idsaledet"></th>
                              <th hidden type="hidden" id="id_product"></th>
                              <th scope="col">Código Producto</th>
                              <th scope="col">Nombre Producto</th>
                              <th hidden id="sizeid"></th>
                              <th scope="col">Talla  </th>
                              <th scope="col">Precio  </th>
                              <th scope="col">Cantidad</th>
                              <th scope="col">Regresar</th>
                                <th hidden type="hidden" id="devact"></th>
                            </tr>
                          </thead>

                          <tbody id="dtDetallesBody">
                            <tr>
                              <td hidden></td>
                              <td hidden></td>
                              <td></td>
                              <td></td>
                              <td hidden></td>
                              <td></td>
                              <td></td>
                              <td></td>
                              <td></td>
                              <td hidden></td>
                            </tr>
                          </tbody>
                        </table>
                      </div><!--fin responsive table-->

                  </div>
                </div>
            </div>


        </div>
      </form>
        </div>
        <div class="modal-footer">
          <button class="btn btn-secondary" type="button" data-dismiss="modal">Regresar</button>
          <button type="button" id="btnSave" onclick="devolucionSale()" class="btn btn-primary">Devolver</button>
        </div>
      </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
  </div><!-- /.modal -->
<!-- End Bootstrap modal -->



<!-- Modal Buscar Ventas -->
<div class="modal fade" id="modalBuscar" tabindex="-1" role="dialog" aria-labelledby="modalBuscarLabel" aria-hidden="true">
<div class="modal-dialog modal-lg">
  <div class="modal-content">
    <div class="modal-header">
      <h5 class="modal-title" id="modalBuscarLabel">Busqueda días anteriores</h5>
      <button class="close" type="button" data-dismiss="modal" aria-label="Close">
        <span aria-hidden="true">×</span>
      </button>
    </div>

    <div class="modal-body form">
      <form action="#" id="formDev" class="form-horizontal">
        <div class="form-body">

            <div class="form-group">
              <div class="form-row">
                <div class="col-md-3 " >
                    <label for="name">Fecha Inicio</label>
                      <input class="form-control date numeros" data-provide="datepicker" data-date-language="es" autoclose="true" data-date-end-date="0d" data-date-format="yyyy-mm-dd" id="dateIni" name="dateIni" type="text" aria-describedby="dateIniHelp"  placeholder="yyyy-mm-dd" maxlength="10"  tabindex="1" >
                    </input>
                </div>
                <div class="col-md-3 " >
                    <label for="name">Fecha Fin</label>
                      <input class="form-control date numeros" data-provide="datepicker" data-date-language="es" autoclose="true" data-date-end-date="0d" data-date-format="yyyy-mm-dd" id="dateFin" name="dateFin" type="text" aria-describedby="dateIniHelp"  placeholder="yyyy-mm-dd" maxlength="10"  tabindex="2" >
                    </input>
                </div>
                <div class="col-md-3 " >
                  <label for="name">Factura</label>
                    <input class="form-control"  id="facturabus" name="facturabus" type="text" aria-describedby="facturabusHelp"  placeholder="WM000001" maxlength="10"  tabindex="3" >
                    </input>
                </div>
              </div>
            </div>


            <div class="form-group">
              <div class="form-row">
                <div class="col-md-10">
                    <div class="table-responsive">
                          <!--tabla para agregar detalles-->
                          <table class="table" id="dtSalesAnt" name="dtSalesAnt">
                            <thead>
                              <tr>
                                <th> No. </th>
                                <th> Factura </th>
                                <th> Fecha </th>
                                <th> Total </th>
                                <th hidden> </th>
                                <th> Estatus </th>
                                <th >Acciones</th>
                              </tr>
                            </thead>

                            <tbody id="dtSalesAntBody">
                              <tr>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td hidden></td>
                                <td></td>
                                <td></td>
                              </tr>
                            </tbody>
                          </table>
                        </div><!--fin responsive table-->

                    </div>
                  </div>
              </div>

        </div>
      </form>
    </div>


    <div class="modal-footer">
      <button class="btn btn-secondary" type="button" data-dismiss="modal">Regresar</button>
      <button type="button" id="btnSave" onclick="buscar()" class="btn btn-primary">Buscar</button>
    </div>
  </div>
</div>
</div>
