<?php defined('BASEPATH') OR exit('No direct script access allowed');?>



   <div class="card">
     <div class="card-header">Registrar venta</div>
     <div class="card-body">
      <form action="#" id="formVentas" class="form-horizontal">
         <input type="hidden" name="<?php echo $this->security->get_csrf_token_name();?>" value="<?php echo $this->security->get_csrf_hash();?>">

         <div id="errores" class="col-md-10 alert alert-danger respuesta" role="alert" style="display:none;">
         </div>
         <div id="exito" class="col-md-10 alert alert-success respexito" role="alert" style="display:none;">
         </div>

        <input type="hidden" name="arrDetalles" id="arrDetalles" >
        <input type="hidden" name="diainicio" id="diainicio" value="<?php echo $diainicio ?>" >
        <input type="hidden" name="diafin" id="diafin" value="<?php echo $diafin ?>" >
        <input type="hidden" name="id_sucursal" id="id_sucursal" value="<?php echo $id_sucursal ?>" >

      <!--informacion del formulario-->
         <div class="form-group">
           <div class="form-row">
             <div class="col-md-5">
               <label for="user">Usuario: <?php echo $user ?></label>
             </div>
             <div class="col-md-3">
               <label for="user">Sucursal: <?php echo $sucursal ?></label>
             </div>
             <div class="col-md-2">
               <label for="date_buy" id="date_buy" >Fecha: 2018-08-08</label>
             </div>
           </div>
         </div>

         <!-- SECCION PARA AGREGAR DETALLES-->
                   <div class="form-group">
                     <div class="form-row">
                       <div class="col-md-10">


                           <div class="table-responsive">
                                 <!--tabla para agregar detalles-->
                                 <table class="table" id="dtDetalles" name="dtDetalles">
                                   <thead>
                                     <tr>
                                       <th hidden>
                                         <input  type="hidden" id="id_product" name="id_product">
                                       </th>
                                       <th scope="col">sku
                                         <input class="form-control"  id="autocompletesku" name="sku" type="text" maxlength="3"  tabindex="1">
                                       </th>
                                       <th scope="col">producto
                                         <input class="form-control"  id="autocompleteproducto" name="producto" type="text" maxlength="3"  tabindex="2">
                                       </th>
                                       <th hidden id="sizeid"></th>
                                       <th scope="col">Tamaño
                                         <select class="form-control" id="size" name="size" aria-describedby="sizeHelp"   tabindex="3">
                                         </select>
                                       </th>
                                       <th scope="col">Existencia
                                         <input class="form-control"  id="existencia" name="existencia" type="text"  aria-describedby="existenceHelp" placeholder="0"  maxlength="3"  tabindex="5" readonly>
                                       </th>
                                       <th scope="col">Precio
                                         <input class="form-control"  id="price" name="price" type="text" aria-describedby="priceceHelp" maxlength="9" value="0" readonly  tabindex="4">
                                       </th>
                                       <th scope="col">Cantidad
                                         <input class="form-control numeros"  id="cantidad" name="cantidad" type="text"  aria-describedby="existenceHelp" placeholder="0"  maxlength="3"  tabindex="6">
                                       </th>

                                       <th scope="col">
                                         <a class="btn btn-primary btn-sm " data-toggle="tooltip" data-placement="top" title="Agregar" onclick="agregardetalles()" href="#">
                                           <i class="fa fa-plus"></i>
                                         </a>
                                       </th>
                                     </tr>
                                   </thead>

                                   <tbody id="dtDetallesBody">
                                     <tr>
                                       <td hidden></td>
                                       <td></td>
                                       <td></td>
                                       <td hidden></td>
                                       <td hidden></td>
                                       <td></td>
                                       <td></td>
                                       <td></td>
                                       <td></td>
                                     </tr>
                                   </tbody>


                                 </table>

                               </div><!--fin responsive table-->

                           </div>
                         </div>
                     </div>

<!--Totales-->
          <!-- <div class="form-group">
             <div class="form-row">
               <div class="col-md-8">
               </div>
                <div class="col-md-1">
                   <label for="sku">SubTotal </label>
                </div>
               <div class="col-md-1">
                 <input class="form-control" id="subtotal" name="subtotal" type="text" value="0" maxlength="10" tabindex="1" readonly>
               </div>
             </div>
           </div>
           <div class="form-group">
             <div class="form-row">
               <div class="col-md-8">
               </div>
               <div class="col-md-1">
                  <label for="sku">Iva </label>
               </div>
               <div class="col-md-1">
                 <input class="form-control" id="iva" name="iva" type="text" value="0" maxlength="10" tabindex="1" readonly>
               </div>
             </div>
           </div>
         -->
           <div class="form-group">
             <div class="form-row">
               <div class="col-md-8">
               </div>
               <div class="col-md-1">
                  <label for="sku">Total </label>
               </div>
               <div class="col-md-1">
                 <input class="form-control" id="total" name="total" type="text" value="0"  maxlength="10" tabindex="1" readonly>
               </div>
             </div>
           </div>
<!--pie de pagina... botones-->
        <div class="form-group">
          <div class="form-row">
            <div class="col-md-8">
            </div>
            <div class="col-md-1">
              <button type="button" id="btnCancel" onclick="cancel()" class="btn btn-danger">Cancelar</button>
            </div>
            <div class="col-md-1">
              <button type="button" id="btnSave" onclick="save()" class="btn btn-primary">Pagar</button>
            </div>
          </div>
        </div>
       </form>
     </div>
   </div>


   <script type="text/javascript">
   $(document).ready( function () {

     if($("#diainicio").val()=='1')//se diainicio
     {
       $('#btnSave').attr("disabled", false);
     }else{
       //bloquear boton de venta y levantar un modal
       $('#sucursal_id').val($('#id_sucursal').val());
       $('#modalStartDay').modal('show'); // abrir
        $('#btnSave').attr("disabled", true);
     }

     if($("#diafin").val()=='1')//se finalizo el dia
     {
       $('#btnSave').attr("disabled", true);
       alert('No se pueden realizar ventas, el día ya ha finalizado.');
     }else{
       if($("#diainicio").val()=='1')
       {
          $('#btnSave').attr("disabled", false);
        }
     }

        $('#errores').slideUp();

     // Validar solo numeros
     	$(".numeros").keypress(function (e) {
     	 	if (e.which != 8 && e.which != 0 && (e.which < 48 || e.which > 57)) {
                 return false;
     		}
     	});

      $("#pagocte").keyup(function (e) {
        if (e.which >= 48 && e.which <= 57 || e.which == 8 ) {

          if($("#pagocte").val() == '')
          {
            $("#cambiocte").val('');
          }
          else{
                 console.log('voy a restar');
            var dinero = parseInt($("#pagocte").val());
            var pagar = parseInt($("#totalpagar").val());
            var devolver = dinero - pagar;
            console.log(dinero);
            $("#cambiocte").val(devolver);
          }
     		}

     });

      //asignar la fecha del dia a la pantalla
      var fechaMinima = new Date();
      console.log(fechaMinima);
	     dia = fechaMinima.getDate();//?
	     mes = fechaMinima.getMonth()+1;
	     anio = fechaMinima.getFullYear();
       mes =   PadLeft(mes, 2) ;//formatear mes

      $( "#date_buy" ).val(dia +"-"+ mes+"-"+anio);
      $("#date_buy").html('Fecha: '+ dia +"-"+ mes+"-"+anio);
      $("#date_buy").css( {"display":"inline", "color":"black"} );

      //obtener cat tallas
      getsizes();

      //agregar change a talla
      $('#size').change(function(e) {
           var id =$('#id_product').val();
           var idsize = $('#size').val();
           if($('#id_product').val() != '')
           {
              getdetailsproduct(id,idsize);
           }

       });

   });// fin ready function

   //rellena con cero a la izquierda
   function PadLeft(value, length) {
       return (value.toString().length < length) ? PadLeft("0" + value, length) :
       value;
   }

   function save()
   {
      //validar que tenga datos por pagar
      if( parseInt($("#total").val()) > 0)
      {
          //levantar modal de pago
          $('#totalpagar').val($('#total').val());
          $('#sucursal').val($('#id_sucursal').val());
          $('#arrDetallesPagar').val($('#arrDetalles').val());//enviar id de control al modal
          $('#modalPagar').modal('show'); // abrir
      }else{
        alert('Ningún producto agregado al carrito, favor de seleccionar e intentar nuevamente.');
      }
   }

   //limpiar todo.. no puede cancelar venta en proceso
   function cancel()
   {
     //no eliminar la primera fila nunca
       var trs=$("#dtDetallesBody tr").length;
       for (var i = 0; i < trs-1; i++) {
           $("#dtDetallesBody tr:last").remove();
       }

       $("#id_product").val("");
       $("#size").val("");
       $("#size option:selected").text("");
       $("#cantidad").val("");
       $("#existencia").val("");
       $("#price").val("");
       $("#autocompletesku").val("");
       $("#autocompleteproducto").val("");
       $("#subtotal").val("0");
       $("#iva").val("0");
       $("#total").val("0");
   }
//limpiar el modal de pago
function cancelapago()
{
    $("#cambiocte").val("");
    $("#pagocte").val("");
    $("#totalpagar").val("");
    //deshabilitar caja de pago y cambio
    //$('#blkefectivo').slideUp();
    //$('#blkcambio').slideUp();
    //$('#lblpagocte').slideUp();
    //$('#lblcambiocte').slideUp();
}
   //autocomplete para recuperar al producto
   var optionssku = {
     url: "<?php echo site_url('product/autocomplete')?>", //esta es la data
     getValue: "sku", //este es el valor que busca el autocomplete, puede ser string o funcion
     template: {  //muestra una descripcion sumado al elemento de busqueda, aparece en letra mas pequeña :)
       type: "description",
       fields: {
         description: "name"
       }
     },
     list: {
         match: { //este hace una busqueda por coincidencia
           enabled: true
         },
         sort: { //ordena los datos de la lista
           enabled: true
         },
         onChooseEvent: function() {
           //llenar los combos y cajas
           var nombre = $("#autocompletesku").getSelectedItemData().name.trim();
           var price = $("#autocompletesku").getSelectedItemData().price;
           var id = $("#autocompletesku").getSelectedItemData().id;
          // var userid = $("#autocompletesku").getSelectedItemData().id;
             $("#autocompleteproducto").val(nombre).trigger("change");
             $("#price").val(price).trigger("change");
             $("#id_product").val(id).trigger("change");
              var idsize = $('#size').val();
             getdetailsproduct(id,idsize);
         }
       },
     theme: "bootstrap",
     placeholder: "Ingresar sku",
     adjustWidth: false //linea super necesaria para que se vea la lista en horizontal :) y no letra por letra hacia abajo
   };
   //opcion de busqueda cpor nombre
   var optionsprod = {
     url: "<?php echo site_url('product/autocomplete')?>", //esta es la data
     getValue: "name", //este es el valor que busca el autocomplete, puede ser string o funcion
     template: {  //muestra una descripcion sumado al elemento de busqueda, aparece en letra mas pequeña :)
       type: "description",
       fields: {
         description: "sku"
       }
     },
     list: {
         match: { //este hace una busqueda por coincidencia
           enabled: true
         },
         sort: { //ordena los datos de la lista
           enabled: true
         },
         onChooseEvent: function() {
           //llenar los combos y cajas
           var sku = $("#autocompleteproducto").getSelectedItemData().sku.trim();
           var price = $("#autocompleteproducto").getSelectedItemData().price;
           var id = $("#autocompleteproducto").getSelectedItemData().id;
             $("#autocompletesku").val(sku).trigger("change");
             $("#price").val(price).trigger("change");
             $("#id_product").val(id).trigger("change");
             var idsize = $('#size').val();
            getdetailsproduct(id,idsize);
         }
       },
     theme: "bootstrap",
     placeholder: "Ingresar nombre",
     adjustWidth: false //linea super necesaria para que se vea la lista en horizontal :) y no letra por letra hacia abajo
   };

   //asignar propiedad autocomplete a los campos
   $("#autocompletesku").easyAutocomplete(optionssku);
    $("#autocompleteproducto").easyAutocomplete(optionsprod);

    //obtiene la lista de detalles del producto
    function getdetailsproduct(id,idsize)
    {
        idSuc = $("#id_sucursal").val();
          //Ajax Load data from ajax
          $.ajax({
            url : "<?php echo site_url('stocktaking/getstockproductsuc/')?>"+id+"/"+idsize+"/"+idSuc,
            type: "GET",
            dataType: "JSON",
            success: function(data)
            {
              $(data).each(function(i, v){ // indice, valor
                  $("#existencia").val(v.cantidad);
              });
              if(data==null)
              {
                $("#existencia").val(0);
              }
            },
            error: function (jqXHR, textStatus, errorThrown)
            {
                alert('Error al obtener datos');
            }
        });


    }



    //agrega detalles a la tabla
    function agregardetalles()
    {
        var arrProdDetalles = new Array();
        var cantExis  = 0;
        var nuevafila = true;

        var productoid = $("#id_product").val();
        var sizeid = $("#size").val();
        var colorid = $("#color").val();
        var size = $("#size option:selected").text();
        var color = $("#color option:selected").text();
        var cantidad = $("#cantidad").val();
        var price = parseFloat($("#price").val()).toFixed(2);
        var sku = $("#autocompletesku").val();
        var producto = $("#autocompleteproducto").val();
        var existencia = $("#existencia").val();
        console.log('existencia');
        console.log(existencia);

        if(cantidad == "" || cantidad == "0" || parseInt(price) == 0 || parseInt(productoid) == 0 )
        {
          alert('ingrese cantidad o producto válido');
        }
        else if(parseInt(cantidad) > parseInt(existencia))
        {
          alert('La cantidad ingresada es mayor a la existencia.');
        }
        else{

              cantidad = parseInt(cantidad);
              //verificar si ya tiene datos el array detalles
              if($('#arrDetalles').val() != '')
              {
                var deserializedDetalles = JSON.parse($('#arrDetalles').val());
                //recorre los datos y asigna la informacion
                for (var i = 0; i < deserializedDetalles.length; i++) {
                   var idP = deserializedDetalles[i][0];
                   var idS = deserializedDetalles[i][1];
                   var cant = deserializedDetalles[i][2];

                   //validar si ya esta registrado el mismo articulo
                   if(productoid==idP && sizeid==idS)
                   {
                     console.log('es igual');
                         if(parseInt(cantidad+cant) > parseInt(existencia))
                         {
                           //alert('La cantidad ingresada es mayor a la existencia. \n Existencia Actual ' );
                           alert('La cantidad ingresada es mayor a la existencia.' );
                           validaexis = false;
                           return;
                         }
                         cant = cant+cantidad;
                         nuevafila = false;

                   }

                   var renglon = new Array(idP,idS,cant);
                    arrProdDetalles.push( renglon );
                }
              }

              if(nuevafila)
              {
                    //asignar datos de la fila nueva
                    var renglon = new Array(productoid,sizeid,cantidad);
                     arrProdDetalles.push( renglon );
                     //serializar en json el array de detalles
                     var jsonArray = JSON.stringify(arrProdDetalles)
                       //asignar datos al campo hidden
                    $('#arrDetalles').val(jsonArray) ;

                    //crea una nueva fila para la tabla
                      var fila='<tr id="'+productoid+sizeid+'"><td id="id_product" hidden> ' +productoid+'</td><td> ' +sku+'</td><td> ' +producto+'</td><td id="sizeid" hidden> ' +sizeid+'</td><td> ' +size+
                      '</td><td>'+existencia+'</td><td>'+price+'</td><td id="existence">'+cantidad+'</td><td><a href="#" class="btn btn-danger btn-sm eliminarFila"  ><i class="fa fa-trash"></i> </a></td></tr>';
                         //asigna la fila
                     $('#dtDetallesBody tr:last').after(fila);
                 }
                 else{
                     console.log('no agrega fila');
                     //serializar en json el array de detalles
                     var jsonArray = JSON.stringify(arrProdDetalles)
                       //asignar datos al campo hidden
                     $('#arrDetalles').val(jsonArray) ;

                      $('#'+productoid+sizeid).each(function() {
                        var cantActual = $(this).find("td").eq(7).html();
                        console.log(cantActual);
                        cantActual= parseInt(cantActual)+cantidad;
                         $(this).find("td").eq(7).html(cantActual);
                      });
                 }


                   //realizar calculos de --Totales--
                   var total = parseFloat($("#total").val());
                  // var subtotal = parseFloat($("#subtotal").val());
                   //var iva = parseFloat($("#iva").val());

                   //subtotal = subtotal + (cantidad * price);
                   //iva = subtotal * (16/100);
                   total = total + (cantidad * price);//subtotal; // + iva;


                   //$("#subtotal").val(parseFloat(subtotal).toFixed(2));
                   //$("#iva").val(parseFloat(iva).toFixed(2));
                   $("#total").val(parseFloat(total).toFixed(2));


                  //limpiar todas
                   $("#cantidad").val('');
                   $("#autocompletesku").val('');
                   $("#autocompleteproducto").val('');
                   $("#price").val('');
                   $("#existencia").val('');

                   console.log(  $('#arrDetalles').val());

      }

    }

    //elimina la fila seleccionada de la tabla detalles
    $(document).on('click','.eliminarFila',function()
    {
       //recupera la informacion de la fila a eliminar
       var tds = $(this).parent('td').parent('tr').find('td');
       var producElim = 0;
       var sizeElim = 0;
       var cantElim = 0;
       var priceElim = 0;
       if(tds.length != 0)
        {
          producElim = parseInt(tds.eq(0).text());
          sizeElim = parseInt(tds.eq(3).text());
          priceElim = parseFloat(tds.eq(6).text());
          cantElim = parseInt(tds.eq(7).text());
        }
        //eliminar datos del array detalles
        var arrProdDetalles = new Array();
        var deserializedDetalles = JSON.parse($('#arrDetalles').val());
        //recorre los datos y asigna la informacion
        for (var i = 0; i < deserializedDetalles.length; i++) {
           var idP = parseInt(deserializedDetalles[i][0]);
           var idS = parseInt(deserializedDetalles[i][1]);
           var cant = parseInt(deserializedDetalles[i][2]);

           //validar si es el renglon eliminado para ya no asignarlo
           if(producElim===idP && sizeElim === idS && cantElim === cant )
           {
             //elimina la fila seleccionada
             $(this).parent('td').parent('tr').remove();
            }else{
              var renglon = new Array(idP,idS,cant);
              arrProdDetalles.push( renglon );
            }
        }
        //serializar en json el array de detalles
        var jsonArray = JSON.stringify(arrProdDetalles)
          //asignar datos al campo hidden
        $('#arrDetalles').val(jsonArray) ;

        //restar a los --Totales--
        var total = parseFloat($("#total").val());
        //var subtotal = parseFloat($("#subtotal").val());
        //var iva = parseFloat($("#iva").val());

        //subtotal = subtotal - (cantElim * priceElim);
        //iva = subtotal * (16/100);
        total = total - (cantElim * priceElim);//subtotal; // + iva;

      //  $("#subtotal").val(parseFloat(subtotal).toFixed(2));
      //  $("#iva").val(parseFloat(iva).toFixed(2));
        $("#total").val(parseFloat(total).toFixed(2));

    });

    //obtiene la lista de colores disponibles
    function getsizes()
    {
        //Ajax Load data from ajax
        $.ajax({
          url : "<?php echo site_url('size/get_all/')?>",
          type: "GET",
          dataType: "JSON",
          success: function(data)
          {
            console.log('obtiene Tamaños');
            console.log(data);
            //cargar datos en el formulario
            $(data).each(function(i, v){ // indice, valor
                        $("#size").append('<option value="' + v.id + '">' + v.abbreviation + '</option>');
                    })

          },
          error: function (jqXHR, textStatus, errorThrown)
          {
              alert('Error al obtener datos');
          }
      });
    }

    var tipopago = '';
    //pago en efectivo
    function efectivo()
    {
      tipopago = 'E';
        $('#tipopago').val('1');
      //habilitar caja de pago y cambio
      $('#blkefectivo').slideDown();
      $('#blkcambio').slideDown();
      $('#lblpagocte').slideDown();
      $('#lblcambiocte').slideDown();
    }
    function tarjeta()
    {
      tipopago = 'T';
      $('#tipopago').val('2');
      //deshabilitar caja de pago y cambio
      $('#blkefectivo').slideUp();
      $('#blkcambio').slideUp();
      $('#lblpagocte').slideUp();
      $('#lblcambiocte').slideUp();
    }

    function pagar()
    {
      //validar tipo de pago
      if(tipopago = 'E'){
        //validar que el efectivo sea mayor que el total
        if(validapago())
        {
          //registrar el movimiento de venta
          var url = "<?php echo site_url('sales/add')?>";

          // ajax adding data to database
            $.ajax({
              url : url,
              type: "POST",
              data: $('#formPagos').serialize(),
              dataType: "JSON",
              success: function(data)
              {
                 if(data.status == false)
                 {
                   $(".respuesta").html('<button type="button" class="btn btn-sm close" data-dismiss="alert" aria-label="Close"><i class="fa fa-times" aria-hidden="true"></i> </button>');
                     $(".respuesta").html(data.mensaje);
                    $('#errores').slideDown().fadeOut(8000);
                     return false;
                  }else{
                    $(".respexito").html('<button type="button" class="btn btn-sm close" data-dismiss="alert" aria-label="Close"><i class="fa fa-times" aria-hidden="true"></i> </button>');
                    $(".respexito").html("Venta registrada exitosamente");
                     $('#exito').slideDown().fadeOut(5000);
                      //return true;
                      cancelapago();//accion de limpiar
                      $('#modalPagar').modal('hide'); // cerrar
                      cancel();//limpiar la pantalla de venta
                      //imprimir ticket
                  }
              },
              error: function (jqXHR, textStatus, errorThrown)
              {
                  alert('Error al registrar los datos');
              }
          });

        }

      }

    }
    function validapago()
    {
      console.log('entro');
      var mensaje = '';
      var respuesta = true;

      if($("#pagocte").val()=="" ||  parseInt($("#pagocte").val()) == 0)
      {
        mensaje += 'Favor de ingresar Efectivo <br>';
        respuesta = false;
      }else{
        if(parseInt($("#pagocte").val()) < parseInt($("#totalpagar").val()))
        {
          mensaje += 'El pago del cliente es menor al total de la compra.  <br>';
          respuesta = false;
        }
      }

      if(respuesta == false)
      {
          $(".respuestaPago").html('<button type="button" class="btn btn-sm close" data-dismiss="alert" aria-label="Close"><i class="fa fa-times" aria-hidden="true"></i> </button>');
            $(".respuestaPago").html(mensaje);
           $('#erroresPago').slideDown().fadeOut(5000);
      }
      return respuesta;
    }

  /*  function cancelastartday()
    {
      $('#btnSave').attr("disabled", true);
      $('#modalStartDay').modal('hide'); // cerrar
      alert("Debe iniciar el día para realizar ventas.");
    }*/
    function startday()
    {
      //validar se ingrese una cantidad, minimo 0
      if($("#amount_ini").val()=='')
      {
          alert('Debe ingresar una cantidad para iniciar el día. Minimo $0');
      }else{
        //ejecutar ajax
        var url = "<?php echo site_url('sales/add_startday')?>";
        // ajax adding data to database
          $.ajax({
            url : url,
            type: "POST",
            data: $('#formStartDay').serialize(),
            dataType: "JSON",
            success: function(data)
            {
               if(data.status == false)
               {
                 $(".respuesta").html('<button type="button" class="btn btn-sm close" data-dismiss="alert" aria-label="Close"><i class="fa fa-times" aria-hidden="true"></i> </button>');
                   $(".respuesta").html(data.mensaje);
                  $('#errores').slideDown().fadeOut(8000);
                   return false;
                }else{
                  $(".respexito").html('<button type="button" class="btn btn-sm close" data-dismiss="alert" aria-label="Close"><i class="fa fa-times" aria-hidden="true"></i> </button>');
                  $(".respexito").html("Día iniciado exitosamente");
                   $('#exito').slideDown().fadeOut(5000);

                    //accion de limpiar
                    $("#amount_ini").val('');
                    $("#observaciones").val('');
                    $('#modalStartDay').modal('hide'); // cerrar
                    $('#btnSave').attr("disabled", false);//habilitar boton de pago
                }
            },
            error: function (jqXHR, textStatus, errorThrown)
            {
                alert('Error al registrar los datos');
            }
        });

      }

    }
   </script>



   <!-- Modal pagar-->
   <div class="modal fade" id="modalPagar" tabindex="-1" role="dialog" aria-labelledby="modalPagarLabel" aria-hidden="true">
   <div class="modal-dialog" role="document" >
     <div class="modal-content">
       <div class="modal-header">
         <h5 class="modal-title" id="modalPagarLabel">Pagos</h5>
         <button class="close" type="button" data-dismiss="modal" aria-label="Close">
           <span aria-hidden="true">×</span>
         </button>
       </div>
       <div class="modal-body form">

         <form action="#" id="formPagos" class="form-horizontal"  >
           <div class="form-body">

             <div id="erroresPago" class="col-md-10 alert alert-danger respuestaPago" role="alert" style="display:none;">
             </div>
                   <input type="hidden" name="arrDetallesPagar" id="arrDetallesPagar" >
                   <input type="hidden" name="tipopago" id="tipopago" >
                   <input type="hidden" name="sucursal" id="sucursal" >

                   <div class="form-group">
                     <div class="form-row">
                       <div class="col-md-10">
                         <label for="totalpagar">Total</label>
                         <input class="form-control" id="totalpagar" name="totalpagar" type="text" aria-describedby="totalHelp"   maxlength="10" tabindex="1" readonly>
                       </div>
                     </div>
                   </div>

                   <div class="form-group">
                     <div class="form-row">
                       <div class="btn-group" role="group" aria-label="Basic example">
                         <button type="button" class="btn btn-primary" onclick="efectivo()">Efectivo</button>
                         <button type="button" class="btn btn-secondary" onclick="tarjeta()">Tarjeta</button>
                       </div>
                     </div>
                  </div>

                   <div class="form-group">
                     <div class="form-row">
                       <div class="col-md-10">
                         <label for="pagocte" id="lblpagocte">Efectivo: </label>
                         <div id="blkefectivo" class="input-group mb-3">
                          <div class="input-group-prepend">
                            <span class="input-group-text">$</span>
                          </div>
                          <input type="text" id="pagocte" name="pagocte" tabindex="1" maxlength="7" required class="form-control numeros"  aria-label="Amount (to the nearest dollar)" >
                          <div class="input-group-append">
                            <span class="input-group-text">.00</span>
                          </div>
                        </div>
                       </div>
                     </div>
                   </div>

                   <div class="form-group">
                     <div class="form-row">
                       <div class="col-md-10">
                         <label for="cambiocte" id="lblcambiocte">Cambio: </label>

                         <div id="blkcambio" class="input-group mb-3">
                          <div class="input-group-prepend">
                            <span class="input-group-text">$</span>
                          </div>
                          <input type="text" id="cambiocte" name="cambiocte" tabindex="2" maxlength="7" readonly class="form-control numeros" aria-label="Amount (to the nearest dollar)" >
                          <div class="input-group-append">
                            <span class="input-group-text">.00</span>
                          </div>
                        </div>

                       </div>
                     </div>
                   </div>

            </div>
        </form>

       </div>
       <div class="modal-footer">
         <button class="btn btn-secondary" type="button" onclick="cancelapago()" data-dismiss="modal">Cancelar</button>
           <button type="button" id="btnSavePay" onclick="pagar()" class="btn btn-primary">Finalizar Pago</button>
       </div>
     </div>
   </div>
   </div>



      <!-- Modal Inicio de dia-->
      <div class="modal fade" id="modalStartDay" tabindex="-1" role="dialog" aria-labelledby="modalStartDayLabel" aria-hidden="true">
      <div class="modal-dialog" role="document" >
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="modalStartDayLabel">Inicio del día</h5>
            <button class="close" type="button" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">×</span>
            </button>
          </div>
          <div class="modal-body form">

            <form action="#" id="formStartDay" class="form-horizontal"  >
              <div class="form-body">

                <div id="erroresStartD" class="col-md-10 alert alert-danger respuestaStartD" role="alert" style="display:none;">
                </div>

                    <input type="hidden" name="sucursal_id" id="sucursal_id" >

                      <div class="form-group">
                        <div class="form-row">
                          <div class="col-md-10">
                            <label for="amount_ini" id="lblamount">Efectivo: </label>
                            <div id="lblamount" class="input-group mb-3">
                             <div class="input-group-prepend">
                               <span class="input-group-text">$</span>
                             </div>
                             <input type="text" id="amount_ini" name="amount_ini"  maxlength="7" required class="form-control numeros"  aria-label="Amount (to the nearest dollar)" tabindex="1">
                             <div class="input-group-append">
                               <span class="input-group-text">.00</span>
                             </div>
                           </div>
                          </div>
                        </div>
                      </div>

                      <div class="form-group">
                        <div class="form-row">
                          <div class="col-md-10">
                            <label for="totalpagar">Observaciones</label>
                            <input class="form-control" id="observaciones" name="observaciones" type="text" aria-describedby="totalHelp"   maxlength="100" tabindex="2" >
                          </div>
                        </div>
                      </div>


               </div>
           </form>

          </div>
          <div class="modal-footer">
            <button class="btn btn-secondary" type="button"  data-dismiss="modal">Cancelar</button>
              <button type="button" id="btnIniciarD" onclick="startday()" class="btn btn-primary">Guardar</button>
          </div>
        </div>
      </div>
      </div>
