Tipo de reporte:
Rango Fecha
Estatus
Tipo venta (tienda,online)--a futuro


<?php defined('BASEPATH') OR exit('No direct script access allowed');?>



   <div class="card">
     <div class="card-header">Reportes de Ventas</div>
     <div class="card-body">
      <form action="#" id="form" class="form-horizontal">
         <input type="hidden" name="<?php echo $this->security->get_csrf_token_name();?>" value="<?php echo $this->security->get_csrf_hash();?>">


    
      <!--informacion del formulario-->
      <div class="form-group">
        <label for="tiporeporte">Tipo de reporte:</label>
        <div class="form-row">
          <div class="btn-group-sm" role="group" aria-label="Basic example">
            <button type="button" class="btn btn-primary" onclick="efectivo()">Fecha</button>
            <button type="button" class="btn btn-secondary" onclick="tarjeta()">Estatus</button>
            <button type="button" class="btn btn-secondary" onclick="tarjeta()">Ambos</button>
          </div>
        </div>
     </div>

     <div class="form-group">
       <label for="tiporeporte">Estatus Ventas:</label>
       <div class="form-row">
         <div class="btn-group-sm" role="group" aria-label="Basic example">
           <button type="button" class="btn btn-success" onclick="tarjeta()">Activas</button>
           <button type="button" class="btn btn-danger" onclick="tarjeta()">Canceladas</button>
           <button type="button" class="btn btn-warning" onclick="tarjeta()">Devueltas</button>
           <button type="button" class="btn btn-primary" onclick="efectivo()">Todas</button>
         </div>
       </div>
    </div>
<!--pie de pagina... botones-->
        <div class="form-group">
          <div class="form-row">
            <div class="col-md-1">
              <button type="button" id="btnCancel" onclick="cancel()" class="btn btn-alert">Buscar información</button>
            </div>
            <div class="col-md-7">
            </div  >
            <div class="col-md-1">
              <button type="button" id="btnSave" onclick="save()" class="btn btn-primary">Imprimir</button>
            </div>
          </div>
        </div>
       </form>
     </div>
   </div>
