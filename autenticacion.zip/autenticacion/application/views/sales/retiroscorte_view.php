<?php defined('BASEPATH') OR exit('No direct script access allowed');?>



   <div class="card">
     <div class="card-header"><?php echo $tittle ?></div>
     <div class="card-body">
      <form action="#" id="form" class="form-horizontal">
         <input type="hidden" name="<?php echo $this->security->get_csrf_token_name();?>" value="<?php echo $this->security->get_csrf_hash();?>">

         <div id="errores" class="col-md-10 alert alert-danger respuesta" role="alert" style="display:none;">
         </div>
         <div id="exito" class="col-md-10 alert alert-success respexito" role="alert" style="display:none;">
         </div>

        <input type="hidden" name="opcion" id="opcion" value="<?php echo $opcion ?>" />
        <input type="hidden" name="diafin" id="diafin" value="<?php echo $diafin ?>" >
        <input type="hidden" name="diainicio" id="diainicio" value="<?php echo $diainicio ?>" >

      <!--informacion del formulario-->
         <div class="form-group">
           <div class="form-row">
             <div class="col-md-6">
               <label for="user">Usuario: <?php echo $user ?></label>
             </div>
             <div class="col-md-3">
               <label for="date_close" id="date_close" >Fecha: 2018-08-08</label>
             </div>
           </div>
         </div>

           <div class="form-group">
             <div class="form-row">
               <div class="col-md-3">
                 <label for="sku">Total</label>
                 <div id="lblamount" class="input-group mb-3">
                    <div class="input-group-prepend">
                      <span class="input-group-text">$</span>
                    </div>
                    <input type="text" id="total" name="total"  maxlength="7" required class="form-control numeros"  aria-label="Amount (to the nearest dollar)" tabindex="1">
                    <div class="input-group-append">
                      <span class="input-group-text">.00</span>
                    </div>
                 </div>
               </div>
               <div class="col-md-5">
                  <label for="sku">Observaciones </label>
                  <input class="form-control" id="observaciones" name="observaciones" type="text"  maxlength="150" tabindex="2">
               </div>
             </div>
           </div>
<!--pie de pagina... botones-->
        <div class="form-group">
          <div class="form-row">
            <div class="col-md-1">
              <button type="button" id="btnCancel" onclick="cancel()" class="btn btn-danger">Cancelar</button>
            </div>
            <div class="col-md-1">
              <button type="button" id="btnSave" onclick="save()" class="btn btn-primary">Guardar</button>
            </div>
          </div>
        </div>
       </form>
     </div>
   </div>


   <script type="text/javascript">
   $(document).ready( function () {

     $('#errores').slideUp();

     // Validar solo numeros
     	$(".numeros").keypress(function (e) {
     	 	if (e.which != 8 && e.which != 0 && (e.which < 48 || e.which > 57)) {
                 return false;
     		}
     	});

      //asignar la fecha del dia a la pantalla
      var fechaMinima = new Date();
      console.log(fechaMinima);
	     dia = fechaMinima.getDate();//?
	     mes = fechaMinima.getMonth()+1;
	     anio = fechaMinima.getFullYear();
       mes =   PadLeft(mes, 2) ;//formatear mes

      $( "#date_close" ).val(dia +"-"+ mes+"-"+anio);
      $("#date_close").html('Fecha: '+ dia +"-"+ mes+"-"+anio);
      $("#date_close").css( {"display":"inline", "color":"black"} );

      console.log($("#diafin").val());
      if($("#diafin").val()=='1')//se finalizo el dia
      {
        $('#btnSave').attr("disabled", true);
        alert('No se pueden realizar movimientos, el día ya ha finalizado.');
      }else{
        if($("#diainicio").val()=='1')//se diainicio
        {
          $('#btnSave').attr("disabled", false);
        }else{
           $('#btnSave').attr("disabled", true);
           alert('No se pueden realizar movimientos, el día no ha iniciado.');
        }
      }

   });// fin ready function
   //rellena con cero a la izquierda
   function PadLeft(value, length) {
       return (value.toString().length < length) ? PadLeft("0" + value, length) :
       value;
   }

   function save()
   {
     //validar que ingrese una Cantidad
     if($("#total").val()!='')
     {
       //ejecutar ajax
       var url = "<?php echo site_url('sales/addretirocorte')?>";

       // ajax adding data to database
         $.ajax({
           url : url,
           type: "POST",
           data: $('#form').serialize(),
           dataType: "JSON",
           success: function(data)
           {
              if(data.status == false)
              {
                $(".respuesta").html('<button type="button" class="btn btn-sm close" data-dismiss="alert" aria-label="Close"><i class="fa fa-times" aria-hidden="true"></i> </button>');
                  $(".respuesta").html(data.mensaje);
                 $('#errores').slideDown().fadeOut(8000);
                  return false;
               }else{
                 $(".respexito").html('<button type="button" class="btn btn-sm close" data-dismiss="alert" aria-label="Close"><i class="fa fa-times" aria-hidden="true"></i> </button>');
                 $(".respexito").html("Guardado exitosamente");
                  $('#exito').slideDown().fadeOut(5000);
                   //limpiar
                   $("#total").val('');
                   $("#observaciones").val('');

               }
           },
           error: function (jqXHR, textStatus, errorThrown)
           {
               alert('Error al registrar los datos');
           }
       });
     }
     else{
       alert('Debe ingresar una cantidad válida.')
     }
   }

   </script>
