<style>
.btn-file {
    position: relative;
    overflow: hidden;
}
.btn-file input[type=file] {
    position: absolute;
    top: 0;
    right: 0;
    min-width: 100%;
    min-height: 100%;
    font-size: 100px;
    text-align: right;
    filter: alpha(opacity=0);
    opacity: 0;
    outline: none;
    background: white;
    cursor: inherit;
    display: block;
}
</style>


<div class="row">
      <div class="col-1">
      <button class="btn btn-primary btn-sm" onclick="add_product()"><i class="fa fa-plus"></i> Agregar Producto</button>
      <p> </p>
      </div>
    </div>


    <!-- Example DataTables Card-->
<div class="card mb-3">
  <div class="card-header">
    <i class="fa fa-table"></i> Listado de Productos</div>
  <div class="card-body">
    <div class="table-responsive">
      <table class="table table-bordered" id="dtProductos" width="100%" cellspacing="0">
        <thead>
          <tr>
            <th> No. </th>
            <th> Código </th>
            <th> Nombre </th>
            <th> Precio </th>
            <th> Estatus </th>
            <th style="width:150px;">Acciones
            </p></th>
          </tr>
        </thead>
      <!--  <tfoot>
          <tr>
            <th> SKU </th>
            <th> Nombre </th>
            <th> Precio </th>
            <th> &nbsp; </th>
          </tr>
        </tfoot>-->
        <tbody>
          <?php foreach($products as $product): ?>
          <tr>
             <td style="width: 10%" id="id"> <?php echo $product->id ?> </td>
             <td style="width: 10%" id="sku"> <?php echo $product->sku ?> </td>
             <td style="width: 30%" id="name"> <?php echo $product->name ?> </td>
             <td style="width: 20%" id="price"> <?php echo $product->price ?> </td>
             <td style="width: 15%" id="status"> <?php echo $product->estatus ?> </td>
             <td style="width: 15%">
              <!--  <button class="btn btn-info btn-sm" data-toggle="tooltip" data-placement="top" title="Visualizar" onclick="see_product(<?php echo $product->id;?>)"><i class="fa fa-eye"></i></button>-->
                <button class="btn btn-primary btn-sm" data-toggle="tooltip" data-placement="top" title="Editar" onclick="edit_product(<?php echo $product->id;?>)"><i class="fa fa-edit"></i></button>
                <button class="btn btn-danger btn-sm " data-toggle="tooltip" data-placement="top" title="Eliminar" onclick="eliminar(<?php echo $product->id;?>)" ><i class="fa fa-trash"></i></button>

             </td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
  <div class="card-footer small text-muted"></div>
</div>




 <!--<script src="<?php // echo base_url('js/jquery-3.3.1.min.js')?>"></script>-->
  <script type="text/javascript">
  $(document).ready( function () {
       $('#errores').slideUp();

        $('#dtProductos').DataTable({
          "language": {
                   "infoFiltered": " - filtrado de _MAX_ registros",
                   "info": "Mostrando página _PAGE_ de _PAGES_",
                   "emptyTable": "No hay datos disponibles en la tabla"
                  }
        });

//valida solo numero y un punto
    $(".numerosypunto").keypress(function (e) {
      valor = $("#price").val();
      if(valor.indexOf('.')==-1)//no tiene Punto
      {
      	 	if (e.which != 8 && e.which != 0 && e.which != 46 && (e.which < 48 || e.which > 57)) {
                  return false;
      		}
      }else {
        if (e.which != 8 && e.which != 0  && (e.which < 48 || e.which > 57)) {
                return false;
        }
      }

  	});

    // Validar solo numeros
    	$(".numeros").keypress(function (e) {
    	 	if (e.which != 8 && e.which != 0 && (e.which < 48 || e.which > 57)) {
                return false;
    		}
    	});

       //cargar datos de colores
       getcolors();
        //cargar datos de categorias
        getcategorys();

        //Agrega una imagen de vista previa
       $('#img_select').change(function(e) {
         addImage(e);
        });

  });// fin ready function


    var save_method; //for save method string
    var table;

    function addImage(e){
       var file = e.target.files[0],
       imageType = /image.*/;

       if (!file.type.match(imageType))
        return;

       var reader = new FileReader();
       reader.onload = fileOnload;
       reader.readAsDataURL(file);
    }

    function fileOnload(e) {
       var result=e.target.result;
       $('#imgSalida').attr("src",result);
    }

    //configuraciones para un nuevo producto
    function add_product()
    {
        $('#errores').slideUp();
        save_method = 'add';
        $('#form')[0].reset(); // reset form on modals
        $('#modal_form').modal('show'); // show bootstrap modal
    }


    function edit_product(id)
    {

      $('#errores').slideUp();
      $("#editimagenes").css("display", "block");
      save_method = 'update';
      $('#form')[0].reset(); // reset form on modals

      limpiarpantalla();

      //Ajax Load data from ajax
      $.ajax({
        url : "<?php echo site_url('product/edit/')?>" + id,
        type: "GET",
        dataType: "JSON",
        success: function(data)
        {

            $('[name="id"]').val(data.id);
            $('[name="name"]').val(data.name);
            $('[name="description"]').val(data.description);
            $('[name="price"]').val(data.price);
            $('[name="sku"]').val(data.sku);
            $('[name="category"]').val(data.category);
            $('[name="color"]').val(data.color);
            $('[name="nameImagen"]').val(data.image);
            $('[name="urlImagen"]').val(data.imageurl);
            $('#imgSalida').attr("src",data.imageurl);
            $('[name="estatus"]').val(data.estatus);


            $('#modal_form').modal('show'); // show bootstrap modal when complete loaded
            $('.modal-title').text('Editar Producto'); // Set title to Bootstrap modal title

        },
        error: function (jqXHR, textStatus, errorThrown)
        {
            alert('Error al obtener datos');
        }
    });
    }

//visualiza un producto de la misma forma que lo haria un cliente, informacion basica e imagenes mas grandes
function see_product(id)
{
  $("#carrouselImg").empty();
  var sku = '';
    //Ajax Load data from ajax
  $.ajax({
    url : "<?php echo site_url('product/edit/')?>/" + id,
    type: "GET",
    dataType: "JSON",
    success: function(data)
    {
        //cargar datos en el formulario
        sku = data.sku;
        $("#lblVisNombre").html(data.name);
        //INFORMACION DE IMAGENES
         var deserializedImagenes = JSON.parse(data.galerias);
         for (var i = 0; i < deserializedImagenes.length; i++)
         {
            var imgid = deserializedImagenes[i]['id'];
            var imgname = deserializedImagenes[i]['name_image'];
            src = "<?php echo base_url('uploads/products/'); ?>"+imgname;

            if(i == 0)
            {
              elemento = '<div class="carousel-item active"><img class="d-block w-100" src="'+src+'" alt="First slide"></div>';
            }else{
              elemento = '<div class="carousel-item"><img class="d-block w-100" src="'+src+'" alt="First slide"></div>';
            }

             $("#carrouselImg").append(elemento);
         }


        $('#modalVisualizar').modal('show'); // show bootstrap modal when complete loaded
        $('.modal-title').text('Producto '+sku); // Set title to Bootstrap modal title

    },
    error: function (jqXHR, textStatus, errorThrown)
    {
        alert('Error al obtener datos');
    }
});
}

//validar que los datos obligatorios sean ingresados antes de realizar el registro
function validar()
{
    var mensaje = 'Campos requeridos:  <br>';
    var respuesta = true;


    if($("#name_").val()=="")
    {
      mensaje += 'Nombre  <br>';
      respuesta = false;
    }
    if($("#sku_").val()=="")
    {
      mensaje += 'Código <br>';
      respuesta = false;
    }
    if($("#price_").val()=="")
    {
      mensaje += 'Precio <br>';
      respuesta = false;
    }

    if($("#img_select").val()=="")
    {
      if(save_method == 'add')
      {
        mensaje += 'Agrege una imagen<br>';
        respuesta = false;
      }
    }

    if(respuesta == false)
    {
        $(".respuesta").html('<button type="button" class="btn btn-sm close" data-dismiss="alert" aria-label="Close"><i class="fa fa-times" aria-hidden="true"></i> </button>');
          $(".respuesta").html(mensaje);
         $('#errores').slideDown().fadeOut(5000);
    }
    return respuesta;
}

    function save()
    {
       if (validar())
       {
           if($("#img_select").val()!="")
           {
             $("#llevaImagen").val("si");
           }
            var url = "<?php echo site_url('product/add')?>";

            var formData = new FormData($("#form")[0]);
            console.log(formData);

             // ajax adding data to database
                $.ajax({
                  url : url,
                  type: "POST",
                //  data: $('#form').serialize(),
                 data : formData,
                  dataType: "JSON",
                  processData: false,
                  contentType: false,
                  success: function(data)
                  {
                     if(data.respuesta == 'error')
                     {
                       $(".respuesta").html('<button type="button" class="btn btn-sm close" data-dismiss="alert" aria-label="Close"><i class="fa fa-times" aria-hidden="true"></i> </button>');
                         $(".respuesta").html(data.sku + data.name + data.price );
                        $('#errores').slideDown().fadeOut(5000);
                         return false;
                      }else{
                         //if success close modal and reload ajax table
                         $('#modal_form').modal('hide');
                         location.reload();// for reload a page
                      }
                  },
                  error: function (jqXHR, textStatus, errorThrown)
                  {
                      alert('Error al registrar los datos');
                  }
              });
        }//fin validar
    }

    function delete_product()
    {
          id = $('#idproduct_delet').val();//recuperar id de control al modal
            console.log('eliminar '+id);
        // ajax delete data from database
          $.ajax({
            url : "<?php echo site_url('product/delete')?>/"+id,
            type: "POST",
            dataType: "JSON",
            success: function(data)
            {

               location.reload();
            },
            error: function (jqXHR, textStatus, errorThrown)
            {
                alert('Error al eliminar información');
            }
        });
    }

    //eliminamos datos
    function eliminar(id)
       {
          $('#idproduct_delet').val(id);//enviar id de control al modal
          $('#modalEliminar').modal('show'); // abrir
      };

      //obtiene la lista de colores disponibles
      function getcolors()
      {
          //Ajax Load data from ajax
        $.ajax({
          url : "<?php echo site_url('color/get_all/')?>",
          type: "GET",
          dataType: "JSON",
          success: function(data)
          {
            console.log('obtiene colores');
            console.log(data);
            //cargar datos en el formulario
            $(data).each(function(i, v){ // indice, valor
                        $("#color").append('<option value="' + v.id + '">' + v.name + '</option>');
                    })

          },
          error: function (jqXHR, textStatus, errorThrown)
          {
              alert('Error al obtener datos');
          }
      });
      }


      //obtiene la lista de categorias de prenda disponibles
      function getcategorys()
      {
          //Ajax Load data from ajax
        $.ajax({
          url : "<?php echo site_url('category/get_all/')?>",
          type: "GET",
          dataType: "JSON",
          success: function(data)
          {
            console.log('obtiene categorias');
            console.log(data);
            //cargar datos en el formulario
            $(data).each(function(i, v){ // indice, valor
                        $("#category").append('<option value="' + v.id + '">' + v.name + '</option>');
                    })

          },
          error: function (jqXHR, textStatus, errorThrown)
          {
              alert('Error al obtener datos');
          }
      });
      }

      function limpiarpantalla()
      {
          $('#imgSalida').attr("src","");
          $("#id_product").val("");
          $("#llevaImagen").val("");
          $("#nameImagen").val("");
          $("#urlImagen").val("");
          console.log('limpio');
      }



  </script>

  <!-- Bootstrap modal -->
  <div class="modal fade" id="modal_form" role="dialog">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
      <!--  <button type="button" class="btn btn-danger btn-sm" data-dismiss="modal" aria-label="Close"><i class="fa fa-times" aria-hidden="true"></i></button> -->
        <h4 class="modal-title">Nuevo Producto</h4>
        <button type="button" class="btn btn-sm" data-dismiss="modal" onclick="limpiarpantalla()"  aria-label="Close"><i class="fa fa-times" aria-hidden="true"></i></button>
      </div>


      <div class="modal-body form">
        <form action="#" id="form" class="form-horizontal" method="post" enctype="multipart/form-data">

            <div id="cargando"></div>

          <div class="form-body">

            <div id="errores" class="col-md-10 alert alert-danger respuesta" role="alert" style="display:none;">
              <!--<button type="button" class="btn btn-sm close" data-dismiss="alert" aria-label="Close">
                  <i class="fa fa-times" aria-hidden="true"></i>
              </button>-->
            </div>


                      <input type="hidden" id="csrf" name="<?php echo $this->security->get_csrf_token_name();?>" value="<?php echo $this->security->get_csrf_hash();?>">

                      <input type="hidden" name="id" id="id_product" >
                      <input type="hidden" name="opcCategoria" id="opcCategoria" >
                      <input type="hidden" name="llevaImagen" id="llevaImagen" >
                      <input type="hidden" name="nameImagen" id="nameImagen" >
                      <input type="hidden" name="urlImagen" id="urlImagen" >
                    <!--  <input type="hidden" name="arrImagenes" id="arrImagenes" >-->


                      <div class="form-group">
                        <div class="form-row">
                          <div class="col-md-7">
                            <label for="name">Nombre</label>
                            <input class="form-control" id="name_" name="name" type="text" aria-describedby="nameHelp"  placeholder="" maxlength="50"  tabindex="1" required>
                          </div>
                          <div class="col-md-3">
                            <label for="name">Código</label>
                            <input class="form-control" id="sku_" name="sku" type="text" aria-describedby="nameHelp"  placeholder="" maxlength="10"  tabindex="2" required>
                          </div>
                        </div>
                      </div>
                      <div class="form-group">
                        <div class="form-row">
                          <div class="col-md-10">
                            <label for="description">Descripción</label>
                            <input class="form-control " id="description" name="description" type="text" aria-describedby="descriptionHelp" placeholder=""  tabindex="3">
                          <!--
                            <textarea class="form-control" id="description" name="description" rows="2" aria-describedby="descriptionHelp" value="<?php //echo $description; ?>"   tabindex="3"></textarea>
            -->
                          </div>
                        </div>
                      </div>

                      <div class="form-group">
                        <div class="form-row">
                          <div class="col-md-2">
                            <label for="price">Precio</label>
                            <input class="form-control numeros" id="price_" name="price" type="text" aria-describedby="priceHelp"  placeholder="" maxlength="7"  tabindex="4" required>
                          </div>
                          <div class="col-md-2">
                            <label for="category">Categoria</label>
                            <select class="form-control" id="category" name="category" aria-describedby="categoryHelp"   tabindex="5" required>
                            <!--  <option value="1">Vestido</option>
                              <option value="2">Palazzo</option>-->
                            </select>
                          </div>
                          <div class="col-md-3">
                              <label for="category">Color</label>
                            <select class="form-control" id="color" name="color" aria-describedby="colorHelp"   tabindex="6">
                            </select>
                          </div>
                          <div class="col-md-2">
                            <label for="category">Estatus</label>
                            <select class="form-control" id="estatus" name="estatus" aria-describedby="categoryHelp"   tabindex="7" required>
                              <option value="1">Activo</option>
                              <option value="2">Inactivo</option>
                            </select>
                          </div>
                        </div>
                      </div>



                      <!-- SECCION PARA AGREGAR IMAGENES-->
                     <div class="form-group">
                       <div class="form-row">
                         <div class="col-md-10">
                           <div class="card" >
                             <div class="card-header">Foto</div>
                             <div class="card-body">

                                 <div class="form-group" id="drop">
                                    <div class="form-row">
                                       <div  class="col-md-7">
                                        <!-- <input type="file" class="form-control" name="images[]" id="img_select">-->
                                         <span class="btn btn-primary btn-file">Seleccionar Imagen <input type="file" name="images[]" id="img_select" tabindex="9"></span>
                                       </div>

                                       <div  class="col-md-3">
                                         <!--MOSTRAR IMAGENE-->
                                         <img id="imgSalida" width="100%" height="100%" src="" class="img-thumbnail rounded float-right"/>
                                       </div>
                                    </div>
                                </div>

                             </div>
                           </div>
                         </div>
                       </div>
                     </div>
                     <!-- fin SECCION PARA AGREGAR IMAGENES-->



          </div>
        </form>
          </div>
          <div class="modal-footer">
            <button type="button" id="btnSave" onclick="save()" class="btn btn-primary">Guardar</button>
            <button type="button" class="btn btn-danger" onclick="limpiarpantalla()" data-dismiss="modal">Cancelar</button>
          </div>
        </div><!-- /.modal-content -->
      </div><!-- /.modal-dialog -->
    </div><!-- /.modal -->
  <!-- End Bootstrap modal -->



  <!-- Modal Eliminar producto-->
  <div class="modal fade" id="modalEliminar" tabindex="-1" role="dialog" aria-labelledby="modalEliminarLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="modalEliminarLabel">¿Seguro desea eliminar este producto?</h5>
        <button class="close" type="button" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">×</span>
        </button>
      </div>
      <input type="hidden" value="" name="idproduct_delet" id="idproduct_delet"/>
    <!--  <div class="modal-body">Seleccione "Eliminar" si está seguro de la acción.</div>-->
      <div class="modal-footer">
        <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancelar</button>
          <button type="button" id="btnSave" onclick="delete_product()" class="btn btn-primary">Eliminar</button>
      </div>
    </div>
  </div>
  </div>


  <!-- Modal Visualizar producto-->
  <div class="modal fade" id="modalVisualizar" tabindex="-1" role="dialog" aria-labelledby="modalVisualizarLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="modalVisualizarLabel">Producto SKU</h5>
        <button class="close" type="button" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">×</span>
        </button>
      </div>
      <input type="hidden" value="" name="idproduct_delet" id="idproduct_delet"/>
      <div class="modal-body">
        <label id="lblVisNombre">Nombre</label>
        <label id="lblVisImagenes">Imagenes</label>

        <div id="carouselExampleControls" class="carousel slide" data-ride="carousel">
            <div id="carrouselImg" class="carousel-inner">
              <!--<div class="carousel-item active">
                <img class="d-block w-100" src="<?php //echo base_url('uploads/52_3.jpg'); ?>" alt="First slide">
              </div>-->
            </div>
            <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">
              <span class="carousel-control-prev-icon" aria-hidden="true"></span>
              <span class="sr-only">Previous</span>
            </a>
            <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
              <span class="carousel-control-next-icon" aria-hidden="true"></span>
              <span class="sr-only">Next</span>
            </a>
        </div>

      </div>
      <div class="modal-footer">
        <button class="btn btn-secondary" type="button" data-dismiss="modal">Regresar</button>
      </div>
    </div>
  </div>
  </div>
